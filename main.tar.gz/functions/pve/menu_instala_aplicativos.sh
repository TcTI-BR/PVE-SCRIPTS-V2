#!/bin/bash

# Menu de instalação de aplicativos

instala_aplicativos_menu(){
	clear
	NORMAL=`echo "\033[m"`
	MENU=`echo "\033[36m"`
	NUMBER=`echo "\033[33m"`
	FGRED=`echo "\033[41m"`
	RED_TEXT=`echo "\033[31m"`
	ENTER_LINE=`echo "\033[33m"`
	
	echo -e "${COLOR_CYAN}${COLOR_BOLD}"
	echo -e "╔═════════════════════════════════════════════════════════════════════╗"
	echo -e "║                                                                     ║"
	echo -e "║            📦 ${LANG_APPS_MENU_TITLE:-Instalação de Aplicativos e Ferramentas}                ║"
	echo -e "║                                                                     ║"
	echo -e "╚═════════════════════════════════════════════════════════════════════╝"
	echo -e "${COLOR_RESET}"
	echo ""
	echo -e "${COLOR_BOLD}  ${LANG_SELECT_OPT:-Selecione uma opção:}${COLOR_RESET}"
	echo ""
	echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	
	ui_print_menu_item "1" "${LANG_APPS_MENU_OPT_1}"
	ui_print_menu_item "2" "${LANG_APPS_MENU_OPT_2}"
	ui_print_menu_item "3" "${LANG_APPS_MENU_OPT_3}"
	ui_print_menu_item "4" "${LANG_APPS_MENU_OPT_4}" "${COLOR_GRAY}"
	
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	
	ui_print_menu_item "0" "${LANG_VM_OP_OPT_0:-Voltar}" "${COLOR_RED}"
	
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
	echo ""
	echo -e "${COLOR_YELLOW}  ${LANG_TYPE_OPT:-Digite sua opção} ${COLOR_GRAY}${LANG_PRESS_ENTER:-(ou pressione ENTER para sair)}${COLOR_YELLOW}: ${COLOR_RESET}"
	read -rsn1 opt
	
	while [ opt != '' ]
	do
		if [[ $opt = "" ]]; then
			update_menu
		else
			case $opt in
				1) clear;
				   instala_tactical_rmm_menu
				   ;;
				2) clear;
				   instala_cloudflared_menu
				   ;;
				3) clear;
				   instala_zabbix_menu
				   ;;
				4) clear;
				   echo -e "${COLOR_YELLOW}${SYMBOL_INFO} Funcionalidade em desenvolvimento...${COLOR_RESET}"
				   sleep 2
				   instala_aplicativos_menu
				   ;;
				0) clear;
				   update_menu
				   ;;
				*) clear;
				   update_menu
				   ;;
			esac
		fi
	done
}

