#!/bin/bash

# Menu de atualização do Proxmox VE

update_menu(){
	clear
	NORMAL=`echo "\033[m"`
	MENU=`echo "\033[36m"`
	NUMBER=`echo "\033[33m"`
	FGRED=`echo "\033[41m"`
	RED_TEXT=`echo "\033[31m"`
	ENTER_LINE=`echo "\033[33m"`
	
	echo -e "${COLOR_CYAN}${COLOR_BOLD}"
	echo -e "╔═════════════════════════════════════════════════════════════════════╗"
	ui_print_header_line "" "" 69
	ui_print_header_line "📦 ${LANG_UPDATE_MENU_TITLE:-Atualização, Instalação e Upgrade do Sistema}" "${COLOR_WHITE}" 69
	ui_print_header_line "" "" 69
	echo -e "╚═════════════════════════════════════════════════════════════════════╝"
	echo -e "${COLOR_RESET}"
	echo ""
	echo -e "${COLOR_BOLD}  ${LANG_SELECT_OPT:-Selecione uma opção:}${COLOR_RESET}"
	echo ""
	echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	
	ui_print_menu_item "1" "${LANG_UPDATE_MENU_OPT_1}"
	ui_print_menu_item "2" "${LANG_UPDATE_MENU_OPT_2}"
	ui_print_menu_item "3" "${LANG_UPDATE_MENU_OPT_3}"
	
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	
	ui_print_menu_item "0" "${LANG_VM_OP_OPT_0:-Voltar}" "${COLOR_RED}"
	
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
	echo ""
	echo -e "${COLOR_YELLOW}  ${LANG_TYPE_OPT:-Digite sua opção} ${COLOR_GRAY}${LANG_PRESS_ENTER:-(ou pressione ENTER para sair)}${COLOR_YELLOW}: ${COLOR_RESET}"
	read -rsn1 opt
	while [ opt != '' ]
	do
		if [[ $opt = "" ]]; then
			exit;
		else
			case $opt in
				1) clear;
				upgrade_menu
					;;
				2) clear;
				mv /etc/apt/sources.list.d/pve-enterprise.list /root/
				clear
				sed -i '/subscription/d' /etc/apt/sources.list
				echo "deb http://download.proxmox.com/debian/pve $distribution pve-no-subscription" >> /etc/apt/sources.list
				apt update
				apt upgrade -y
				apt install libsasl2-modules -y
				apt install lm-sensors
				apt install ifupdown2 -y
				apt install ntfs-3g -y
				apt install ethtool -y
				apt install zip -y
				apt install mutt -y 			
				read -p "Pressione uma tecla para continuar..."
				clear 
				update_menu;	
					;;
				3) clear;
				instala_aplicativos_menu
					;;
				0) clear;
				pve_menu;
					;;
				*)clear;
				pve_menu;
					;;
			esac
		fi
	done
}

