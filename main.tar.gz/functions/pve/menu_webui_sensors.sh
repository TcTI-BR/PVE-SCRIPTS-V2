#!/bin/bash

# ==============================================================================
# TcTI Proxmox Scripts - Customização de Sensores de Hardware na WebUI
# Monitoramento de Temperatura (CPU, Discos SATA/NVMe), Frequência (MHz), 
# Consumo Elétrico (PkgWatt) e Ventoinhas (RPM) no Dashboard do Proxmox VE
# ==============================================================================

NODES_PM="/usr/share/perl5/PVE/API2/Nodes.pm"
PVEMANAGER_JS="/usr/share/pve-manager/js/pvemanagerlib.js"
PROXMOXLIB_JS="/usr/share/javascript/proxmox-widget-toolkit/proxmoxlib.js"

BACKUP_DIR="/var/backups/tcti_webui_bak"

webui_sensors_menu() {
    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}"
    echo -e "╔═════════════════════════════════════════════════════════════════════╗"
    echo -e "║                                                                     ║"
    echo -e "║      🌡️  Customização & Sensores de Hardware na WebUI do PVE        ║"
    echo -e "║                                                                     ║"
    echo -e "╚═════════════════════════════════════════════════════════════════════╝"
    echo -e "${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_YELLOW}${COLOR_BOLD}  ℹ️ INFORMAÇÕES DE SEGURANÇA:${COLOR_RESET}"
    echo -e "  • Os arquivos originais limpos são salvos em: ${COLOR_CYAN}${BACKUP_DIR}${COLOR_RESET}"
    echo -e "  • Você pode restaurar a WebUI oficial a qualquer momento."
    echo ""
    
    if grep -q "TCTI_SENSORS_MOD" "$NODES_PM" 2>/dev/null; then
        STATUS_TXT="${COLOR_GREEN}[ATIVADO] Sensores de Hardware Ativos na WebUI${COLOR_RESET}"
    else
        STATUS_TXT="${COLOR_GRAY}[DESATIVADO] WebUI Padrão do Proxmox${COLOR_RESET}"
    fi
    echo -e "  Status Atual: ${STATUS_TXT}"
    echo ""
    echo -e "${COLOR_BOLD}  Selecione uma opção:${COLOR_RESET}"
    echo ""
    echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}1${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}Ativar Sensores de Temp, MHz, Watts & Discos na WebUI${COLOR_RESET}     ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}2${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}Restaurar WebUI Original (Restaurar do Backup)${COLOR_RESET}            ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}3${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}Reinstalar Pacotes Oficiais Proxmox (Restauração Total Limpa)${COLOR_RESET} ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_RED}0${COLOR_RESET} ${COLOR_RED}➜${COLOR_RESET}  ${COLOR_WHITE}Voltar ao menu anterior${COLOR_RESET}                                 ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_YELLOW}  Digite sua opção ${COLOR_GRAY}(ou pressione ENTER para sair)${COLOR_YELLOW}: ${COLOR_RESET}"
    read -rsn1 opt
    case $opt in
        1)
            aplicar_patch_sensores
            ;;
        2)
            restaurar_backup_sensores
            ;;
        3)
            reinstalar_pacotes_webui
            ;;
        0)
            pve_menu
            ;;
        *)
            pve_menu
            ;;
    esac
}

garantir_arquivos_limpos() {
    mkdir -p "$BACKUP_DIR"
    
    # Se os backups existentes estiverem corrompidos ou modificados, força reinstalação oficial limpa primeiro
    if [ -f "${BACKUP_DIR}/pvemanagerlib.js.orig" ]; then
        if grep -q "TCTI_SENSORS_MOD" "${BACKUP_DIR}/pvemanagerlib.js.orig" 2>/dev/null; then
            echo -e "${COLOR_YELLOW}Detectado backup antigo modificado. Baixando arquivos oficiais limpos...${COLOR_RESET}"
            rm -rf "${BACKUP_DIR}"/*
            apt-get install --reinstall -y pve-manager proxmox-widget-toolkit >/dev/null 2>&1
        fi
    fi

    # Se não existirem backups limpos, faz a cópia dos arquivos de fábrica atuais
    if [ ! -f "${BACKUP_DIR}/Nodes.pm.orig" ] && [ -f "$NODES_PM" ]; then
        cp "$NODES_PM" "${BACKUP_DIR}/Nodes.pm.orig"
    fi
    if [ ! -f "${BACKUP_DIR}/pvemanagerlib.js.orig" ] && [ -f "$PVEMANAGER_JS" ]; then
        cp "$PVEMANAGER_JS" "${BACKUP_DIR}/pvemanagerlib.js.orig"
    fi
    if [ ! -f "${BACKUP_DIR}/proxmoxlib.js.orig" ] && [ -f "$PROXMOXLIB_JS" ]; then
        cp "$PROXMOXLIB_JS" "${BACKUP_DIR}/proxmoxlib.js.orig"
    fi
}

aplicar_patch_sensores() {
    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}⚙️ Preparando ambiente e garantindo arquivos oficiais limpos...${COLOR_RESET}"
    echo ""
    
    # Garantir dependências
    apt-get update -qq 2>/dev/null
    apt-get install -y lm-sensors linux-cpupower kexec-tools python3 2>/dev/null

    # Módulos do Kernel
    modprobe drivetemp 2>/dev/null
    echo "drivetemp" > /etc/modules-load.d/drivetemp-tcti.conf 2>/dev/null

    modprobe msr 2>/dev/null
    echo "msr" > /etc/modules-load.d/msr-tcti.conf 2>/dev/null
    [ -f /usr/sbin/turbostat ] && chmod +s /usr/sbin/turbostat 2>/dev/null

    # Assegurar backups originais sem alterações
    garantir_arquivos_limpos

    # Restaurar a partir da cópia oficial limpa antes de injetar
    if [ -f "${BACKUP_DIR}/Nodes.pm.orig" ]; then
        cp "${BACKUP_DIR}/Nodes.pm.orig" "$NODES_PM"
    fi
    if [ -f "${BACKUP_DIR}/pvemanagerlib.js.orig" ]; then
        cp "${BACKUP_DIR}/pvemanagerlib.js.orig" "$PVEMANAGER_JS"
    fi

    echo -e "${COLOR_YELLOW}1/2 Injetando sensores no Backend Perl (Nodes.pm)...${COLOR_RESET}"

    python3 -c '
path = "/usr/share/perl5/PVE/API2/Nodes.pm"
with open(path, "r", encoding="utf-8", errors="ignore") as f:
    content = f.read()

patch = """
        # TCTI_SENSORS_MOD_BEGIN
        $res->{thermalstate} = `sensors 2>/dev/null`;
        $res->{cpumhz} = `cat /proc/cpuinfo | grep -i "cpu mhz" 2>/dev/null`;
        $res->{pkgwatt} = `[ -e /usr/sbin/turbostat ] && turbostat --quiet --cpu package --show "PkgWatt" -S sleep 0.2 2>&1 | tail -n1 2>/dev/null`;
        $res->{cpugovernor} = `cat /sys/devices/system/cpu/cpufreq/policy0/scaling_governor 2>/dev/null`;
        # TCTI_SENSORS_MOD_END
"""

if "TCTI_SENSORS_MOD_BEGIN" not in content:
    idx = content.rfind("return $res;")
    if idx != -1:
        new_content = content[:idx] + patch + "\n    " + content[idx:]
        with open(path, "w", encoding="utf-8") as f:
            f.write(new_content)
        print("Backend Nodes.pm atualizado.")
'

    echo -e "${COLOR_YELLOW}2/2 Injetando widgets com sintaxe ExtJS válida no Frontend (pvemanagerlib.js)...${COLOR_RESET}"

    python3 -c '
import re

path = "/usr/share/pve-manager/js/pvemanagerlib.js"
with open(path, "r", encoding="utf-8", errors="ignore") as f:
    content = f.read()

# Ajustar altura do card no dashboard de 300 para 420
content = re.sub(r"height:\s*300", "height: 420", content)

# Procurar o fim do objeto kversion no ExtJS StatusView: ex: textField: "kversion"\n } ou textField: '\''kversion'\''\n },
pattern = r"(textField:\s*['\"]kversion['\"]\s*,?\s*\n\s*\})"

patch = """,
	// TCTI_SENSORS_MOD_BEGIN
	{
	    itemId: 'thermalstate',
	    colspan: 2,
	    title: gettext('Sensores & Hardware'),
	    printBar: false,
	    textField: 'thermalstate',
	    renderer: function(value) {
	        if (!value) return 'N/A';
	        let lines = value.trim().split('\\n');
	        let temps = [];
	        lines.forEach(function(l) {
	            if (l.includes('°C') || l.includes('RPM')) {
	                temps.push(l.trim());
	            }
	        });
	        return temps.length > 0 ? temps.slice(0, 4).join(' | ') : value;
	    }
	},
	{
	    itemId: 'cpumhz',
	    colspan: 2,
	    title: gettext('CPU Frequência & Consumo'),
	    printBar: false,
	    textField: 'cpumhz',
	    renderer: function(val, meta, rec) {
	        let res = '';
	        if (val) {
	            let lines = val.trim().split('\\n');
	            let freqs = lines.map(l => parseFloat(l.split(':')[1])).filter(n => !isNaN(n));
	            if (freqs.length > 0) {
	                let avg = Math.round(freqs.reduce((a,b)=>a+b,0)/freqs.length);
	                res += 'Freq: ' + avg + ' MHz';
	            }
	        }
	        let watt = (rec.data.pkgwatt || '').trim();
	        let gov = (rec.data.cpugovernor || '').trim();
	        if (watt) res += (res ? ' | ' : '') + 'Consumo: ' + watt + 'W';
	        if (gov) res += (res ? ' | ' : '') + 'Perfil: ' + gov;
	        return res || 'N/A';
	    }
	}
	// TCTI_SENSORS_MOD_END"""

match = re.search(pattern, content)
if match:
    # Insere o patch LOGO APÓS o fechamento da chave } do objeto kversion
    content = content[:match.end()] + patch + content[match.end():]
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    print("Frontend pvemanagerlib.js atualizado com sucesso após kversion.")
else:
    print("Aviso: Bloco kversion não localizado para injeção. Verifique a versão do Proxmox.")
'

    echo -e "${COLOR_CYAN}Reiniciando pveproxy...${COLOR_RESET}"
    systemctl restart pveproxy

    echo ""
    echo -e "${COLOR_GREEN}${COLOR_BOLD}✅ Sensores aplicados com sucesso na WebUI!${COLOR_RESET}"
    echo -e "${COLOR_YELLOW}👉 Limpe o cache do navegador pressionando SHIFT + F5.${COLOR_RESET}"
    echo ""
    read -p "Pressione ENTER para continuar..."
    webui_sensors_menu
}

restaurar_backup_sensores() {
    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}🔄 Restaurando arquivos originais limpos da WebUI...${COLOR_RESET}"
    echo ""
    
    RESTORED=0
    if [ -f "${BACKUP_DIR}/Nodes.pm.orig" ]; then
        cp "${BACKUP_DIR}/Nodes.pm.orig" "$NODES_PM"
        RESTORED=1
    fi
    if [ -f "${BACKUP_DIR}/pvemanagerlib.js.orig" ]; then
        cp "${BACKUP_DIR}/pvemanagerlib.js.orig" "$PVEMANAGER_JS"
        RESTORED=1
    fi
    if [ -f "${BACKUP_DIR}/proxmoxlib.js.orig" ]; then
        cp "${BACKUP_DIR}/proxmoxlib.js.orig" "$PROXMOXLIB_JS"
        RESTORED=1
    fi

    if [ $RESTORED -eq 1 ]; then
        systemctl restart pveproxy
        echo -e "${COLOR_GREEN}${COLOR_BOLD}✅ Restauração via backup limpo efetuada com sucesso!${COLOR_RESET}"
    else
        reinstalar_pacotes_webui
        return
    fi
    echo ""
    read -p "Pressione ENTER para continuar..."
    webui_sensors_menu
}

reinstalar_pacotes_webui() {
    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}🛠️ Reinstalando pacotes oficiais pve-manager e proxmox-widget-toolkit...${COLOR_RESET}"
    echo ""
    rm -rf "${BACKUP_DIR}"/*
    apt-get update
    apt-get install --reinstall -y pve-manager proxmox-widget-toolkit
    systemctl restart pveproxy
    echo ""
    echo -e "${COLOR_GREEN}${COLOR_BOLD}✅ WebUI original 100% restaurada a partir do repositório oficial!${COLOR_RESET}"
    echo -e "${COLOR_YELLOW}Pressione SHIFT + F5 no navegador.${COLOR_RESET}"
    echo ""
    read -p "Pressione ENTER para continuar..."
    webui_sensors_menu
}
