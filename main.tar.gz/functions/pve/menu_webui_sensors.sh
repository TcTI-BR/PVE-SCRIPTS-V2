#!/bin/bash

# ==============================================================================
# TcTI Proxmox Scripts - Customização de Sensores de Hardware na WebUI
# Monitoramento de Temperatura (CPU, Discos SATA/NVMe), Frequência (MHz), 
# Consumo Elétrico (PkgWatt) e Ventoinhas (RPM) no Dashboard do Proxmox VE
# ==============================================================================

NODES_PM="/usr/share/perl5/PVE/API2/Nodes.pm"
PVEMANAGER_JS="/usr/share/pve-manager/js/pvemanagerlib.js"
PROXMOXLIB_JS="/usr/share/javascript/proxmox-widget-toolkit/proxmoxlib.js"

BACKUP_DIR="/TcTI/SCRIPTS/PROXMOX/webui_bak"

webui_sensors_menu() {
    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}"
    echo -e "╔═════════════════════════════════════════════════════════════════════╗"
    ui_print_header_line "" "" 69
    ui_print_header_line "🌡️  ${LANG_WEBUI_MENU_TITLE:-Customização & Sensores de Hardware na WebUI do PVE}" "${COLOR_WHITE}" 69
    ui_print_header_line "" "" 69
    echo -e "╚═════════════════════════════════════════════════════════════════════╝"
    echo -e "${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_YELLOW}${COLOR_BOLD}  ℹ️ ${LANG_WEBUI_MENU_INFO:-INFORMAÇÕES DE SEGURANÇA:}${COLOR_RESET}"
    echo -e "  • ${LANG_WEBUI_MENU_INFO_1:-Os arquivos originais limpos são salvos em:} ${COLOR_CYAN}${BACKUP_DIR}${COLOR_RESET}"
    echo -e "  • ${LANG_WEBUI_MENU_INFO_2:-Você pode restaurar a WebUI oficial a qualquer momento.}"
    echo ""
    
    if grep -q "TCTI_SENSORS_MOD" "$NODES_PM" 2>/dev/null; then
        STATUS_TXT="${COLOR_GREEN}${LANG_WEBUI_MENU_STATUS_ON:-[ATIVADO] Sensores de Hardware Ativos na WebUI}${COLOR_RESET}"
    else
        STATUS_TXT="${COLOR_GRAY}${LANG_WEBUI_MENU_STATUS_OFF:-[DESATIVADO] WebUI Padrão do Proxmox}${COLOR_RESET}"
    fi
    echo -e "  ${LANG_WEBUI_MENU_STATUS:-Status Atual:} ${STATUS_TXT}"
    echo ""
    echo -e "${COLOR_BOLD}  ${LANG_SELECT_OPT:-Selecione uma opção:}${COLOR_RESET}"
    echo ""
    echo -e "  ${COLOR_CYAN}┌─────────────────────────────────────────────────────────────────────┐${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                                     ${COLOR_CYAN}│${COLOR_RESET}"
    
    ui_print_menu_item "1" "${LANG_WEBUI_MENU_OPT_1}" "${COLOR_YELLOW}" 69
    ui_print_menu_item "2" "${LANG_WEBUI_MENU_OPT_2}" "${COLOR_YELLOW}" 69
    ui_print_menu_item "3" "${LANG_WEBUI_MENU_OPT_3}" "${COLOR_YELLOW}" 69
    
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                                     ${COLOR_CYAN}│${COLOR_RESET}"
    
    ui_print_menu_item "0" "${LANG_VM_OP_OPT_0:-Voltar}" "${COLOR_RED}" 69
    
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                                     ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}└─────────────────────────────────────────────────────────────────────┘${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_YELLOW}  ${LANG_TYPE_OPT:-Digite sua opção} ${COLOR_GRAY}${LANG_PRESS_ENTER:-(ou pressione ENTER para sair)}${COLOR_YELLOW}: ${COLOR_RESET}"
    read -rsn1 opt
    case $opt in
        1)
            aplicar_patch_sensores
            ;;
        2)
            restaurar_backup_sensores
            ;;
        3)
            reinstalar_pacotes_webui
            ;;
        0)
            pve_menu
            ;;
        *)
            pve_menu
            ;;
    esac
}

garantir_arquivos_limpos() {
    mkdir -p "$BACKUP_DIR"
    
    if grep -q "TCTI_SENSORS_MOD" "${BACKUP_DIR}/pvemanagerlib.js.orig" 2>/dev/null || grep -q "TCTI_SENSORS_MOD" "$PVEMANAGER_JS" 2>/dev/null; then
        echo -e "${COLOR_YELLOW}${LANG_WEBUI_CLEAN:-Limpando arquivos modificados antigos e baixando versão oficial limpa...}${COLOR_RESET}"
        rm -rf "${BACKUP_DIR}"/*
        apt-get install --reinstall -y pve-manager proxmox-widget-toolkit >/dev/null 2>&1
    fi

    if [ ! -f "${BACKUP_DIR}/Nodes.pm.orig" ] && [ -f "$NODES_PM" ]; then
        cp "$NODES_PM" "${BACKUP_DIR}/Nodes.pm.orig"
    fi
    if [ ! -f "${BACKUP_DIR}/pvemanagerlib.js.orig" ] && [ -f "$PVEMANAGER_JS" ]; then
        cp "$PVEMANAGER_JS" "${BACKUP_DIR}/pvemanagerlib.js.orig"
    fi
    if [ ! -f "${BACKUP_DIR}/proxmoxlib.js.orig" ] && [ -f "$PROXMOXLIB_JS" ]; then
        cp "$PROXMOXLIB_JS" "${BACKUP_DIR}/proxmoxlib.js.orig"
    fi
}

aplicar_patch_sensores() {
    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}${LANG_WEBUI_PREP:-⚙️ Preparando ambiente e garantindo arquivos oficiais limpos...}${COLOR_RESET}"
    echo ""
    
    apt-get update -qq 2>/dev/null
    apt-get install -y lm-sensors linux-cpupower kexec-tools python3 2>/dev/null

    modprobe drivetemp 2>/dev/null
echo "${LANG_AUTO_MENU_WEBUI_SENS_709:-drivetemp}" > /etc/modules-load.d/drivetemp-tcti.conf 2>/dev/null

    modprobe msr 2>/dev/null
    echo "msr" > /etc/modules-load.d/msr-tcti.conf 2>/dev/null
    [ -f /usr/sbin/turbostat ] && chmod +s /usr/sbin/turbostat 2>/dev/null

    garantir_arquivos_limpos

    if [ -f "${BACKUP_DIR}/Nodes.pm.orig" ]; then
        cp "${BACKUP_DIR}/Nodes.pm.orig" "$NODES_PM"
    fi
    if [ -f "${BACKUP_DIR}/pvemanagerlib.js.orig" ]; then
        cp "${BACKUP_DIR}/pvemanagerlib.js.orig" "$PVEMANAGER_JS"
    fi

    echo -e "${COLOR_YELLOW}${LANG_WEBUI_WIZ_START:-Iniciando o Assistente Interativo de Sensores...}${COLOR_RESET}"
    echo ""
    
    cat << 'EOF' > /tmp/tcti_sensor_wizard.py
import subprocess
import json
import os
import sys

print(f"\n{os.environ.get('LANG_WEBUI_WIZ_TITLE', '--- Assistente de Sensores ---')}")
print(f"{os.environ.get('LANG_WEBUI_WIZ_ANALYZE', 'Analisando sensores disponíveis...')}\n")

try:
    output = subprocess.check_output(["sensors"], text=True)
except Exception as e:
    print(os.environ.get('LANG_WEBUI_WIZ_ERR', "⚠️ Erro ao executar o comando 'sensors'. Certifique-se de que os módulos estão carregados."))
    sys.exit(1)

# Coletar todos os sensores primeiro
available_sensors = []
current_chip = ""
for line in output.strip().split('\n'):
    line = line.strip()
    if not line: continue
    if not ':' in line and len(line) > 2:
        current_chip = line
        continue
    
    if '°C' in line or 'RPM' in line:
        label = line.split(':')[0].strip()
        available_sensors.append({
            'chip': current_chip,
            'label': label,
            'full_line': line
        })

if not available_sensors:
    print(os.environ.get('LANG_WEBUI_WIZ_NONE', "Nenhum sensor de temperatura ou ventoinha foi detectado!"))
    sys.exit(0)

msg_detect = os.environ.get('LANG_WEBUI_WIZ_DETECT', 'Foram detectados {len} sensores. Vamos mapeá-los um a um.')
print(msg_detect.replace('{len}', str(len(available_sensors))) + "\n")

sensors_map = {}
for i, sensor in enumerate(available_sensors, 1):
    msg_sensor = os.environ.get('LANG_WEBUI_WIZ_SENSOR', '--- Sensor {i} de {total} ---')
    print(msg_sensor.replace('{i}', str(i)).replace('{total}', str(len(available_sensors))))
    msg_detected = os.environ.get('LANG_WEBUI_WIZ_DETECTED', 'Detectado:')
    print(f"{msg_detected} [{sensor['chip']}] {sensor['full_line']}")
    print(os.environ.get('LANG_WEBUI_WIZ_TYPE', "Qual o tipo deste sensor?"))
    print(os.environ.get('LANG_WEBUI_WIZ_OPTS', "[C] CPU  [M] Placa-Mãe  [D] Disco SATA  [N] Disco NVMe  [F] Ventoinha  [I] Ignorar"))
    print(os.environ.get('LANG_WEBUI_WIZ_HINT', "Dica: Digite a letra acima, ou escreva um nome (ex: 'CPU 1')."))
    
    while True:
        resp = input(os.environ.get('LANG_WEBUI_WIZ_CHOICE', "Sua escolha: ") + " ").strip()
        if not resp:
            print(os.environ.get('LANG_WEBUI_WIZ_INVALID', "Por favor, insira uma opção válida."))
            continue
        
        upper_resp = resp.upper()
        if upper_resp == 'I':
            print(os.environ.get('LANG_WEBUI_WIZ_IGN', "-> Ignorado.") + "\n")
            break
        
        mapped_label = resp
        if upper_resp == 'C': mapped_label = "CPU"
        elif upper_resp == 'M': mapped_label = "Placa-Mãe"
        elif upper_resp == 'D': mapped_label = "Disco SATA"
        elif upper_resp == 'N': mapped_label = "NVMe"
        elif upper_resp == 'F': mapped_label = "Ventoinha"
        
        key = f"{sensor['chip']}|{sensor['label']}"
        sensors_map[key] = mapped_label
        msg_mapped = os.environ.get('LANG_WEBUI_WIZ_MAPPED', '-> Mapeado como:')
        print(f"{msg_mapped} {mapped_label}\n")
        break

os.makedirs('/etc/tcti', exist_ok=True)
with open('/etc/tcti/sensors_map.json', 'w') as f:
    json.dump(sensors_map, f, indent=4)

print("\n" + os.environ.get('LANG_WEBUI_WIZ_SAVED', "✔ Mapeamento salvo com sucesso!"))

# Criar o script que será chamado pelo Proxmox backend
RUNNER_CODE = r"""#!/usr/bin/env python3
import subprocess
import json
import sys

def main():
    try:
        with open('/etc/tcti/sensors_map.json', 'r') as f:
            smap = json.load(f)
    except Exception:
        print("Sensores Ativos")
        return

    try:
        out = subprocess.check_output(['sensors'], text=True)
    except Exception:
        print("Sensores Ativos")
        return

    results = []
    current_chip = ""
    for line in out.strip().split('\n'):
        line = line.strip()
        if not line: continue
        if not ':' in line and len(line) > 2:
            current_chip = line.strip()
            continue
        
        if '°C' in line or 'RPM' in line:
            label = line.split(':')[0].strip()
            key = f"{current_chip}|{label}"
            if key in smap:
                parts = line.split(':')
                val = parts[1].split('(')[0].strip()
                val = val.replace('+', '')
                results.append(f"{smap[key]}: {val}")

    if results:
        print(" | ".join(results[:8]))
    else:
        print("Sensores Ativos")

if __name__ == '__main__':
    main()
"""
with open('/usr/local/bin/tcti-sensors.py', 'w') as f:
    f.write(RUNNER_CODE)
os.chmod('/usr/local/bin/tcti-sensors.py', 0o755)
EOF

    python3 /tmp/tcti_sensor_wizard.py
    rm -f /tmp/tcti_sensor_wizard.py


    echo -e "${COLOR_YELLOW}${LANG_WEBUI_INJ_1:-1/2 Injetando chamada do sensor na API de Status do Nó (Nodes.pm)...}${COLOR_RESET}"

    python3 << 'EOF'
import re

path = "/usr/share/perl5/PVE/API2/Nodes.pm"
with open(path, "r", encoding="utf-8", errors="ignore") as f:
    content = f.read()

if "TCTI_SENSORS_MOD_BEGIN" in content:
    content = re.sub(r"# TCTI_SENSORS_MOD_BEGIN.*?# TCTI_SENSORS_MOD_END\n", "", content, flags=re.DOTALL)

patch = """# TCTI_SENSORS_MOD_BEGIN
	$res->{thermalstate} = `/usr/local/bin/tcti-sensors.py 2>/dev/null`;
	$res->{cpumhz} = `lscpu | grep -i "CPU MHz" 2>/dev/null || cat /proc/cpuinfo | grep -i "cpu mhz" 2>/dev/null`;
	# TCTI_SENSORS_MOD_END
"""

status_pos = content.find("path => 'status'")
if status_pos == -1:
    status_pos = content.find('path => "status"')
if status_pos == -1:
    status_pos = content.find("name => 'status'")

if status_pos != -1:
    ret_pos = content.find("return $res;", status_pos)
    if ret_pos != -1:
        new_content = content[:ret_pos] + patch + "\t" + content[ret_pos:]
        with open(path, "w", encoding="utf-8") as f:
            f.write(new_content)
        print(os.environ.get('LANG_WEBUI_INJ_1_OK', "✔ Backend Nodes.pm atualizado com sucesso no endpoint de status do nó!"))
    else:
        print(os.environ.get('LANG_WEBUI_INJ_1_ERR1', "⚠️ Erro: return $res não encontrado dentro da sub status."))
else:
    print(os.environ.get('LANG_WEBUI_INJ_1_ERR2', "⚠️ Erro: Endpoint status não localizado em Nodes.pm."))
EOF

    echo -e "${COLOR_YELLOW}${LANG_WEBUI_INJ_2:-2/2 Injetando renderização no PVE.node.StatusView (pvemanagerlib.js)...}${COLOR_RESET}"

    python3 << 'EOF'
import os, re, sys

path = "/usr/share/pve-manager/js/pvemanagerlib.js"
if not os.path.exists(path):
    print(os.environ.get('LANG_WEBUI_INJ_2_ERR', "⚠️ pvemanagerlib.js não encontrado."))
    sys.exit(0)

with open(path, "r", encoding="utf-8", errors="ignore") as f:
    content = f.read()

if "TCTI_SENSORS_MOD_BEGIN" in content:
    content = re.sub(r",?\s*// TCTI_SENSORS_MOD_BEGIN.*?// TCTI_SENSORS_MOD_END", "", content, flags=re.DOTALL)

pos = content.find("PVE.node.StatusView")
if pos == -1:
    pos = content.find("node.StatusView")

if pos != -1:
    sub = content[pos:]
    
    def add_height(m):
        return f"height: {int(m.group(1)) + 70}"
    sub = re.sub(r"height:\s*(\d+)", add_height, sub, count=1)
    
    content = content[:pos] + sub

    items_pos = content.find("items: [", pos)
    if items_pos == -1:
        items_pos = content.find("items:[", pos)

    if items_pos != -1:
        # Procurar a posição do kversion para inserir os sensores logo antes
        kversion_pos = content.find("itemId: 'kversion'", items_pos)
        if kversion_pos == -1:
            kversion_pos = content.find('itemId: "kversion"', items_pos)
            
        insert_pos = -1
        if kversion_pos != -1:
            # Encontrar a chave '{' que abre o bloco do kversion
            insert_pos = content.rfind("{", items_pos, kversion_pos)
            
        # Fallback para o início do array caso não ache o kversion
        if insert_pos == -1:
            insert_pos = content.find("[", items_pos) + 1

        patch = """
	// TCTI_SENSORS_MOD_BEGIN
	{
	    itemId: 'thermalstate',
	    colspan: 2,
	    title: gettext('Sensores & Temperatura'),
	    printBar: false,
	    textField: 'thermalstate',
	    renderer: function(value) {
	        if (!value || typeof value !== 'string' || value.trim() === '') return 'N/A';
	        return value.replace(/Â/g, '').trim();
	    }
	},
	{
	    itemId: 'cpumhz',
	    colspan: 2,
	    title: gettext('Frequência da CPU'),
	    printBar: false,
	    textField: 'cpumhz',
	    renderer: function(val) {
	        if (!val || typeof val !== 'string' || val.trim() === '') return 'N/A';
	        let lines = val.trim().split('\\n');
	        let freqs = [];
	        lines.forEach(function(l) {
	            let parts = l.split(':');
	            if (parts.length > 1) {
	                let f = parseFloat(parts[1]);
	                if (!isNaN(f)) freqs.push(f);
	            }
	        });
	        if (freqs.length > 0) {
	            let avg = Math.round(freqs.reduce((a,b)=>a+b,0)/freqs.length);
	            return avg + ' MHz';
	        }
	        return val.substring(0, 50);
	    }
	},
	// TCTI_SENSORS_MOD_END
"""

        content = content[:insert_pos] + patch + content[insert_pos:]
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        print("✔ Frontend pvemanagerlib.js atualizado com sucesso na posição correta!")
    else:
        print("⚠️ Erro: items: [ não localizado dentro de PVE.node.StatusView.")
else:
    print("⚠️ Erro: PVE.node.StatusView não encontrado em pvemanagerlib.js.")
EOF

    echo -e "${COLOR_CYAN}${LANG_WEBUI_RESTART:-Reiniciando pveproxy...}${COLOR_RESET}"
    if systemctl restart pveproxy; then
        echo -e "${COLOR_GREEN}${LANG_WEBUI_RESTART_OK:-✔ pveproxy reiniciado com sucesso.}${COLOR_RESET}"
    else
        echo -e "${COLOR_RED}${LANG_WEBUI_RESTART_ERR:-⚠️ Falha ao reiniciar pveproxy. Restaurando versão original limpa por segurança...}${COLOR_RESET}"
        restaurar_backup_sensores
        return
    fi

    echo ""
    echo -e "${COLOR_GREEN}${COLOR_BOLD}${LANG_WEBUI_DONE:-✅ Sensores aplicados com sucesso na WebUI!}${COLOR_RESET}"
    echo -e "${COLOR_YELLOW}${LANG_WEBUI_F5:-👉 Limpe o cache do navegador pressionando CTRL + F5 ou feche a aba e abra novamente.}${COLOR_RESET}"
    echo ""
    read -p "${LANG_PVE_PRESS_ENTER:-Pressione ENTER para continuar...}"
    webui_sensors_menu
}

restaurar_backup_sensores() {
    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}${LANG_WEBUI_RESTORE_START:-🔄 Restaurando arquivos originais limpos da WebUI...}${COLOR_RESET}"
    echo ""
    
    RESTORED=0
    if [ -f "${BACKUP_DIR}/Nodes.pm.orig" ]; then
        cp "${BACKUP_DIR}/Nodes.pm.orig" "$NODES_PM"
        RESTORED=1
    fi
    if [ -f "${BACKUP_DIR}/pvemanagerlib.js.orig" ]; then
        cp "${BACKUP_DIR}/pvemanagerlib.js.orig" "$PVEMANAGER_JS"
        RESTORED=1
    fi
    if [ -f "${BACKUP_DIR}/proxmoxlib.js.orig" ]; then
        cp "${BACKUP_DIR}/proxmoxlib.js.orig" "$PROXMOXLIB_JS"
        RESTORED=1
    fi

    if [ $RESTORED -eq 1 ]; then
        systemctl restart pveproxy
        echo -e "${COLOR_GREEN}${COLOR_BOLD}${LANG_WEBUI_RESTORE_OK:-✅ Restauração via backup limpo efetuada com sucesso!}${COLOR_RESET}"
    else
        reinstalar_pacotes_webui
        return
    fi
    echo ""
    read -p "${LANG_PVE_PRESS_ENTER:-Pressione ENTER para continuar...}"
    webui_sensors_menu
}

reinstalar_pacotes_webui() {
    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}${LANG_WEBUI_REINSTALL_START:-🛠️ Reinstalando pacotes oficiais pve-manager e proxmox-widget-toolkit...}${COLOR_RESET}"
    echo ""
    rm -rf "${BACKUP_DIR}"/*
    apt-get update
    apt-get install --reinstall -y pve-manager proxmox-widget-toolkit
    systemctl restart pveproxy
    echo ""
    echo -e "${COLOR_GREEN}${COLOR_BOLD}${LANG_WEBUI_REINSTALL_OK:-✅ WebUI original 100% restaurada a partir do repositório oficial!}${COLOR_RESET}"
    echo -e "${COLOR_YELLOW}${LANG_WEBUI_REINSTALL_F5:-Pressione CTRL + F5 no navegador.}${COLOR_RESET}"
    echo ""
    read -p "${LANG_PVE_PRESS_ENTER:-Pressione ENTER para continuar...}"
    webui_sensors_menu
}
