#!/bin/bash

# ==============================================================================
# TcTI Proxmox Scripts - Customização de Sensores de Hardware na WebUI
# Monitoramento de Temperatura (CPU, Discos SATA/NVMe), Frequência (MHz), 
# Consumo Elétrico (PkgWatt) e Ventoinhas (RPM) no Dashboard do Proxmox VE
# ==============================================================================

# Arquivos afetados no Proxmox VE:
# 1. /usr/share/perl5/PVE/API2/Nodes.pm (Backend Perl API)
# 2. /usr/share/pve-manager/js/pvemanagerlib.js (Frontend ExtJS)
# 3. /usr/share/javascript/proxmox-widget-toolkit/proxmoxlib.js (Widget Toolkit)

NODES_PM="/usr/share/perl5/PVE/API2/Nodes.pm"
PVEMANGER_JS="/usr/share/pve-manager/js/pvemanagerlib.js"
PROXMOXLIB_JS="/usr/share/javascript/proxmox-widget-toolkit/proxmoxlib.js"

BACKUP_DIR="/var/backups/tcti_webui_bak"

webui_sensors_menu() {
    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}"
    echo -e "╔═════════════════════════════════════════════════════════════════════╗"
    echo -e "║                                                                     ║"
    echo -e "║      🌡️  Customização & Sensores de Hardware na WebUI do PVE        ║"
    echo -e "║                                                                     ║"
    echo -e "╚═════════════════════════════════════════════════════════════════════╝"
    echo -e "${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_YELLOW}${COLOR_BOLD}  ℹ️ INFORMACÕES DE SEGURANÇA:${COLOR_RESET}"
    echo -e "  • Este assistente realiza backups preventivos de segurança dos arquivos da WebUI."
    echo -e "  • Seus arquivos originais serão preservados em: ${COLOR_CYAN}${BACKUP_DIR}${COLOR_RESET}"
    echo -e "  • É fornecida a opção de restauração limpa em 1-click a qualquer momento."
    echo ""
    
    # Verificar status atual
    if grep -q "TCTI_SENSORS_MOD" "$NODES_PM" 2>/dev/null; then
        STATUS_TXT="${COLOR_GREEN}[ATIVADO] Sensores aplicados na WebUI${COLOR_RESET}"
    else
        STATUS_TXT="${COLOR_YELLOW}[DESATIVADO] WebUI Padrão do Proxmox${COLOR_RESET}"
    fi
    echo -e "  Status Atual: ${STATUS_TXT}"
    echo ""
    echo -e "${COLOR_BOLD}  Selecione uma opção:${COLOR_RESET}"
    echo ""
    echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}1${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}Ativar Sensores Completo na WebUI (Temp, MHz, Watts, Discos)${COLOR_RESET} ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}2${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}Restaurar WebUI Original (Desfazer alterações via Backup)${COLOR_RESET}   ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}3${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}Reinstalar Pacotes Oficiais (Restauração Forçada Limpa)${COLOR_RESET} ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_RED}0${COLOR_RESET} ${COLOR_RED}➜${COLOR_RESET}  ${COLOR_WHITE}Voltar ao menu anterior${COLOR_RESET}                                 ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_YELLOW}  Digite sua opção ${COLOR_GRAY}(ou pressione ENTER para sair)${COLOR_YELLOW}: ${COLOR_RESET}"
    read -rsn1 opt
    case $opt in
        1)
            aplicar_patch_sensores
            ;;
        2)
            restaurar_backup_sensores
            ;;
        3)
            reinstalar_pacotes_webui
            ;;
        0)
            pve_menu
            ;;
        *)
            pve_menu
            ;;
    esac
}

criar_backups_seguranca() {
    mkdir -p "$BACKUP_DIR"
    
    # Criar backup do Nodes.pm se não existir backup preservado
    if [ -f "$NODES_PM" ] && [ ! -f "${BACKUP_DIR}/Nodes.pm.orig" ]; then
        cp "$NODES_PM" "${BACKUP_DIR}/Nodes.pm.orig"
        echo -e "${COLOR_GREEN}✔ Backup criado: ${BACKUP_DIR}/Nodes.pm.orig${COLOR_RESET}"
    fi

    # Criar backup do pvemanagerlib.js se não existir backup preservado
    if [ -f "$PVEMANGER_JS" ] && [ ! -f "${BACKUP_DIR}/pvemanagerlib.js.orig" ]; then
        cp "$PVEMANGER_JS" "${BACKUP_DIR}/pvemanagerlib.js.orig"
        echo -e "${COLOR_GREEN}✔ Backup criado: ${BACKUP_DIR}/pvemanagerlib.js.orig${COLOR_RESET}"
    fi

    # Criar backup do proxmoxlib.js se não existir backup preservado
    if [ -f "$PROXMOXLIB_JS" ] && [ ! -f "${BACKUP_DIR}/proxmoxlib.js.orig" ]; then
        cp "$PROXMOXLIB_JS" "${BACKUP_DIR}/proxmoxlib.js.orig"
        echo -e "${COLOR_GREEN}✔ Backup criado: ${BACKUP_DIR}/proxmoxlib.js.orig${COLOR_RESET}"
    fi
}

aplicar_patch_sensores() {
    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}⚙️ Preparando dependências de hardware e módulos do Kernel...${COLOR_RESET}"
    echo ""
    
    # 1. Instalar dependências necessárias
    echo -e "${COLOR_YELLOW}1/5 Instalando lm-sensors, linux-cpupower e turbostat...${COLOR_RESET}"
    apt-get update -qq 2>/dev/null
    apt-get install -y lm-sensors linux-cpupower kexec-tools 2>/dev/null

    # 2. Ativar módulo de kernel drivetemp para leitura nativa de discos SATA/HDD/SSD via lm-sensors
    echo -e "${COLOR_YELLOW}2/5 Carregando módulo de kernel drivetemp (Leitura SATA/HDD/SSD)...${COLOR_RESET}"
    modprobe drivetemp 2>/dev/null
    echo "drivetemp" > /etc/modules-load.d/drivetemp-tcti.conf

    # 3. Ativar módulo de kernel msr e turbostat para leitura de Watts da CPU
    echo -e "${COLOR_YELLOW}3/5 Carregando módulo de kernel msr e ativando turbostat (Consumo em Watts)...${COLOR_RESET}"
    modprobe msr 2>/dev/null
    echo "msr" > /etc/modules-load.d/msr-tcti.conf
    [ -f /usr/sbin/turbostat ] && chmod +s /usr/sbin/turbostat 2>/dev/null

    # 4. Criar backups de segurança antes de modificar os arquivos da WebUI
    echo -e "${COLOR_YELLOW}4/5 Salvando cópia de segurança dos arquivos da WebUI...${COLOR_RESET}"
    criar_backups_seguranca

    # Se já tiver o patch aplicado, restaura a cópia original primeiro para aplicar limpo
    if grep -q "TCTI_SENSORS_MOD" "$NODES_PM" 2>/dev/null; then
        [ -f "${BACKUP_DIR}/Nodes.pm.orig" ] && cp "${BACKUP_DIR}/Nodes.pm.orig" "$NODES_PM"
        [ -f "${BACKUP_DIR}/pvemanagerlib.js.orig" ] && cp "${BACKUP_DIR}/pvemanagerlib.js.orig" "$PVEMANGER_JS"
    fi

    echo -e "${COLOR_YELLOW}5/5 Aplicando injeção de código limpa no backend Perl e frontend JS...${COLOR_RESET}"

    # Injeção no Backend Perl (/usr/share/perl5/PVE/API2/Nodes.pm)
    PERL_PATCH='
        # TCTI_SENSORS_MOD_BEGIN
        $res->{thermalstate} = `sensors -j 2>/dev/null`;
        $res->{cpumhz} = `cat /proc/cpuinfo | grep -i "cpu mhz" 2>/dev/null`;
        $res->{pkgwatt} = `[ -e /usr/sbin/turbostat ] && turbostat --quiet --cpu package --show "PkgWatt" -S sleep 0.2 2>&1 | tail -n1 2>/dev/null`;
        $res->{cpugovernor} = `cat /sys/devices/system/cpu/cpufreq/policy0/scaling_governor 2>/dev/null`;
        # TCTI_SENSORS_MOD_END
'
    # Inserir o patch antes do 'return $res;' na função status do Nodes.pm
    if ! grep -q "TCTI_SENSORS_MOD" "$NODES_PM"; then
        awk -v patch="$PERL_PATCH" '/return \$res;/ { print patch } { print }' "$NODES_PM" > "${NODES_PM}.tmp" && mv "${NODES_PM}.tmp" "$NODES_PM"
    fi

    # Injeção no Frontend JavaScript (/usr/share/pve-manager/js/pvemanagerlib.js)
    # 1. Expandir a altura do card de status do nó de 300 para 420
    sed -i 's/height:\s*300/height: 420/g' "$PVEMANGER_JS" 2>/dev/null

    # 2. Injetar renderizador de temperatura, frequência e consumo
    JS_PATCH='
        // TCTI_SENSORS_MOD_BEGIN
        {
            itemId: "tcti_thermal",
            colspan: 2,
            printBar: false,
            title: gettext("Sensores & Hardware"),
            textField: "thermalstate",
            renderer: function(value) {
                if (!value) return "N/A";
                try {
                    let data = JSON.parse(value);
                    let items = [];
                    for (let chip in data) {
                        let cdata = data[chip];
                        if (chip.includes("coretemp") || chip.includes("cpu")) {
                            let temps = [];
                            for (let key in cdata) {
                                for (let sub in cdata[key]) {
                                    if (sub.includes("input")) temps.push(Math.round(cdata[key][sub]));
                                }
                            }
                            if (temps.length > 0) items.push("CPU: " + temps[0] + "°C (" + temps.join(" | ") + "°C)");
                        } else if (chip.includes("nvme")) {
                            for (let key in cdata) {
                                for (let sub in cdata[key]) {
                                    if (sub.includes("input")) items.push("NVMe (" + key + "): " + Math.round(cdata[key][sub]) + "°C");
                                }
                            }
                        } else if (chip.includes("drivetemp")) {
                            for (let key in cdata) {
                                for (let sub in cdata[key]) {
                                    if (sub.includes("input")) items.push("Disco: " + Math.round(cdata[key][sub]) + "°C");
                                }
                            }
                        }
                    }
                    return items.length > 0 ? items.join(" | ") : "Sensores ativos";
                } catch(e) { return "Carregando sensores..."; }
            }
        },
        {
            itemId: "tcti_power_mhz",
            colspan: 2,
            printBar: false,
            title: gettext("CPU Freq / Consumo (Watts)"),
            textField: "cpumhz",
            renderer: function(val, meta, rec) {
                let mhz = "N/A";
                if (val) {
                    let lines = val.trim().split("\n");
                    let freqs = lines.map(l => parseFloat(l.split(":")[1])).filter(n => !isNaN(n));
                    if (freqs.length > 0) {
                        let avg = Math.round(freqs.reduce((a,b)=>a+b,0)/freqs.length);
                        mhz = avg + " MHz";
                    }
                }
                let watt = (rec.data.pkgwatt || "").trim();
                let gov = (rec.data.cpugovernor || "").trim();
                let res = "Frequência: " + mhz;
                if (watt) res += " | Consumo: " + watt + "W";
                if (gov) res += " | Perfil: " + gov;
                return res;
            }
        },
        // TCTI_SENSORS_MOD_END
'
    if ! grep -q "TCTI_SENSORS_MOD" "$PVEMANGER_JS"; then
        awk -v patch="$JS_PATCH" '/pveNodeStatus/ { print; print patch; next } { print }' "$PVEMANGER_JS" > "${PVEMANGER_JS}.tmp" && mv "${PVEMANGER_JS}.tmp" "$PVEMANGER_JS" 2>/dev/null || true
    fi

    # Reiniciar o serviço web do Proxmox pveproxy
    echo -e "${COLOR_CYAN}Reiniciando serviço pveproxy...${COLOR_RESET}"
    systemctl restart pveproxy

    echo ""
    echo -e "${COLOR_GREEN}${COLOR_BOLD}✅ Sensores de Hardware aplicados com sucesso na WebUI do Proxmox VE!${COLOR_RESET}"
    echo -e "${COLOR_YELLOW}👉 Abra a WebUI do Proxmox e pressione SHIFT + F5 no navegador para atualizar o cache visual.${COLOR_RESET}"
    echo ""
    read -p "Pressione ENTER para continuar..."
    webui_sensors_menu
}

restaurar_backup_sensores() {
    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}🔄 Restaurando arquivos originais da WebUI a partir do backup...${COLOR_RESET}"
    echo ""
    
    RESTORED=0
    if [ -f "${BACKUP_DIR}/Nodes.pm.orig" ]; then
        cp "${BACKUP_DIR}/Nodes.pm.orig" "$NODES_PM"
        echo -e "${COLOR_GREEN}✔ Restaurado: $NODES_PM${COLOR_RESET}"
        RESTORED=1
    fi

    if [ -f "${BACKUP_DIR}/pvemanagerlib.js.orig" ]; then
        cp "${BACKUP_DIR}/pvemanagerlib.js.orig" "$PVEMANGER_JS"
        echo -e "${COLOR_GREEN}✔ Restaurado: $PVEMANGER_JS${COLOR_RESET}"
        RESTORED=1
    fi

    if [ -f "${BACKUP_DIR}/proxmoxlib.js.orig" ]; then
        cp "${BACKUP_DIR}/proxmoxlib.js.orig" "$PROXMOXLIB_JS"
        echo -e "${COLOR_GREEN}✔ Restaurado: $PROXMOXLIB_JS${COLOR_RESET}"
        RESTORED=1
    fi

    if [ $RESTORED -eq 1 ]; then
        systemctl restart pveproxy
        echo ""
        echo -e "${COLOR_GREEN}${COLOR_BOLD}✅ Restauração via backup concluída!${COLOR_RESET}"
        echo -e "${COLOR_YELLOW}Pressione SHIFT + F5 no navegador para atualizar a WebUI.${COLOR_RESET}"
    else
        echo -e "${COLOR_YELLOW}Nenhum arquivo de backup foi encontrado em ${BACKUP_DIR}.${COLOR_RESET}"
    fi
    echo ""
    read -p "Pressione ENTER para continuar..."
    webui_sensors_menu
}

reinstalar_pacotes_webui() {
    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}🛠️ Reinstalando pacotes oficiais pve-manager e proxmox-widget-toolkit...${COLOR_RESET}"
    echo -e "${COLOR_YELLOW}Isso fará o download da versão oficial limpa dos arquivos da WebUI diretamente do repositório Proxmox.${COLOR_RESET}"
    echo ""
    read -p "Deseja continuar? (s/N): " resp
    if [[ "$resp" == "s" || "$resp" == "S" ]]; then
        apt-get update
        apt-get install --reinstall -y pve-manager proxmox-widget-toolkit
        systemctl restart pveproxy
        echo ""
        echo -e "${COLOR_GREEN}${COLOR_BOLD}✅ Pacotes oficiais reinstalados com sucesso! WebUI original restaurada 100%.${COLOR_RESET}"
        echo -e "${COLOR_YELLOW}Pressione SHIFT + F5 no navegador.${COLOR_RESET}"
    else
        echo -e "${COLOR_YELLOW}Operação cancelada.${COLOR_RESET}"
    fi
    echo ""
    read -p "Pressione ENTER para continuar..."
    webui_sensors_menu
}
