#!/bin/bash

# ==============================================================================
# TcTI Proxmox Scripts - Customização de Sensores de Hardware na WebUI
# Monitoramento de Temperatura (CPU, Discos SATA/NVMe), Frequência (MHz), 
# Consumo Elétrico (PkgWatt) e Ventoinhas (RPM) no Dashboard do Proxmox VE
# ==============================================================================

NODES_PM="/usr/share/perl5/PVE/API2/Nodes.pm"
PVEMANAGER_JS="/usr/share/pve-manager/js/pvemanagerlib.js"
PROXMOXLIB_JS="/usr/share/javascript/proxmox-widget-toolkit/proxmoxlib.js"

BACKUP_DIR="/var/backups/tcti_webui_bak"

webui_sensors_menu() {
    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}"
    echo -e "╔═════════════════════════════════════════════════════════════════════╗"
    echo -e "║                                                                     ║"
    echo -e "║      🌡️  Customização & Sensores de Hardware na WebUI do PVE        ║"
    echo -e "║                                                                     ║"
    echo -e "╚═════════════════════════════════════════════════════════════════════╝"
    echo -e "${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_YELLOW}${COLOR_BOLD}  ℹ️ INFORMACÕES DE SEGURANÇA:${COLOR_RESET}"
    echo -e "  • Seus arquivos originais estão preservados em: ${COLOR_CYAN}${BACKUP_DIR}${COLOR_RESET}"
    echo -e "  • Você pode restaurar a WebUI original a qualquer momento."
    echo ""
    
    if grep -q "TCTI_SENSORS_MOD" "$NODES_PM" 2>/dev/null; then
        STATUS_TXT="${COLOR_GREEN}[ATIVADO] Sensores de Hardware na WebUI${COLOR_RESET}"
    else
        STATUS_TXT="${COLOR_YELLOW}[DESATIVADO] WebUI Padrão do Proxmox${COLOR_RESET}"
    fi
    echo -e "  Status Atual: ${STATUS_TXT}"
    echo ""
    echo -e "${COLOR_BOLD}  Selecione uma opção:${COLOR_RESET}"
    echo ""
    echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}1${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}Ativar Sensores de Temp, MHz, Watts & Discos na WebUI${COLOR_RESET}     ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}2${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}Restaurar WebUI Original (Restaurar do Backup)${COLOR_RESET}            ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}3${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}Reinstalar Pacotes Oficiais Proxmox (Restauração Total Limpa)${COLOR_RESET} ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_RED}0${COLOR_RESET} ${COLOR_RED}➜${COLOR_RESET}  ${COLOR_WHITE}Voltar ao menu anterior${COLOR_RESET}                                 ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_YELLOW}  Digite sua opção ${COLOR_GRAY}(ou pressione ENTER para sair)${COLOR_YELLOW}: ${COLOR_RESET}"
    read -rsn1 opt
    case $opt in
        1)
            aplicar_patch_sensores
            ;;
        2)
            restaurar_backup_sensores
            ;;
        3)
            reinstalar_pacotes_webui
            ;;
        0)
            pve_menu
            ;;
        *)
            pve_menu
            ;;
    esac
}

criar_backups_seguranca() {
    mkdir -p "$BACKUP_DIR"
    
    if [ -f "$NODES_PM" ] && [ ! -f "${BACKUP_DIR}/Nodes.pm.orig" ]; then
        cp "$NODES_PM" "${BACKUP_DIR}/Nodes.pm.orig"
    fi

    if [ -f "$PVEMANAGER_JS" ] && [ ! -f "${BACKUP_DIR}/pvemanagerlib.js.orig" ]; then
        cp "$PVEMANAGER_JS" "${BACKUP_DIR}/pvemanagerlib.js.orig"
    fi

    if [ -f "$PROXMOXLIB_JS" ] && [ ! -f "${BACKUP_DIR}/proxmoxlib.js.orig" ]; then
        cp "$PROXMOXLIB_JS" "${BACKUP_DIR}/proxmoxlib.js.orig"
    fi
}

aplicar_patch_sensores() {
    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}⚙️ Instalando dependências e carregando módulos do Kernel...${COLOR_RESET}"
    echo ""
    
    # 1. Instalar dependências
    apt-get update -qq 2>/dev/null
    apt-get install -y lm-sensors linux-cpupower kexec-tools 2>/dev/null

    # 2. Módulos do Kernel (drivetemp e msr)
    modprobe drivetemp 2>/dev/null
    echo "drivetemp" > /etc/modules-load.d/drivetemp-tcti.conf 2>/dev/null

    modprobe msr 2>/dev/null
    echo "msr" > /etc/modules-load.d/msr-tcti.conf 2>/dev/null
    [ -f /usr/sbin/turbostat ] && chmod +s /usr/sbin/turbostat 2>/dev/null

    # 3. Criar backups
    criar_backups_seguranca

    # Restaurar cópia limpa primeiro para garantir integridade antes de aplicar
    if [ -f "${BACKUP_DIR}/Nodes.pm.orig" ]; then
        cp "${BACKUP_DIR}/Nodes.pm.orig" "$NODES_PM"
    fi
    if [ -f "${BACKUP_DIR}/pvemanagerlib.js.orig" ]; then
        cp "${BACKUP_DIR}/pvemanagerlib.js.orig" "$PVEMANAGER_JS"
    fi

    echo -e "${COLOR_YELLOW}Aplicando patch no Backend Perl (/usr/share/perl5/PVE/API2/Nodes.pm)...${COLOR_RESET}"

    # Injeção segura no Nodes.pm antes da linha 'return $res;'
    python3 -c '
import sys

path = "/usr/share/perl5/PVE/API2/Nodes.pm"
with open(path, "r") as f:
    content = f.read()

patch = """
        # TCTI_SENSORS_MOD_BEGIN
        $res->{thermalstate} = `sensors 2>/dev/null`;
        $res->{cpumhz} = `cat /proc/cpuinfo | grep -i "cpu mhz" 2>/dev/null`;
        $res->{pkgwatt} = `[ -e /usr/sbin/turbostat ] && turbostat --quiet --cpu package --show "PkgWatt" -S sleep 0.2 2>&1 | tail -n1 2>/dev/null`;
        $res->{cpugovernor} = `cat /sys/devices/system/cpu/cpufreq/policy0/scaling_governor 2>/dev/null`;
        # TCTI_SENSORS_MOD_END
"""

if "TCTI_SENSORS_MOD_BEGIN" not in content:
    idx = content.rfind("return $res;")
    if idx != -1:
        new_content = content[:idx] + patch + "\n    " + content[idx:]
        with open(path, "w") as f:
            f.write(new_content)
        print("Backend Nodes.pm atualizado com sucesso.")
'

    echo -e "${COLOR_YELLOW}Aplicando patch no Frontend JS (/usr/share/pve-manager/js/pvemanagerlib.js)...${COLOR_RESET}"

    # Injeção válida no pvemanagerlib.js usando Python para garantir sintaxe JS 100% perfeita
    python3 -c '
import sys

path = "/usr/share/pve-manager/js/pvemanagerlib.js"
with open(path, "r", encoding="utf-8", errors="ignore") as f:
    content = f.read()

# Ajustar altura da caixa de status
content = content.replace("height: 300,", "height: 420,").replace("height: 300 ", "height: 420 ")

target = "textField: '\''kversion'\'',"
if target not in content:
    target = "textField: \"kversion\","

patch = """,
        // TCTI_SENSORS_MOD_BEGIN
        {
            itemId: "thermalstate",
            colspan: 2,
            title: gettext("Sensores & Temperatura"),
            printBar: false,
            textField: "thermalstate",
            renderer: function(value) {
                if (!value) return "N/A";
                let lines = value.trim().split("\\n");
                let temps = [];
                lines.forEach(function(l) {
                    if (l.includes("°C") || l.includes("RPM")) {
                        temps.push(l.trim());
                    }
                });
                return temps.length > 0 ? temps.slice(0, 4).join(" | ") : value;
            }
        },
        {
            itemId: "cpumhz",
            colspan: 2,
            title: gettext("CPU Frequência & Consumo (Watts)"),
            printBar: false,
            textField: "cpumhz",
            renderer: function(val, meta, rec) {
                let res = "";
                if (val) {
                    let lines = val.trim().split("\\n");
                    let freqs = lines.map(l => parseFloat(l.split(":")[1])).filter(n => !isNaN(n));
                    if (freqs.length > 0) {
                        let avg = Math.round(freqs.reduce((a,b)=>a+b,0)/freqs.length);
                        res += "Freq: " + avg + " MHz";
                    }
                }
                let watt = (rec.data.pkgwatt || "").trim();
                let gov = (rec.data.cpugovernor || "").trim();
                if (watt) res += (res ? " | " : "") + "Consumo: " + watt + "W";
                if (gov) res += (res ? " | " : "") + "Perfil: " + gov;
                return res || "N/A";
            }
        }
        // TCTI_SENSORS_MOD_END"""

if "TCTI_SENSORS_MOD_BEGIN" not in content and target in content:
    content = content.replace(target, target + patch)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    print("Frontend pvemanagerlib.js atualizado com sucesso.")
else:
    print("Alvo de injeção encontrado ou mod já existente.")
'

    echo -e "${COLOR_CYAN}Reiniciando serviço web pveproxy...${COLOR_RESET}"
    systemctl restart pveproxy

    echo ""
    echo -e "${COLOR_GREEN}${COLOR_BOLD}✅ Sensores de Hardware aplicados com sucesso na WebUI do Proxmox VE!${COLOR_RESET}"
    echo -e "${COLOR_YELLOW}👉 Pressione SHIFT + F5 no navegador para carregar as alterações sem cache.${COLOR_RESET}"
    echo ""
    read -p "Pressione ENTER para continuar..."
    webui_sensors_menu
}

restaurar_backup_sensores() {
    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}🔄 Restaurando arquivos originais da WebUI a partir do backup local...${COLOR_RESET}"
    echo ""
    
    RESTORED=0
    if [ -f "${BACKUP_DIR}/Nodes.pm.orig" ]; then
        cp "${BACKUP_DIR}/Nodes.pm.orig" "$NODES_PM"
        echo -e "${COLOR_GREEN}✔ Restaurado: $NODES_PM${COLOR_RESET}"
        RESTORED=1
    fi

    if [ -f "${BACKUP_DIR}/pvemanagerlib.js.orig" ]; then
        cp "${BACKUP_DIR}/pvemanagerlib.js.orig" "$PVEMANAGER_JS"
        echo -e "${COLOR_GREEN}✔ Restaurado: $PVEMANAGER_JS${COLOR_RESET}"
        RESTORED=1
    fi

    if [ -f "${BACKUP_DIR}/proxmoxlib.js.orig" ]; then
        cp "${BACKUP_DIR}/proxmoxlib.js.orig" "$PROXMOXLIB_JS"
        echo -e "${COLOR_GREEN}✔ Restaurado: $PROXMOXLIB_JS${COLOR_RESET}"
        RESTORED=1
    fi

    if [ $RESTORED -eq 1 ]; then
        systemctl restart pveproxy
        echo ""
        echo -e "${COLOR_GREEN}${COLOR_BOLD}✅ Restauração via backup concluída com sucesso!${COLOR_RESET}"
        echo -e "${COLOR_YELLOW}Pressione SHIFT + F5 no navegador.${COLOR_RESET}"
    else
        echo -e "${COLOR_YELLOW}Executando reinstalação oficial dos pacotes para garantir a recuperação...${COLOR_RESET}"
        reinstalar_pacotes_webui
        return
    fi
    echo ""
    read -p "Pressione ENTER para continuar..."
    webui_sensors_menu
}

reinstalar_pacotes_webui() {
    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}🛠️ Reinstalando pacotes oficiais pve-manager e proxmox-widget-toolkit...${COLOR_RESET}"
    echo -e "${COLOR_YELLOW}Isso fará o download da versão oficial limpa dos arquivos da WebUI diretamente do repositório Proxmox.${COLOR_RESET}"
    echo ""
    apt-get update
    apt-get install --reinstall -y pve-manager proxmox-widget-toolkit
    systemctl restart pveproxy
    echo ""
    echo -e "${COLOR_GREEN}${COLOR_BOLD}✅ Pacotes oficiais reinstalados com sucesso! WebUI original 100% restaurada.${COLOR_RESET}"
    echo -e "${COLOR_YELLOW}Pressione SHIFT + F5 no seu navegador para carregar o painel limpo.${COLOR_RESET}"
    echo ""
    read -p "Pressione ENTER para continuar..."
    webui_sensors_menu
}
