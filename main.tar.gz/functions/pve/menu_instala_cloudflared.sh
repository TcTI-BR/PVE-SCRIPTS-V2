#!/bin/bash

# Menu de instalação e configuração do Cloudflared

# Função auxiliar para verificar se cloudflared está instalado
cloudflared_check_installed() {
    if command -v cloudflared &> /dev/null; then
        return 0  # Instalado
    else
        return 1  # Não instalado
    fi
}

# Função auxiliar para verificar se o serviço está configurado
cloudflared_check_service() {
    if systemctl is-enabled cloudflared &> /dev/null; then
        return 0  # Serviço configurado
    else
        return 1  # Serviço não configurado
    fi
}

# Função para instalar cloudflared
cloudflared_install() {
    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}"
    echo -e "╔═════════════════════════════════════════════════════════════════════╗"
    ui_print_header_line "" "" 69
    ui_print_header_line "☁️  Instalação do Cloudflare Tunnel" "${COLOR_WHITE}" 69
    ui_print_header_line "" "" 69
    echo -e "╚═════════════════════════════════════════════════════════════════════╝"
    echo -e "${COLOR_RESET}"
    echo ""
    
    echo -e "${COLOR_YELLOW}${SYMBOL_LOADING} Iniciando instalação do Cloudflared...${COLOR_RESET}"
    echo ""
    
    # Cria diretório para as chaves
    echo -e "${COLOR_BLUE}${SYMBOL_INFO} Criando diretório de chaves...${COLOR_RESET}"
    mkdir -p --mode=0755 /usr/share/keyrings
    
    # Baixa a chave GPG do Cloudflare
    echo -e "${COLOR_BLUE}${SYMBOL_INFO} Baixando chave GPG do Cloudflare...${COLOR_RESET}"
    curl -fsSL https://pkg.cloudflare.com/cloudflare-public-v2.gpg | tee /usr/share/keyrings/cloudflare-public-v2.gpg >/dev/null
    
    # Adiciona o repositório
    echo -e "${COLOR_BLUE}${SYMBOL_INFO} Adicionando repositório...${COLOR_RESET}"
    echo 'deb [signed-by=/usr/share/keyrings/cloudflare-public-v2.gpg] https://pkg.cloudflare.com/cloudflared any main' | tee /etc/apt/sources.list.d/cloudflared.list
    
    # Atualiza e instala
    echo -e "${COLOR_BLUE}${SYMBOL_INFO} Atualizando lista de pacotes...${COLOR_RESET}"
    apt-get update
    
    echo -e "${COLOR_BLUE}${SYMBOL_INFO} Instalando cloudflared...${COLOR_RESET}"
    apt-get install cloudflared -y
    
    if cloudflared_check_installed; then
        echo ""
        echo -e "${COLOR_GREEN}${SYMBOL_CHECK} Cloudflared instalado com sucesso!${COLOR_RESET}"
    else
        echo ""
        echo -e "${COLOR_RED}${SYMBOL_ERROR} Erro na instalação do Cloudflared!${COLOR_RESET}"
    fi
    
    echo ""
    read -p "${LANG_PVE_PRESS_ENTER:-Pressione ENTER para continuar...}"
    instala_cloudflared_menu
}

# Função para configurar o serviço
cloudflared_configure_service() {
    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}"
    echo -e "╔═════════════════════════════════════════════════════════════════════╗"
    ui_print_header_line "" "" 69
    ui_print_header_line "🔧 Configuração do Serviço Cloudflare Tunnel" "${COLOR_WHITE}" 69
    ui_print_header_line "" "" 69
    echo -e "╚═════════════════════════════════════════════════════════════════════╝"
    echo -e "${COLOR_RESET}"
    echo ""
    
    echo -e "${COLOR_YELLOW}Para configurar o túnel, você precisa da chave fornecida pelo Cloudflare.${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_WHITE}A chave tem este formato:${COLOR_RESET}"
    echo -e "${COLOR_GRAY}eyJhIjoiNzk5M2ExZGQxMmEzNGY5NGE4YzUyNTEyODYwNjU0ZjQiLCJ0IjoiM...${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${COLOR_RESET}"
    echo ""
    
    echo -e "${COLOR_WHITE}Cole a chave do túnel:${COLOR_RESET}"
    read -p "→ " TUNNEL_TOKEN
    
    if [ -z "$TUNNEL_TOKEN" ]; then
        echo ""
        echo -e "${COLOR_RED}${SYMBOL_ERROR} Chave não pode estar vazia!${COLOR_RESET}"
        sleep 2
        instala_cloudflared_menu
        return
    fi
    
    echo ""
    echo -e "${COLOR_YELLOW}${SYMBOL_LOADING} Configurando serviço...${COLOR_RESET}"
    echo ""
    
    # Para e desinstala o serviço se estiver configurado
    if cloudflared_check_service; then
        echo -e "${COLOR_BLUE}${SYMBOL_INFO} Parando serviço existente...${COLOR_RESET}"
        systemctl stop cloudflared 2>/dev/null
        echo -e "${COLOR_BLUE}${SYMBOL_INFO} Desinstalando serviço anterior...${COLOR_RESET}"
        cloudflared service uninstall >/dev/null 2>&1
    fi
    
    # Remove configuração antiga do serviço (garantia)
    if [ -f /etc/systemd/system/cloudflared.service ]; then
        echo -e "${COLOR_BLUE}${SYMBOL_INFO} Limpando configuração anterior...${COLOR_RESET}"
        rm -f /etc/systemd/system/cloudflared.service
    fi
    
    # Recarrega o systemd
    systemctl daemon-reload 2>/dev/null
    
    # Instala o serviço com a nova chave
    echo -e "${COLOR_BLUE}${SYMBOL_INFO} Instalando nova configuração...${COLOR_RESET}"
    cloudflared service install $TUNNEL_TOKEN >/dev/null 2>&1
    
    if cloudflared_check_service; then
        # Inicia o serviço
        echo -e "${COLOR_BLUE}${SYMBOL_INFO} Iniciando serviço...${COLOR_RESET}"
        systemctl start cloudflared 2>/dev/null
        sleep 2
        
        # Verifica se está rodando
        if systemctl is-active cloudflared &> /dev/null; then
            echo ""
            echo -e "${COLOR_GREEN}${SYMBOL_CHECK} Serviço configurado com sucesso!${COLOR_RESET}"
            echo -e "${COLOR_GREEN}${SYMBOL_CHECK} O túnel está ativo e iniciará automaticamente no boot.${COLOR_RESET}"
        else
            echo ""
            echo -e "${COLOR_YELLOW}${SYMBOL_INFO} Serviço configurado, mas não está ativo.${COLOR_RESET}"
            echo -e "${COLOR_YELLOW}${SYMBOL_INFO} Verifique os logs: ${COLOR_WHITE}journalctl -u cloudflared${COLOR_RESET}"
        fi
    else
        echo ""
        echo -e "${COLOR_RED}${SYMBOL_ERROR} Erro ao configurar o serviço!${COLOR_RESET}"
    fi
    
    echo ""
    read -p "${LANG_PVE_PRESS_ENTER:-Pressione ENTER para continuar...}"
    instala_cloudflared_menu
}

# Função para remover cloudflared
cloudflared_remove() {
    clear
    echo -e "${COLOR_RED}${COLOR_BOLD}"
    echo -e "╔═════════════════════════════════════════════════════════════════════╗"
    ui_print_header_line "" "" 69
    ui_print_header_line "⚠️  Remover Cloudflare Tunnel" "${COLOR_WHITE}" 69
    ui_print_header_line "" "" 69
    echo -e "╚═════════════════════════════════════════════════════════════════════╝"
    echo -e "${COLOR_RESET}"
    echo ""
    
    echo -e "${COLOR_YELLOW}${COLOR_BOLD}ATENÇÃO:${COLOR_RESET}"
    echo -e "${COLOR_YELLOW}• Isso removerá completamente o Cloudflared do sistema${COLOR_RESET}"
    echo -e "${COLOR_YELLOW}• O serviço será parado e desabilitado${COLOR_RESET}"
    echo -e "${COLOR_YELLOW}• Você precisará reinstalar para usar novamente${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${COLOR_RESET}"
    echo ""
    
    echo -e "${COLOR_RED}${COLOR_BOLD}Confirmar remoção?${COLOR_RESET} (${COLOR_GREEN}s${COLOR_RESET}/${COLOR_RED}n${COLOR_RESET})"
    read -p "→ " CONFIRM
    
    if [[ "$CONFIRM" =~ ^[Ss]$ ]]; then
        echo ""
        echo -e "${COLOR_YELLOW}${SYMBOL_LOADING} Removendo Cloudflared...${COLOR_RESET}"
        echo ""
        
        # Para e desinstala o serviço se estiver configurado
        if cloudflared_check_service; then
            echo -e "${COLOR_BLUE}${SYMBOL_INFO} Parando serviço...${COLOR_RESET}"
            systemctl stop cloudflared 2>/dev/null
            echo -e "${COLOR_BLUE}${SYMBOL_INFO} Desinstalando serviço...${COLOR_RESET}"
            cloudflared service uninstall >/dev/null 2>&1
        fi
        
        # Remove o arquivo de serviço systemd (garantia)
        echo -e "${COLOR_BLUE}${SYMBOL_INFO} Limpando configuração do serviço...${COLOR_RESET}"
        rm -f /etc/systemd/system/cloudflared.service
        
        # Recarrega o systemd
        systemctl daemon-reload 2>/dev/null
        
        # Remove o pacote
        echo -e "${COLOR_BLUE}${SYMBOL_INFO} Removendo pacote...${COLOR_RESET}"
        apt purge cloudflared -y >/dev/null 2>&1
        
        # Remove o repositório
        echo -e "${COLOR_BLUE}${SYMBOL_INFO} Removendo repositório...${COLOR_RESET}"
        rm -f /etc/apt/sources.list.d/cloudflared.list
        
        echo ""
        echo -e "${COLOR_GREEN}${SYMBOL_CHECK} Cloudflared removido com sucesso!${COLOR_RESET}"
    else
        echo ""
        echo -e "${COLOR_YELLOW}${SYMBOL_INFO} Remoção cancelada.${COLOR_RESET}"
    fi
    
    echo ""
    read -p "${LANG_PVE_PRESS_ENTER:-Pressione ENTER para continuar...}"
    instala_cloudflared_menu
}

# Menu principal
instala_cloudflared_menu() {
    clear
    
    echo -e "${COLOR_CYAN}${COLOR_BOLD}"
    echo -e "╔═════════════════════════════════════════════════════════════════════╗"
    echo -e "║                 ☁️  ${LANG_CF_MENU_TITLE:-Túnel Reverso Cloudflare}                         ║"
    ui_print_header_line "" "" 69
    echo -e "╚═════════════════════════════════════════════════════════════════════╝"
    echo -e "${COLOR_RESET}"
    echo ""
    
    # Status da instalação
    echo -e "${COLOR_BOLD}  ${LANG_ZABBIX_MENU_STATUS_TITLE:-Status:}${COLOR_RESET}"
    echo ""
    if cloudflared_check_installed; then
        CF_VERSION=$(cloudflared --version 2>/dev/null | awk '{print $3}')
        echo -e "  ${COLOR_GREEN}${SYMBOL_CHECK} ${LANG_CF_MENU_STATUS_INSTALLED:-Cloudflared instalado} ${COLOR_GRAY}(v$CF_VERSION)${COLOR_RESET}"
        
        if cloudflared_check_service; then
            if systemctl is-active cloudflared &> /dev/null; then
                echo -e "  ${COLOR_GREEN}${SYMBOL_CHECK} ${LANG_CF_MENU_STATUS_RUNNING:-Serviço ativo e rodando}${COLOR_RESET}"
            else
                echo -e "  ${COLOR_YELLOW}${SYMBOL_INFO} ${LANG_CF_MENU_STATUS_STOPPED:-Serviço configurado mas não está rodando}${COLOR_RESET}"
            fi
        else
            echo -e "  ${COLOR_YELLOW}${SYMBOL_INFO} ${LANG_CF_MENU_STATUS_NOT_CONFIGURED:-Serviço não configurado}${COLOR_RESET}"
        fi
    else
        echo -e "  ${COLOR_RED}${SYMBOL_ERROR} ${LANG_CF_MENU_STATUS_NOT_INSTALLED:-Cloudflared não instalado}${COLOR_RESET}"
    fi
    
    echo ""
    echo -e "${COLOR_CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_BOLD}  ${LANG_SELECT_OPT:-Selecione uma opção:}${COLOR_RESET}"
    echo ""
    echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    
    # Opção 1 - Instalar (desabilitada se já instalado)
    if cloudflared_check_installed; then
        ui_print_menu_item "1" "${LANG_CF_MENU_OPT_1} ${LANG_ZABBIX_MENU_ALREADY_INSTALLED:-(já instalado)}" "${COLOR_GRAY}"
    else
        ui_print_menu_item "1" "${LANG_CF_MENU_OPT_1}" "${COLOR_YELLOW}"
    fi
    
    # Opção 2 - Configurar serviço (requer instalação)
    if cloudflared_check_installed; then
        ui_print_menu_item "2" "${LANG_CF_MENU_OPT_2}" "${COLOR_YELLOW}"
    else
        ui_print_menu_item "2" "${LANG_CF_MENU_OPT_2} ${LANG_ZABBIX_MENU_REQ_INSTALL:-(requer instalação)}" "${COLOR_GRAY}"
    fi
    
    # Opção 3 - Remover (requer instalação)
    if cloudflared_check_installed; then
        ui_print_menu_item "3" "${LANG_CF_MENU_OPT_3}" "${COLOR_YELLOW}"
    else
        ui_print_menu_item "3" "${LANG_CF_MENU_OPT_3} ${LANG_ZABBIX_MENU_REQ_INSTALL:-(requer instalação)}" "${COLOR_GRAY}"
    fi
    
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    
    ui_print_menu_item "0" "${LANG_VM_OP_OPT_0:-Voltar}" "${COLOR_RED}"
    
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_YELLOW}  ${LANG_TYPE_OPT:-Digite sua opção} ${COLOR_GRAY}${LANG_PRESS_ENTER:-(ou pressione ENTER para sair)}${COLOR_YELLOW}: ${COLOR_RESET}"
    read -rsn1 opt
    
    while [ opt != '' ]
    do
        if [[ $opt = "" ]]; then
            instala_aplicativos_menu
        else
            case $opt in
                1)
                    if cloudflared_check_installed; then
                        clear
                        echo -e "${COLOR_YELLOW}${SYMBOL_INFO} Cloudflared já está instalado!${COLOR_RESET}"
                        sleep 2
                        instala_cloudflared_menu
                    else
                        clear
                        cloudflared_install
                    fi
                    ;;
                2)
                    if cloudflared_check_installed; then
                        clear
                        cloudflared_configure_service
                    else
                        clear
                        echo -e "${COLOR_RED}${SYMBOL_ERROR} Você precisa instalar o Cloudflared primeiro!${COLOR_RESET}"
                        sleep 2
                        instala_cloudflared_menu
                    fi
                    ;;
                3)
                    if cloudflared_check_installed; then
                        clear
                        cloudflared_remove
                    else
                        clear
                        echo -e "${COLOR_RED}${SYMBOL_ERROR} Cloudflared não está instalado!${COLOR_RESET}"
                        sleep 2
                        instala_cloudflared_menu
                    fi
                    ;;
                0)
                    clear
                    instala_aplicativos_menu
                    ;;
                *)
                    clear
                    instala_aplicativos_menu
                    ;;
            esac
        fi
    done
}


