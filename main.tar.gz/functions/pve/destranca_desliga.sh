#!/bin/bash

# Função para destrancar, desligar e reiniciar VMs

destranca_desliga(){
	clear
	NORMAL=`echo "\033[m"`
	MENU=`echo "\033[36m"`
	NUMBER=`echo "\033[33m"`
	FGRED=`echo "\033[41m"`
	RED_TEXT=`echo "\033[31m"`
	ENTER_LINE=`echo "\033[33m"`
	
	echo -e "${COLOR_CYAN}${COLOR_BOLD}"
	echo -e "╔═════════════════════════════════════════════════════════════════════╗"
	ui_print_header_line "" "" 69
	ui_print_header_line "🔓 ${LANG_UNLOCK_MENU_TITLE:-Destranca, Desliga e Reinicia VM}" "${COLOR_WHITE}" 69
	ui_print_header_line "" "" 69
	echo -e "╚═════════════════════════════════════════════════════════════════════╝"
	echo -e "${COLOR_RESET}"
	echo ""
	echo -e "${COLOR_BOLD}  ${LANG_SELECT_OPT:-Selecione uma opção:}${COLOR_RESET}"
	echo ""
	echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
	
	ui_print_menu_item "1" "${LANG_UNLOCK_MENU_OPT_1}" "${COLOR_YELLOW}"
	ui_print_menu_item "2" "${LANG_UNLOCK_MENU_OPT_2}" "${COLOR_YELLOW}"
	ui_print_menu_item "3" "${LANG_UNLOCK_MENU_OPT_3}" "${COLOR_YELLOW}"
	
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	
	ui_print_menu_item "0" "${LANG_VM_OP_OPT_0:-Voltar}" "${COLOR_RED}"
	
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
	echo ""
	echo -e "${COLOR_YELLOW}  ${LANG_TYPE_OPT:-Digite sua opção} ${COLOR_GRAY}${LANG_PRESS_ENTER:-(ou pressione ENTER para sair)}${COLOR_YELLOW}: ${COLOR_RESET}"
	read -rsn1 opt
	while [ opt != '' ]	
	do
		if [[ $opt = "" ]]; then
			exit;
		else
			case $opt in
				1) clear;
				echo "Qual ID da VM? EX: 230"
				read DESTRANCAVM
				rm /var/lock/qemu-server/lock-$DESTRANCAVM.conf
				qm unlock $DESTRANCAVM
				echo "VM destrancada com sucesso!"
				read -p "Pressione uma tecla para continuar..."
				clear	  
				destranca_desliga
					;;
				2) clear;
				echo "Qual ID da VM? EX: 230"
				read DESTRANCADESLIGAVM
				rm /var/lock/qemu-server/lock-$DESTRANCADESLIGAVM.conf
				qm unlock $DESTRANCADESLIGAVM
				sleep 10
				qm stop $DESTRANCADESLIGAVM
				sleep 5
				echo "VM destrancada e desligada com sucesso!"
				read -p "Pressione uma tecla para continuar..."
				clear
				destranca_desliga	
					;;
				3) clear;
				echo "Qual ID da VM? EX: 230"
				read DESTRANCADESLIGAREINICIAVM
				rm /var/lock/qemu-server/lock-$DESTRANCADESLIGAREINICIAVM.conf
				qm unlock $DESTRANCADESLIGAREINICIAVM
				sleep 10
				qm stop $DESTRANCADESLIGAREINICIAVM
				sleep 5
				qm start $DESTRANCADESLIGAREINICIAVM
				sleep 2
				echo "VM destrancada, desligada e reiniciada!"
				read -p "Pressione uma tecla para continuar..."
				clear
				destranca_desliga	
					;;
				0) clear;
				vm_operations_menu;
					;;
				*) clear
				vm_operations_menu;
					;;			
			esac
		fi
	done
	destranca_desliga
}

