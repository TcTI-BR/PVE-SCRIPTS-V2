#!/bin/bash

# Verificador de Configurações de VMs e Containers usando IA
# Versão: V003.R004
# Adicionado em: 2025-11-17
# Atualizado em: 2025-11-18
# Melhorias: 
#   - Diagnóstico detalhado de diretórios e melhor tratamento de erros
#   - Substituído 'find' por 'glob patterns' (compatível com FUSE filesystem do Proxmox)
#   - Adicionado modo DEBUG para diagnóstico 

# Arquivo onde a chave está armazenada
OPENAI_KEY_FILE="/root/.openai_key"

# Diretórios padrão do Proxmox
QEMU_DIR="/etc/pve/qemu-server"
LXC_DIR="/etc/pve/lxc"

# Debug mode (descomente para ativar logs detalhados)
# DEBUG_MODE=1

AI_CONFIG_FILE="/root/.ai_config"

# Função para verificar se existe chave de IA cadastrada (.ai_config ou .openai_key)
check_openai_key() {
	if [ -f "$AI_CONFIG_FILE" ]; then
		return 0
	elif [ -f "$OPENAI_KEY_FILE" ]; then
		return 0
	else
		echo -e "${COLOR_RED}  ✗ Nenhuma Chave de IA configurada!${COLOR_RESET}"
		echo -e "${COLOR_YELLOW}  Por favor, cadastre uma chave no Assistente de IA (Menu 3 -> Opção 6).${COLOR_RESET}"
		echo ""
		read -p "  Pressione ENTER para voltar..."
		return 1
	fi
}


# Função para enviar a análise para a API de IA configurada
analyze_with_openai() {
	local config_content="$1"
	local vm_type="$2"
	local vm_id="$3"
	
	local ai_prov="openai"
	local ai_mod="gpt-4o-mini"
	local ai_k=""

	if [ -f "$AI_CONFIG_FILE" ]; then
		source "$AI_CONFIG_FILE"
		ai_prov="$AI_PROVIDER"
		ai_mod="$AI_MODEL"
		ai_k="$AI_KEY"
	elif [ -f "$OPENAI_KEY_FILE" ]; then
		ai_k=$(cat "$OPENAI_KEY_FILE")
	fi

	if [ -z "$ai_k" ]; then
		echo "Erro: Nenhuma chave de IA válida encontrada."
		return 1
	fi
	
	local prompt="Você é um especialista em Proxmox VE. Analise a seguinte configuração de $vm_type (ID: $vm_id) e forneça:

1. ERROS CRÍTICOS: Identifique problemas que podem causar falhas
2. AVISOS: Configurações que podem causar problemas de performance
3. MELHORIAS SUGERIDAS: Otimizações recomendadas
4. BOAS PRÁTICAS: Se a configuração segue as melhores práticas

Configuração:
\`\`\`
$config_content
\`\`\`

Formato da resposta:
- Use emojis para destacar (🔴 erros, ⚠️ avisos, ✅ ok, 💡 sugestões)
- Seja objetivo e técnico
- Priorize os problemas mais importantes"

	local response=""
	local http_code=""
	local body=""

	if [ "$ai_prov" = "gemini" ]; then
		local json_payload=$(jq -n --arg sys "Você é um especialista em Proxmox VE com profundo conhecimento de virtualização e containers." --arg prompt "$prompt" '{
			systemInstruction: { parts: [{ text: $sys }] },
			contents: [{ parts: [{ text: $prompt }] }]
		}')
		response=$(curl -s -w "\n%{http_code}" -X POST "https://generativelanguage.googleapis.com/v1beta/models/${ai_mod}:generateContent?key=${ai_k}" \
			-H "Content-Type: application/json" \
			-d "$json_payload" 2>&1)
		http_code=$(echo "$response" | tail -n1)
		body=$(echo "$response" | head -n-1)
		if [ "$http_code" = "200" ]; then
			local text=$(echo "$body" | jq -r '.candidates[0].content.parts[0].text' 2>/dev/null)
			if [ -n "$text" ] && [ "$text" != "null" ]; then
				echo "$text"
				return 0
			fi
		fi
	elif [ "$ai_prov" = "claude" ]; then
		local json_payload=$(jq -n --arg mod "$ai_mod" --arg prompt "$prompt" '{
			model: $mod,
			max_tokens: 2000,
			messages: [{ role: "user", content: $prompt }]
		}')
		response=$(curl -s -w "\n%{http_code}" -X POST "https://api.anthropic.com/v1/messages" \
			-H "x-api-key: $ai_k" \
			-H "anthropic-version: 2023-06-01" \
			-H "Content-Type: application/json" \
			-d "$json_payload" 2>&1)
		http_code=$(echo "$response" | tail -n1)
		body=$(echo "$response" | head -n-1)
		if [ "$http_code" = "200" ]; then
			local text=$(echo "$body" | jq -r '.content[0].text' 2>/dev/null)
			if [ -n "$text" ] && [ "$text" != "null" ]; then
				echo "$text"
				return 0
			fi
		fi
	else
		# OpenAI padrão
		local json_prompt=$(echo "$prompt" | jq -Rs .)
		local json_data=$(cat <<EOF
{
  "model": "$ai_mod",
  "messages": [
    {
      "role": "system",
      "content": "Você é um especialista em Proxmox VE com profundo conhecimento de virtualização, containers LXC, e otimização de recursos."
    },
    {
      "role": "user",
      "content": $json_prompt
    }
  ],
  "temperature": 0.3,
  "max_tokens": 2000
}
EOF
)
		response=$(curl -s -w "\n%{http_code}" -X POST \
			-H "Content-Type: application/json" \
			-H "Authorization: Bearer $ai_k" \
			-d "$json_data" \
			"https://api.openai.com/v1/chat/completions" 2>&1)
		http_code=$(echo "$response" | tail -n1)
		body=$(echo "$response" | head -n-1)
		if [ "$http_code" = "200" ]; then
			local ai_response=$(echo "$body" | jq -r '.choices[0].message.content' 2>/dev/null)
			if [ -n "$ai_response" ] && [ "$ai_response" != "null" ]; then
				echo "$ai_response"
				return 0
			fi
		fi
	fi

	echo "Erro ao comunicar com a API da IA ($ai_prov - Código HTTP: $http_code)"
	return 1
}

vm_config_checker(){
	clear
	
	echo -e "${COLOR_CYAN}${COLOR_BOLD}"
	echo -e "╔═════════════════════════════════════════════════════════════════════╗"
	echo -e "║                                                                     ║"
	echo -e "║         🔍 Verificação de Configurações com IA                       ║"
	echo -e "║                                                                     ║"
	echo -e "╚═════════════════════════════════════════════════════════════════════╝"
	echo -e "${COLOR_RESET}"
	echo ""
	
	# Verifica se a chave OpenAI existe
	if ! check_openai_key; then
		return
	fi
	
	echo -e "${COLOR_YELLOW}  🔎 Buscando VMs e Containers...${COLOR_RESET}"
	echo ""
	
	# Verificação de ambiente e diretórios
	local qemu_exists=0
	local lxc_exists=0
	local qemu_readable=0
	local lxc_readable=0
	
	if [ -d "$QEMU_DIR" ]; then
		qemu_exists=1
		if [ -r "$QEMU_DIR" ]; then
			qemu_readable=1
		fi
	fi
	
	if [ -d "$LXC_DIR" ]; then
		lxc_exists=1
		if [ -r "$LXC_DIR" ]; then
			lxc_readable=1
		fi
	fi
	
	# Debug: Mostra status dos diretórios
	echo -e "${COLOR_CYAN}  📁 Status dos diretórios:${COLOR_RESET}"
	if [ $qemu_exists -eq 1 ]; then
		if [ $qemu_readable -eq 1 ]; then
			echo -e "    ${COLOR_GREEN}✓${COLOR_RESET} ${COLOR_WHITE}VMs:${COLOR_RESET} ${QEMU_DIR} ${COLOR_GREEN}(acessível)${COLOR_RESET}"
		else
			echo -e "    ${COLOR_RED}✗${COLOR_RESET} ${COLOR_WHITE}VMs:${COLOR_RESET} ${QEMU_DIR} ${COLOR_RED}(sem permissão)${COLOR_RESET}"
		fi
	else
		echo -e "    ${COLOR_RED}✗${COLOR_RESET} ${COLOR_WHITE}VMs:${COLOR_RESET} ${QEMU_DIR} ${COLOR_RED}(não existe)${COLOR_RESET}"
	fi
	
	if [ $lxc_exists -eq 1 ]; then
		if [ $lxc_readable -eq 1 ]; then
			echo -e "    ${COLOR_GREEN}✓${COLOR_RESET} ${COLOR_WHITE}Containers:${COLOR_RESET} ${LXC_DIR} ${COLOR_GREEN}(acessível)${COLOR_RESET}"
		else
			echo -e "    ${COLOR_RED}✗${COLOR_RESET} ${COLOR_WHITE}Containers:${COLOR_RESET} ${LXC_DIR} ${COLOR_RED}(sem permissão)${COLOR_RESET}"
		fi
	else
		echo -e "    ${COLOR_RED}✗${COLOR_RESET} ${COLOR_WHITE}Containers:${COLOR_RESET} ${LXC_DIR} ${COLOR_RED}(não existe)${COLOR_RESET}"
	fi
	echo ""
	
	# Busca arquivos de VMs usando glob (mais compatível com /etc/pve/ FUSE filesystem)
	local vm_files=()
	if [ $qemu_exists -eq 1 ] && [ $qemu_readable -eq 1 ]; then
		[ -n "$DEBUG_MODE" ] && echo -e "${COLOR_GRAY}  [DEBUG] Procurando VMs em: $QEMU_DIR${COLOR_RESET}"
		
		# Usa glob pattern que funciona melhor com filesystem FUSE do Proxmox
		shopt -s nullglob  # Evita retornar o pattern literal se não houver matches
		for file in "$QEMU_DIR"/*.conf "$QEMU_DIR"/*/*.conf; do
			[ -f "$file" ] || continue
			local basename=$(basename "$file")
			[ -n "$DEBUG_MODE" ] && echo -e "${COLOR_GRAY}  [DEBUG] Encontrado: $file (basename: $basename)${COLOR_RESET}"
			
			# Aceita arquivos .conf que começam com números (padrão Proxmox)
			if [[ $basename =~ ^[0-9]+\.conf$ ]]; then
				vm_files+=("$file")
				[ -n "$DEBUG_MODE" ] && echo -e "${COLOR_GRAY}  [DEBUG] ✓ Adicionado: $file${COLOR_RESET}"
			fi
		done
		shopt -u nullglob
		
		[ -n "$DEBUG_MODE" ] && echo -e "${COLOR_GRAY}  [DEBUG] Total de VMs encontradas: ${#vm_files[@]}${COLOR_RESET}"
	fi
	
	# Busca arquivos de Containers usando glob (mais compatível com /etc/pve/ FUSE filesystem)
	local ct_files=()
	if [ $lxc_exists -eq 1 ] && [ $lxc_readable -eq 1 ]; then
		[ -n "$DEBUG_MODE" ] && echo -e "${COLOR_GRAY}  [DEBUG] Procurando Containers em: $LXC_DIR${COLOR_RESET}"
		
		# Usa glob pattern que funciona melhor com filesystem FUSE do Proxmox
		shopt -s nullglob  # Evita retornar o pattern literal se não houver matches
		for file in "$LXC_DIR"/*.conf "$LXC_DIR"/*/*.conf; do
			[ -f "$file" ] || continue
			local basename=$(basename "$file")
			[ -n "$DEBUG_MODE" ] && echo -e "${COLOR_GRAY}  [DEBUG] Encontrado: $file (basename: $basename)${COLOR_RESET}"
			
			# Aceita arquivos .conf que começam com números (padrão Proxmox)
			if [[ $basename =~ ^[0-9]+\.conf$ ]]; then
				ct_files+=("$file")
				[ -n "$DEBUG_MODE" ] && echo -e "${COLOR_GRAY}  [DEBUG] ✓ Adicionado: $file${COLOR_RESET}"
			fi
		done
		shopt -u nullglob
		
		[ -n "$DEBUG_MODE" ] && echo -e "${COLOR_GRAY}  [DEBUG] Total de Containers encontrados: ${#ct_files[@]}${COLOR_RESET}"
	fi
	
	local total_vms=${#vm_files[@]}
	local total_cts=${#ct_files[@]}
	local total=$((total_vms + total_cts))
	
	if [ $total -eq 0 ]; then
		echo -e "${COLOR_RED}  ✗ Nenhuma VM ou Container encontrado${COLOR_RESET}"
		echo ""
		
		# Diagnóstico adicional
		if [ $qemu_exists -eq 0 ] && [ $lxc_exists -eq 0 ]; then
			echo -e "${COLOR_YELLOW}  💡 Possíveis causas:${COLOR_RESET}"
			echo -e "    ${COLOR_WHITE}• Não está num servidor Proxmox VE${COLOR_RESET}"
			echo -e "    ${COLOR_WHITE}• O filesystem /etc/pve/ não está montado${COLOR_RESET}"
			echo ""
			echo -e "${COLOR_CYAN}  🔧 Comandos de diagnóstico:${COLOR_RESET}"
			echo -e "    ${COLOR_GRAY}pvesh get /version${COLOR_RESET}"
			echo -e "    ${COLOR_GRAY}pvesm status${COLOR_RESET}"
			echo -e "    ${COLOR_GRAY}mount | grep pve${COLOR_RESET}"
		elif [ $qemu_readable -eq 0 ] || [ $lxc_readable -eq 0 ]; then
			echo -e "${COLOR_YELLOW}  💡 Possível causa:${COLOR_RESET}"
			echo -e "    ${COLOR_WHITE}• Sem permissões de acesso aos diretórios${COLOR_RESET}"
			echo ""
			echo -e "${COLOR_CYAN}  🔧 Solução:${COLOR_RESET}"
			echo -e "    ${COLOR_GRAY}Execute o script como root ou com sudo${COLOR_RESET}"
		else
			echo -e "${COLOR_YELLOW}  💡 Informação:${COLOR_RESET}"
			echo -e "    ${COLOR_WHITE}• Os diretórios existem mas não há VMs/Containers configurados${COLOR_RESET}"
			echo -e "    ${COLOR_WHITE}• Crie VMs ou Containers primeiro no Proxmox${COLOR_RESET}"
		fi
		
		echo ""
		read -p "  Pressione ENTER para voltar..."
		return
	fi
	
	echo -e "${COLOR_GREEN}  ✓ Encontrados:${COLOR_RESET}"
	echo -e "    ${COLOR_WHITE}VMs: ${COLOR_YELLOW}${total_vms}${COLOR_RESET}"
	echo -e "    ${COLOR_WHITE}Containers: ${COLOR_YELLOW}${total_cts}${COLOR_RESET}"
	echo ""
	
	# Lista as VMs encontradas
	if [ $total_vms -gt 0 ]; then
		echo -e "${COLOR_CYAN}  📦 VMs encontradas:${COLOR_RESET}"
		for vm_file in "${vm_files[@]}"; do
			local vm_id=$(basename "$vm_file" .conf)
			local vm_name=$(grep "^name:" "$vm_file" 2>/dev/null | cut -d' ' -f2)
			if [ -n "$vm_name" ]; then
				echo -e "    ${COLOR_GRAY}•${COLOR_RESET} VM ${COLOR_YELLOW}${vm_id}${COLOR_RESET} - ${COLOR_WHITE}${vm_name}${COLOR_RESET}"
			else
				echo -e "    ${COLOR_GRAY}•${COLOR_RESET} VM ${COLOR_YELLOW}${vm_id}${COLOR_RESET}"
			fi
		done
		echo ""
	fi
	
	# Lista os Containers encontrados
	if [ $total_cts -gt 0 ]; then
		echo -e "${COLOR_CYAN}  📦 Containers encontrados:${COLOR_RESET}"
		for ct_file in "${ct_files[@]}"; do
			local ct_id=$(basename "$ct_file" .conf)
			local ct_name=$(grep "^hostname:" "$ct_file" 2>/dev/null | cut -d' ' -f2)
			if [ -n "$ct_name" ]; then
				echo -e "    ${COLOR_GRAY}•${COLOR_RESET} CT ${COLOR_YELLOW}${ct_id}${COLOR_RESET} - ${COLOR_WHITE}${ct_name}${COLOR_RESET}"
			else
				echo -e "    ${COLOR_GRAY}•${COLOR_RESET} CT ${COLOR_YELLOW}${ct_id}${COLOR_RESET}"
			fi
		done
		echo ""
	fi
	
	echo -e "${COLOR_BOLD}  Selecione uma opção:${COLOR_RESET}"
	echo ""
	echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}1${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}Verificar TODAS as VMs e Containers${COLOR_RESET}                     ${COLOR_CYAN}│${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}2${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}Verificar uma VM/Container específico${COLOR_RESET}                   ${COLOR_CYAN}│${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_RED}0${COLOR_RESET} ${COLOR_RED}➜${COLOR_RESET}  ${COLOR_WHITE}Voltar${COLOR_RESET}                                                  ${COLOR_CYAN}│${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
	echo ""
	echo -e "${COLOR_YELLOW}  Digite sua opção: ${COLOR_RESET}"
	read -rsn1 opt
	
	case $opt in
		1)
			clear
			echo -e "${COLOR_CYAN}${COLOR_BOLD}"
			echo -e "╔═════════════════════════════════════════════════════════════════════╗"
			echo -e "║            🤖 Verificação Completa com IA                           ║"
			echo -e "╚═════════════════════════════════════════════════════════════════════╝"
			echo -e "${COLOR_RESET}"
			echo ""
			echo -e "${COLOR_YELLOW}  Analisando ${total} VMs/Containers...${COLOR_RESET}"
			echo ""
			
			local processed=0
			local errors=0
			
			# Processa VMs
			for vm_file in "${vm_files[@]}"; do
				processed=$((processed + 1))
				local vm_id=$(basename "$vm_file" .conf)
				local vm_name=$(grep "^name:" "$vm_file" 2>/dev/null | cut -d' ' -f2)
				
				echo -e "${COLOR_CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${COLOR_RESET}"
				echo -e "${COLOR_BOLD}  📦 VM ${vm_id}${COLOR_RESET}${vm_name:+ - $vm_name} ${COLOR_GRAY}[${processed}/${total}]${COLOR_RESET}"
				echo -e "${COLOR_CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${COLOR_RESET}"
				echo ""
				
				local config_content=$(cat "$vm_file")
				local analysis=$(analyze_with_openai "$config_content" "VM" "$vm_id")
				
				if [ $? -eq 0 ]; then
					echo -e "${COLOR_WHITE}${analysis}${COLOR_RESET}"
				else
					echo -e "${COLOR_RED}  ✗ Erro ao analisar: ${analysis}${COLOR_RESET}"
					errors=$((errors + 1))
				fi
				
				echo ""
				
				# Pausa entre requisições para evitar rate limit
				if [ $processed -lt $total ]; then
					sleep 2
				fi
			done
			
			# Processa Containers
			for ct_file in "${ct_files[@]}"; do
				processed=$((processed + 1))
				local ct_id=$(basename "$ct_file" .conf)
				local ct_name=$(grep "^hostname:" "$ct_file" 2>/dev/null | cut -d' ' -f2)
				
				echo -e "${COLOR_CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${COLOR_RESET}"
				echo -e "${COLOR_BOLD}  📦 Container ${ct_id}${COLOR_RESET}${ct_name:+ - $ct_name} ${COLOR_GRAY}[${processed}/${total}]${COLOR_RESET}"
				echo -e "${COLOR_CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${COLOR_RESET}"
				echo ""
				
				local config_content=$(cat "$ct_file")
				local analysis=$(analyze_with_openai "$config_content" "Container" "$ct_id")
				
				if [ $? -eq 0 ]; then
					echo -e "${COLOR_WHITE}${analysis}${COLOR_RESET}"
				else
					echo -e "${COLOR_RED}  ✗ Erro ao analisar: ${analysis}${COLOR_RESET}"
					errors=$((errors + 1))
				fi
				
				echo ""
				
				# Pausa entre requisições para evitar rate limit
				if [ $processed -lt $total ]; then
					sleep 2
				fi
			done
			
			echo -e "${COLOR_CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${COLOR_RESET}"
			echo -e "${COLOR_GREEN}  ✓ Verificação concluída!${COLOR_RESET}"
			echo -e "    ${COLOR_WHITE}Analisados: ${COLOR_YELLOW}${processed}${COLOR_RESET}"
			if [ $errors -gt 0 ]; then
				echo -e "    ${COLOR_RED}Erros: ${errors}${COLOR_RESET}"
			fi
			echo -e "${COLOR_CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${COLOR_RESET}"
			echo ""
			read -p "  Pressione ENTER para voltar..."
			vm_config_checker
			;;
		2)
			clear
			echo -e "${COLOR_CYAN}${COLOR_BOLD}"
			echo -e "╔═════════════════════════════════════════════════════════════════════╗"
			echo -e "║          🔍 Verificação Individual com IA                           ║"
			echo -e "╚═════════════════════════════════════════════════════════════════════╝"
			echo -e "${COLOR_RESET}"
			echo ""
			echo -e "${COLOR_WHITE}  Digite o ID da VM ou Container (ex: 100):${COLOR_RESET}"
			read -p "  ID: " target_id
			
			# Remove espaços e valida se é número
			target_id=$(echo "$target_id" | tr -d ' ')
			if ! [[ "$target_id" =~ ^[0-9]+$ ]]; then
				echo ""
				echo -e "${COLOR_RED}  ✗ ID inválido! Use apenas números.${COLOR_RESET}"
				sleep 2
				vm_config_checker
				return
			fi
			
			# Busca o arquivo usando glob (compatível com FUSE filesystem)
			local found=0
			local config_file=""
			local type=""
			
			# Verifica se é VM (primeiro no diretório raiz, depois em subdiretórios)
			if [ -f "$QEMU_DIR/${target_id}.conf" ]; then
				config_file="$QEMU_DIR/${target_id}.conf"
				type="VM"
				found=1
			else
				# Verifica em subpastas usando glob
				shopt -s nullglob
				for file in "$QEMU_DIR"/*/"${target_id}.conf" "$QEMU_DIR"/*/*/"${target_id}.conf"; do
					if [ -f "$file" ]; then
						config_file="$file"
						type="VM"
						found=1
						break
					fi
				done
				shopt -u nullglob
			fi
			
			# Se não encontrou como VM, verifica se é Container
			if [ $found -eq 0 ]; then
				if [ -f "$LXC_DIR/${target_id}.conf" ]; then
					config_file="$LXC_DIR/${target_id}.conf"
					type="Container"
					found=1
				else
					# Verifica em subpastas usando glob
					shopt -s nullglob
					for file in "$LXC_DIR"/*/"${target_id}.conf" "$LXC_DIR"/*/*/"${target_id}.conf"; do
						if [ -f "$file" ]; then
							config_file="$file"
							type="Container"
							found=1
							break
						fi
					done
					shopt -u nullglob
				fi
			fi
			
			if [ $found -eq 0 ]; then
				echo ""
				echo -e "${COLOR_RED}  ✗ VM/Container ${target_id} não encontrado${COLOR_RESET}"
				sleep 2
				vm_config_checker
				return
			fi
			
			clear
			echo -e "${COLOR_CYAN}${COLOR_BOLD}"
			echo -e "╔═════════════════════════════════════════════════════════════════════╗"
			echo -e "║              🤖 Análise com IA em Progresso                         ║"
			echo -e "╚═════════════════════════════════════════════════════════════════════╝"
			echo -e "${COLOR_RESET}"
			echo ""
			echo -e "${COLOR_YELLOW}  Analisando ${type} ${target_id}...${COLOR_RESET}"
			echo ""
			
			local config_content=$(cat "$config_file")
			local analysis=$(analyze_with_openai "$config_content" "$type" "$target_id")
			
			clear
			echo -e "${COLOR_CYAN}${COLOR_BOLD}"
			echo -e "╔═════════════════════════════════════════════════════════════════════╗"
			echo -e "║            📊 Resultado da Análise - ${type} ${target_id}                           ║"
			echo -e "╚═════════════════════════════════════════════════════════════════════╝"
			echo -e "${COLOR_RESET}"
			echo ""
			
			if [ $? -eq 0 ]; then
				echo -e "${COLOR_WHITE}${analysis}${COLOR_RESET}"
			else
				echo -e "${COLOR_RED}  ✗ Erro ao analisar: ${analysis}${COLOR_RESET}"
			fi
			
			echo ""
			echo -e "${COLOR_CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${COLOR_RESET}"
			read -p "  Pressione ENTER para voltar..."
			vm_config_checker
			;;
		0)
			return
			;;
		*)
			vm_config_checker
			;;
	esac
}

