#!/bin/bash

# Verificador de Configurações de VMs e Containers usando IA
# Versão: V003.R005
# Adicionado em: 2025-11-17
# Atualizado em: 2026-07-24
# Melhorias: 
#   - Diagnóstico detalhado de diretórios e melhor tratamento de erros
#   - Substituído 'find' por 'glob patterns' (compatível com FUSE filesystem do Proxmox)
#   - Adicionado modo DEBUG para diagnóstico
#   - Opções 3 e 4: envio de relatório fracionado via Telegram (Bot de Notificações)

# Arquivo onde a chave está armazenada
OPENAI_KEY_FILE="/root/.openai_key"

# Diretórios padrão do Proxmox
QEMU_DIR="/etc/pve/qemu-server"
LXC_DIR="/etc/pve/lxc"

# Debug mode (descomente para ativar logs detalhados)
# DEBUG_MODE=1

AI_CONFIG_FILE="/root/.ai_config"

# Função para verificar se existe chave de IA cadastrada (.ai_config ou .openai_key)
check_openai_key() {
	if [ -f "$AI_CONFIG_FILE" ]; then
		return 0
	elif [ -f "$OPENAI_KEY_FILE" ]; then
		return 0
	else
		echo -e "${COLOR_RED}  ✗ ${LANG_AUDITOR_NO_KEY:-Nenhuma Chave de IA configurada!}${COLOR_RESET}"
		echo -e "${COLOR_YELLOW}  ${LANG_AUDITOR_REG_KEY:-Por favor, cadastre uma chave no Assistente de IA (Menu 3 -> Opção 6).}${COLOR_RESET}"
		echo ""
		read -p "  ${LANG_AUDITOR_PRESS_BACK:-Pressione ENTER para voltar...}"
		return 1
	fi
}


# Função para enviar a análise para a API de IA configurada
analyze_with_openai() {
	local config_content="$1"
	local vm_type="$2"
	local vm_id="$3"
	
	local ai_prov="openai"
	local ai_mod="gpt-4o-mini"
	local ai_k=""

	if [ -f "$AI_CONFIG_FILE" ]; then
		source "$AI_CONFIG_FILE"
		ai_prov="$AI_PROVIDER"
		ai_mod="$AI_MODEL"
		if [ -n "$AI_ENC_KEY" ]; then
			ai_k=$(echo "$AI_ENC_KEY" | openssl aes-256-cbc -d -a -pbkdf2 -salt -pass pass:"TCTI_PVE_2026" 2>/dev/null || echo "$AI_ENC_KEY" | base64 -d 2>/dev/null)
		else
			ai_k="$AI_KEY"
		fi
	elif [ -f "$OPENAI_KEY_FILE" ]; then
		ai_k=$(cat "$OPENAI_KEY_FILE")
	fi

	if [ -z "$ai_k" ]; then
		echo "${LANG_AUDITOR_ERR_NO_KEY:-Erro: Nenhuma chave de IA válida encontrada.}"
		return 1
	fi
	
	local prompt="Você é um especialista em Proxmox VE. Analise a seguinte configuração de $vm_type (ID: $vm_id) e forneça:

1. ERROS CRÍTICOS: Identifique problemas que podem causar falhas
2. AVISOS: Configurações que podem causar problemas de performance
3. MELHORIAS SUGERIDAS: Otimizações recomendadas
4. BOAS PRÁTICAS: Se a configuração segue as melhores práticas

Configuração:
\`\`\`
$config_content
\`\`\`

Formato da resposta:
- Use emojis para destacar (🔴 erros, ⚠️ avisos, ✅ ok, 💡 sugestões)
- Seja objetivo e técnico
- Priorize os problemas mais importantes"

	local response=""
	local http_code=""
	local body=""

	if [ "$ai_prov" = "gemini" ]; then
		local json_payload=$(jq -n --arg sys "Você é um especialista em Proxmox VE com profundo conhecimento de virtualização e containers." --arg prompt "$prompt" '{
			systemInstruction: { parts: [{ text: $sys }] },
			contents: [{ parts: [{ text: $prompt }] }]
		}')
		response=$(curl -s -w "\n%{http_code}" -X POST "https://generativelanguage.googleapis.com/v1beta/models/${ai_mod}:generateContent?key=${ai_k}" \
			-H "Content-Type: application/json" \
			-d "$json_payload" 2>&1)
		http_code=$(echo "$response" | tail -n1)
		body=$(echo "$response" | head -n-1)
		if [ "$http_code" = "200" ]; then
			local text=$(echo "$body" | jq -r '.candidates[0].content.parts[0].text' 2>/dev/null)
			if [ -n "$text" ] && [ "$text" != "null" ]; then
				echo "$text"
				return 0
			fi
		fi
	elif [ "$ai_prov" = "claude" ]; then
		local json_payload=$(jq -n --arg mod "$ai_mod" --arg prompt "$prompt" '{
			model: $mod,
			max_tokens: 2000,
			messages: [{ role: "user", content: $prompt }]
		}')
		response=$(curl -s -w "\n%{http_code}" -X POST "https://api.anthropic.com/v1/messages" \
			-H "x-api-key: $ai_k" \
			-H "anthropic-version: 2023-06-01" \
			-H "Content-Type: application/json" \
			-d "$json_payload" 2>&1)
		http_code=$(echo "$response" | tail -n1)
		body=$(echo "$response" | head -n-1)
		if [ "$http_code" = "200" ]; then
			local text=$(echo "$body" | jq -r '.content[0].text' 2>/dev/null)
			if [ -n "$text" ] && [ "$text" != "null" ]; then
				echo "$text"
				return 0
			fi
		fi
	else
		# OpenAI padrão
		local json_prompt=$(echo "$prompt" | jq -Rs .)
		local json_data=$(cat <<EOF
{
  "model": "$ai_mod",
  "messages": [
    {
      "role": "system",
      "content": "Você é um especialista em Proxmox VE com profundo conhecimento de virtualização, containers LXC, e otimização de recursos."
    },
    {
      "role": "user",
      "content": $json_prompt
    }
  ],
  "temperature": 0.3,
  "max_tokens": 2000
}
EOF
)
		local endpoint_url="https://api.openai.com/v1/chat/completions"
		if [ "$ai_prov" = "xiaomi" ]; then
			endpoint_url="https://token-plan-sgp.xiaomimimo.com/v1/chat/completions"
		fi

		response=$(curl -s -w "\n%{http_code}" -X POST \
			-H "Content-Type: application/json" \
			-H "Authorization: Bearer $ai_k" \
			-d "$json_data" \
			"$endpoint_url" 2>&1)
		http_code=$(echo "$response" | tail -n1)
		body=$(echo "$response" | head -n-1)
		if [ "$http_code" = "200" ]; then
			local ai_response=$(echo "$body" | jq -r '.choices[0].message.content' 2>/dev/null)
			if [ -n "$ai_response" ] && [ "$ai_response" != "null" ]; then
				echo "$ai_response"
				return 0
			fi
		fi
	fi

	echo "${LANG_AUDITOR_ERR_API:-Erro ao comunicar com a API da IA} ($ai_prov - Código HTTP: $http_code)"
	return 1
}

# ==============================================================================
# Função auxiliar: envia texto longo via Telegram fracionado em chunks seguros
# ==============================================================================
_vm_checker_telegram_send_chunk() {
	local bot_token="$1"
	local chat_id="$2"
	local text="$3"

	# Remove sequências de escape ANSI para deixar o texto limpo no Telegram
	local clean_text
	clean_text=$(printf '%s' "$text" | sed 's/\x1b\[[0-9;]*m//g')

	local max_len=4000
	local total_len=${#clean_text}
	local offset=0

	while [ $offset -lt $total_len ]; do
		local chunk="${clean_text:$offset:$max_len}"

		# Se não chegou ao final, recua até o último newline para não cortar linha
		if [ $((offset + max_len)) -lt $total_len ]; then
			local safe_chunk
			safe_chunk=$(echo "$chunk" | head -n -1)
			# Se head não removeu nada (linha única), usa o chunk inteiro mesmo
			if [ -z "$safe_chunk" ]; then
				safe_chunk="$chunk"
			fi
			chunk="$safe_chunk"
		fi

		# Serializa como JSON e envia
		local json_text
		json_text=$(printf '%s' "$chunk" | python3 -c 'import sys,json; print(json.dumps(sys.stdin.read()))' 2>/dev/null)
		if [ -z "$json_text" ]; then
			json_text="(erro ao serializar chunk)"
		fi

		curl -s -X POST \
			"https://api.telegram.org/bot${bot_token}/sendMessage" \
			-H "Content-Type: application/json" \
			-d "{"chat_id":"${chat_id}","text":${json_text}}" \
			--max-time 15 > /dev/null 2>&1

		offset=$((offset + ${#chunk}))
		[ $offset -eq 0 ] && break  # segurança contra loop infinito
		sleep 1
	done
}

# ==============================================================================
# Função auxiliar: envia relatório de TODAS as VMs/CTs via Telegram (fracionado)
# ==============================================================================
_vm_checker_send_all_telegram() {
	local total="$1"
	shift

	# Separa os arrays de VMs e CTs usando o separador passado na chamada
	local vm_files_local=()
	local ct_files_local=()
	local in_ct=0
	for f in "$@"; do
		if [ "$f" = "---VMS_SEP---" ]; then
			in_ct=1
			continue
		fi
		if [ $in_ct -eq 0 ]; then
			vm_files_local+=("$f")
		else
			ct_files_local+=("$f")
		fi
	done

	# Verifica se Bot de Notificações está configurado
	local notif_file="/TcTI/SCRIPTS/telegram/.env_notificacoes"
	if [ ! -f "$notif_file" ]; then
		clear
echo -e  "${COLOR_RED}  ✗ Bot de Notificações não configurado!${COLOR_RESET}"
echo -e  "${COLOR_YELLOW}  Configure-o em: Menu 3 → 7 → 2 → 1${COLOR_RESET}"
		echo ""
		read -p "  ${LANG_AUDITOR_PRESS_BACK:-Pressione ENTER para voltar...}"
		return
	fi
	source "$notif_file" 2>/dev/null

	clear
	echo -e "${COLOR_CYAN}${COLOR_BOLD}"
	echo -e "╔═════════════════════════════════════════════════════════════════════╗"
echo -e  "║       📨 Enviando Relatório Completo via Telegram                   ║"
	echo -e "╚═════════════════════════════════════════════════════════════════════╝"
	echo -e "${COLOR_RESET}"
	echo ""
echo -e  "${COLOR_WHITE}  Destino: ${COLOR_YELLOW}${NOTIF_SERVER_NAME}${COLOR_RESET} | ${COLOR_GRAY}Chat ID: ${NOTIF_CHAT_ID}${COLOR_RESET}"
	echo ""

	local processed=0
	local hostname
	hostname=$(hostname)
	local ts
	ts=$(date '+%d/%m/%Y %H:%M')

	# Mensagem de início
	_vm_checker_telegram_send_chunk "$NOTIF_BOT_TOKEN" "$NOTIF_CHAT_ID" \
"🤖 RELATÓRIO DE VMs/CONTAINERS COM IA
Servidor: ${hostname}
Data: ${ts}
Total: ${total} VMs/Containers
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

	# Processa VMs
	for vm_file in "${vm_files_local[@]}"; do
		processed=$((processed + 1))
		local vm_id
		vm_id=$(basename "$vm_file" .conf)
		local vm_name
		vm_name=$(grep "^name:" "$vm_file" 2>/dev/null | cut -d' ' -f2)
echo -e  "  ${COLOR_YELLOW}▸${COLOR_RESET} Consultando IA para VM ${vm_id}${vm_name:+ ($vm_name)} [${processed}/${total}]..."

		local config_content
		config_content=$(cat "$vm_file")
		local analysis
		analysis=$(analyze_with_openai "$config_content" "VM" "$vm_id")

		_vm_checker_telegram_send_chunk "$NOTIF_BOT_TOKEN" "$NOTIF_CHAT_ID" \
"📦 VM ${vm_id}${vm_name:+ — $vm_name} [${processed}/${total}]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
${analysis}"
echo -e  "  ${COLOR_GREEN}✓${COLOR_RESET} VM ${vm_id} enviada"
		sleep 3
	done

	# Processa Containers
	for ct_file in "${ct_files_local[@]}"; do
		processed=$((processed + 1))
		local ct_id
		ct_id=$(basename "$ct_file" .conf)
		local ct_name
		ct_name=$(grep "^hostname:" "$ct_file" 2>/dev/null | cut -d' ' -f2)
echo -e  "  ${COLOR_YELLOW}▸${COLOR_RESET} Consultando IA para Container ${ct_id}${ct_name:+ ($ct_name)} [${processed}/${total}]..."

		local config_content
		config_content=$(cat "$ct_file")
		local analysis
		analysis=$(analyze_with_openai "$config_content" "Container" "$ct_id")

		_vm_checker_telegram_send_chunk "$NOTIF_BOT_TOKEN" "$NOTIF_CHAT_ID" \
"📦 Container ${ct_id}${ct_name:+ — $ct_name} [${processed}/${total}]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
${analysis}"
echo -e  "  ${COLOR_GREEN}✓${COLOR_RESET} Container ${ct_id} enviado"
		sleep 3
	done

	# Mensagem de encerramento
	_vm_checker_telegram_send_chunk "$NOTIF_BOT_TOKEN" "$NOTIF_CHAT_ID" \
"✅ RELATÓRIO CONCLUÍDO
Servidor: ${hostname}
Analisados: ${processed}/${total}
Data: ${ts}"

	echo ""
echo -e  "${COLOR_GREEN}  ✓ Relatório completo enviado ao Telegram!${COLOR_RESET}"
	echo ""
	read -p "  ${LANG_AUDITOR_PRESS_BACK:-Pressione ENTER para voltar...}"
}

# ==============================================================================
# Função auxiliar: envia relatório de UMA VM/CT via Telegram
# ==============================================================================
_vm_checker_send_one_telegram() {
	local notif_file="/TcTI/SCRIPTS/telegram/.env_notificacoes"
	if [ ! -f "$notif_file" ]; then
		clear
echo -e  "${COLOR_RED}  ✗ Bot de Notificações não configurado!${COLOR_RESET}"
echo -e  "${COLOR_YELLOW}  Configure-o em: Menu 3 → 7 → 2 → 1${COLOR_RESET}"
		echo ""
		read -p "  ${LANG_AUDITOR_PRESS_BACK:-Pressione ENTER para voltar...}"
		return
	fi
	source "$notif_file" 2>/dev/null

	clear
	echo -e "${COLOR_CYAN}${COLOR_BOLD}"
	echo -e "╔═════════════════════════════════════════════════════════════════════╗"
echo -e  "║        📨 Enviar Análise Individual via Telegram                    ║"
	echo -e "╚═════════════════════════════════════════════════════════════════════╝"
	echo -e "${COLOR_RESET}"
	echo ""
echo -e  "${COLOR_WHITE}  Destino: ${COLOR_YELLOW}${NOTIF_SERVER_NAME}${COLOR_RESET} | ${COLOR_GRAY}Chat ID: ${NOTIF_CHAT_ID}${COLOR_RESET}"
	echo ""
	echo -e "${COLOR_WHITE}  ${LANG_AUDITOR_TYPE_ID:-Digite o ID da VM ou Container (ex: 100):}${COLOR_RESET}"
	read -p "  ID: " target_id

	target_id=$(echo "$target_id" | tr -d ' ')
	if ! [[ "$target_id" =~ ^[0-9]+$ ]]; then
echo -e  "${COLOR_RED}  ✗ ID inválido!${COLOR_RESET}"
		sleep 2
		return
	fi

	local found=0
	local config_file=""
	local type=""

	if [ -f "$QEMU_DIR/${target_id}.conf" ]; then
		config_file="$QEMU_DIR/${target_id}.conf"
		type="VM"
		found=1
	elif [ -f "$LXC_DIR/${target_id}.conf" ]; then
		config_file="$LXC_DIR/${target_id}.conf"
		type="Container"
		found=1
	else
		shopt -s nullglob
		for file in "$QEMU_DIR"/*/"${target_id}.conf"; do
			config_file="$file"; type="VM"; found=1; break
		done
		for file in "$LXC_DIR"/*/"${target_id}.conf"; do
			config_file="$file"; type="Container"; found=1; break
		done
		shopt -u nullglob
	fi

	if [ $found -eq 0 ]; then
echo -e  "${COLOR_RED}  ✗ VM/Container ${target_id} não encontrado${COLOR_RESET}"
		sleep 2
		return
	fi

	local display_name=""
	if [ "$type" = "VM" ]; then
		display_name=$(grep "^name:" "$config_file" 2>/dev/null | cut -d' ' -f2)
	else
		display_name=$(grep "^hostname:" "$config_file" 2>/dev/null | cut -d' ' -f2)
	fi

	echo ""
echo -e  "${COLOR_YELLOW}  Consultando IA para ${type} ${target_id}...${COLOR_RESET}"

	local config_content
	config_content=$(cat "$config_file")
	local analysis
	analysis=$(analyze_with_openai "$config_content" "$type" "$target_id")

	local hostname
	hostname=$(hostname)
	local ts
	ts=$(date '+%d/%m/%Y %H:%M')
echo -e  "${COLOR_YELLOW}  Enviando ao Telegram (pode ser fracionado)...${COLOR_RESET}"

	_vm_checker_telegram_send_chunk "$NOTIF_BOT_TOKEN" "$NOTIF_CHAT_ID" \
"🤖 ANÁLISE IA — ${type} ${target_id}${display_name:+ ($display_name)}
Servidor: ${hostname} | ${ts}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
${analysis}"

	echo ""
	echo -e "${COLOR_GREEN}  ✓ ${LANG_AUDITOR_TG_SUC:-Relatório enviado ao Telegram com sucesso!}${COLOR_RESET}"
	echo ""
	read -p "  ${LANG_AUDITOR_PRESS_BACK:-Pressione ENTER para voltar...}"
}

# ==============================================================================
# Menu principal do verificador de VMs/CTs com IA
# ==============================================================================
vm_config_checker(){
	clear
	
	echo -e "${COLOR_CYAN}${COLOR_BOLD}"
	echo -e "╔═════════════════════════════════════════════════════════════════════╗"
	ui_print_header_line "" "" 69
	ui_print_header_line "🔍 ${LANG_CONFIG_CHECKER_MENU_TITLE:-IA Auditor de VMs / CTs}" "${COLOR_WHITE}" 69
	ui_print_header_line "" "" 69
	echo -e "╚═════════════════════════════════════════════════════════════════════╝"
	echo -e "${COLOR_RESET}"
	echo ""
	
	# Verifica se a chave OpenAI existe
	if ! check_openai_key; then
		return
	fi
echo -e  "${COLOR_YELLOW}  🔎 Buscando VMs e Containers...${COLOR_RESET}"
	echo ""
	
	# Verificação de ambiente e diretórios
	local qemu_exists=0
	local lxc_exists=0
	local qemu_readable=0
	local lxc_readable=0
	
	if [ -d "$QEMU_DIR" ]; then
		qemu_exists=1
		if [ -r "$QEMU_DIR" ]; then
			qemu_readable=1
		fi
	fi
	
	if [ -d "$LXC_DIR" ]; then
		lxc_exists=1
		if [ -r "$LXC_DIR" ]; then
			lxc_readable=1
		fi
	fi
	
	# Debug: Mostra status dos diretórios
echo -e  "${COLOR_CYAN}  📁 Status dos diretórios:${COLOR_RESET}"
	if [ $qemu_exists -eq 1 ]; then
		if [ $qemu_readable -eq 1 ]; then
echo -e  "    ${COLOR_GREEN}✓${COLOR_RESET} ${COLOR_WHITE}VMs:${COLOR_RESET} ${QEMU_DIR} ${COLOR_GREEN}(acessível)${COLOR_RESET}"
		else
echo -e  "    ${COLOR_RED}✗${COLOR_RESET} ${COLOR_WHITE}VMs:${COLOR_RESET} ${QEMU_DIR} ${COLOR_RED}(sem permissão)${COLOR_RESET}"
		fi
	else
echo -e  "    ${COLOR_RED}✗${COLOR_RESET} ${COLOR_WHITE}VMs:${COLOR_RESET} ${QEMU_DIR} ${COLOR_RED}(não existe)${COLOR_RESET}"
	fi
	
	if [ $lxc_exists -eq 1 ]; then
		if [ $lxc_readable -eq 1 ]; then
echo -e  "    ${COLOR_GREEN}✓${COLOR_RESET} ${COLOR_WHITE}Containers:${COLOR_RESET} ${LXC_DIR} ${COLOR_GREEN}(acessível)${COLOR_RESET}"
		else
echo -e  "    ${COLOR_RED}✗${COLOR_RESET} ${COLOR_WHITE}Containers:${COLOR_RESET} ${LXC_DIR} ${COLOR_RED}(sem permissão)${COLOR_RESET}"
		fi
	else
echo -e  "    ${COLOR_RED}✗${COLOR_RESET} ${COLOR_WHITE}Containers:${COLOR_RESET} ${LXC_DIR} ${COLOR_RED}(não existe)${COLOR_RESET}"
	fi
	echo ""
	
	# Busca arquivos de VMs usando glob (compatível com FUSE filesystem)
	local vm_files=()
	if [ $qemu_exists -eq 1 ] && [ $qemu_readable -eq 1 ]; then
		shopt -s nullglob
		for file in "$QEMU_DIR"/*.conf "$QEMU_DIR"/*/*.conf; do
			[ -f "$file" ] || continue
			local basename=$(basename "$file")
			if [[ $basename =~ ^[0-9]+\.conf$ ]]; then
				vm_files+=("$file")
			fi
		done
		shopt -u nullglob
	fi
	
	# Busca arquivos de Containers usando glob
	local ct_files=()
	if [ $lxc_exists -eq 1 ] && [ $lxc_readable -eq 1 ]; then
		shopt -s nullglob
		for file in "$LXC_DIR"/*.conf "$LXC_DIR"/*/*.conf; do
			[ -f "$file" ] || continue
			local basename=$(basename "$file")
			if [[ $basename =~ ^[0-9]+\.conf$ ]]; then
				ct_files+=("$file")
			fi
		done
		shopt -u nullglob
	fi
	
	local total_vms=${#vm_files[@]}
	local total_cts=${#ct_files[@]}
	local total=$((total_vms + total_cts))
	
	if [ $total -eq 0 ]; then
echo -e  "${COLOR_RED}  ✗ Nenhuma VM ou Container encontrado${COLOR_RESET}"
		echo ""
		
		if [ $qemu_exists -eq 0 ] && [ $lxc_exists -eq 0 ]; then
echo -e  "${COLOR_YELLOW}  💡 Possíveis causas:${COLOR_RESET}"
echo -e  "    ${COLOR_WHITE}• Não está num servidor Proxmox VE${COLOR_RESET}"
echo -e  "    ${COLOR_WHITE}• O filesystem /etc/pve/ não está montado${COLOR_RESET}"
			echo ""
echo -e  "${COLOR_CYAN}  🔧 Comandos de diagnóstico:${COLOR_RESET}"
echo -e  "    ${COLOR_GRAY}pvesh get /version${COLOR_RESET}"
echo -e  "    ${COLOR_GRAY}pvesm status${COLOR_RESET}"
echo -e  "    ${COLOR_GRAY}mount | grep pve${COLOR_RESET}"
		elif [ $qemu_readable -eq 0 ] || [ $lxc_readable -eq 0 ]; then
echo -e  "${COLOR_YELLOW}  💡 Possível causa:${COLOR_RESET}"
echo -e  "    ${COLOR_WHITE}• Sem permissões de acesso aos diretórios${COLOR_RESET}"
			echo ""
echo -e  "${COLOR_CYAN}  🔧 Solução:${COLOR_RESET}"
echo -e  "    ${COLOR_GRAY}Execute o script como root ou com sudo${COLOR_RESET}"
		else
echo -e  "${COLOR_YELLOW}  💡 Informação:${COLOR_RESET}"
echo -e  "    ${COLOR_WHITE}• Os diretórios existem mas não há VMs/Containers configurados${COLOR_RESET}"
echo -e  "    ${COLOR_WHITE}• Crie VMs ou Containers primeiro no Proxmox${COLOR_RESET}"
		fi
		
		echo ""
		read -p "  ${LANG_AUDITOR_PRESS_BACK:-Pressione ENTER para voltar...}"
		return
	fi
echo -e  "${COLOR_GREEN}  ✓ Encontrados:${COLOR_RESET}"
echo -e  "    ${COLOR_WHITE}VMs: ${COLOR_YELLOW}${total_vms}${COLOR_RESET}"
echo -e  "    ${COLOR_WHITE}Containers: ${COLOR_YELLOW}${total_cts}${COLOR_RESET}"
	echo ""
	
	# Lista as VMs encontradas
	if [ $total_vms -gt 0 ]; then
echo -e  "${COLOR_CYAN}  📦 VMs encontradas:${COLOR_RESET}"
		for vm_file in "${vm_files[@]}"; do
			local vm_id=$(basename "$vm_file" .conf)
			local vm_name=$(grep "^name:" "$vm_file" 2>/dev/null | cut -d' ' -f2)
			if [ -n "$vm_name" ]; then
echo -e  "    ${COLOR_GRAY}•${COLOR_RESET} VM ${COLOR_YELLOW}${vm_id}${COLOR_RESET} - ${COLOR_WHITE}${vm_name}${COLOR_RESET}"
			else
echo -e  "    ${COLOR_GRAY}•${COLOR_RESET} VM ${COLOR_YELLOW}${vm_id}${COLOR_RESET}"
			fi
		done
		echo ""
	fi
	
	# Lista os Containers encontrados
	if [ $total_cts -gt 0 ]; then
echo -e  "${COLOR_CYAN}  📦 Containers encontrados:${COLOR_RESET}"
		for ct_file in "${ct_files[@]}"; do
			local ct_id=$(basename "$ct_file" .conf)
			local ct_name=$(grep "^hostname:" "$ct_file" 2>/dev/null | cut -d' ' -f2)
			if [ -n "$ct_name" ]; then
echo -e  "    ${COLOR_GRAY}•${COLOR_RESET} CT ${COLOR_YELLOW}${ct_id}${COLOR_RESET} - ${COLOR_WHITE}${ct_name}${COLOR_RESET}"
			else
echo -e  "    ${COLOR_GRAY}•${COLOR_RESET} CT ${COLOR_YELLOW}${ct_id}${COLOR_RESET}"
			fi
		done
		echo ""
	fi
	
	echo -e "${COLOR_BOLD}  ${LANG_SELECT_OPT:-Selecione uma opção:}${COLOR_RESET}"
	echo ""
	echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	
	ui_print_menu_item "1" "${LANG_CONFIG_CHECKER_MENU_OPT_1}" "${COLOR_YELLOW}"
	ui_print_menu_item "2" "${LANG_CONFIG_CHECKER_MENU_OPT_2}" "${COLOR_YELLOW}"
	
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	
	ui_print_menu_item "3" "${LANG_CONFIG_CHECKER_MENU_OPT_3}" "${COLOR_YELLOW}"
	ui_print_menu_item "4" "${LANG_CONFIG_CHECKER_MENU_OPT_4}" "${COLOR_YELLOW}"
	
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	
	ui_print_menu_item "0" "${LANG_VM_OP_OPT_0:-Voltar}" "${COLOR_RED}"
	
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
	echo ""
	echo -e "${COLOR_YELLOW}  ${LANG_TYPE_OPT:-Digite sua opção} ${COLOR_GRAY}${LANG_PRESS_ENTER:-(ou pressione ENTER para sair)}${COLOR_YELLOW}: ${COLOR_RESET}"
	read -rsn1 opt
	
	case $opt in
		1)
			clear
			echo -e "${COLOR_CYAN}${COLOR_BOLD}"
			echo -e "╔═════════════════════════════════════════════════════════════════════╗"
echo -e  "║            🤖 Verificação Completa com IA                           ║"
			echo -e "╚═════════════════════════════════════════════════════════════════════╝"
			echo -e "${COLOR_RESET}"
			echo ""
echo -e  "${COLOR_YELLOW}  Analisando ${total} VMs/Containers...${COLOR_RESET}"
			echo ""
			
			local processed=0
			local errors=0
			
			# Processa VMs
			for vm_file in "${vm_files[@]}"; do
				processed=$((processed + 1))
				local vm_id=$(basename "$vm_file" .conf)
				local vm_name=$(grep "^name:" "$vm_file" 2>/dev/null | cut -d' ' -f2)
				
				echo -e "${COLOR_CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${COLOR_RESET}"
echo -e  "${COLOR_BOLD}  📦 VM ${vm_id}${COLOR_RESET}${vm_name:+ - $vm_name} ${COLOR_GRAY}[${processed}/${total}]${COLOR_RESET}"
				echo -e "${COLOR_CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${COLOR_RESET}"
				echo ""
				
				local config_content=$(cat "$vm_file")
				local analysis=$(analyze_with_openai "$config_content" "VM" "$vm_id")
				
				if [ $? -eq 0 ]; then
					echo -e "${COLOR_WHITE}${analysis}${COLOR_RESET}"
				else
					echo -e "${COLOR_RED}  ✗ ${LANG_AUDITOR_ERR_PARSE:-Erro ao analisar: }${analysis}${COLOR_RESET}"
					errors=$((errors + 1))
				fi
				
				echo ""
				if [ $processed -lt $total ]; then
					sleep 2
				fi
			done
			
			# Processa Containers
			for ct_file in "${ct_files[@]}"; do
				processed=$((processed + 1))
				local ct_id=$(basename "$ct_file" .conf)
				local ct_name=$(grep "^hostname:" "$ct_file" 2>/dev/null | cut -d' ' -f2)
				
				echo -e "${COLOR_CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${COLOR_RESET}"
echo -e  "${COLOR_BOLD}  📦 Container ${ct_id}${COLOR_RESET}${ct_name:+ - $ct_name} ${COLOR_GRAY}[${processed}/${total}]${COLOR_RESET}"
				echo -e "${COLOR_CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${COLOR_RESET}"
				echo ""
				
				local config_content=$(cat "$ct_file")
				local analysis=$(analyze_with_openai "$config_content" "Container" "$ct_id")
				
				if [ $? -eq 0 ]; then
					echo -e "${COLOR_WHITE}${analysis}${COLOR_RESET}"
				else
					echo -e "${COLOR_RED}  ✗ ${LANG_AUDITOR_ERR_PARSE:-Erro ao analisar: }${analysis}${COLOR_RESET}"
					errors=$((errors + 1))
				fi
				
				echo ""
				if [ $processed -lt $total ]; then
					sleep 2
				fi
			done
			
			echo -e "${COLOR_CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${COLOR_RESET}"
echo -e  "${COLOR_GREEN}  ✓ Verificação concluída!${COLOR_RESET}"
echo -e  "    ${COLOR_WHITE}Analisados: ${COLOR_YELLOW}${processed}${COLOR_RESET}"
			if [ $errors -gt 0 ]; then
echo -e  "    ${COLOR_RED}Erros: ${errors}${COLOR_RESET}"
			fi
			echo -e "${COLOR_CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${COLOR_RESET}"
			echo ""
			read -p "  ${LANG_AUDITOR_PRESS_BACK:-Pressione ENTER para voltar...}"
			vm_config_checker
			;;
		2)
			clear
			echo -e "${COLOR_CYAN}${COLOR_BOLD}"
			echo -e "╔═════════════════════════════════════════════════════════════════════╗"
echo -e  "║          🔍 Verificação Individual com IA                           ║"
			echo -e "╚═════════════════════════════════════════════════════════════════════╝"
			echo -e "${COLOR_RESET}"
			echo ""
			echo -e "${COLOR_WHITE}  ${LANG_AUDITOR_TYPE_ID:-Digite o ID da VM ou Container (ex: 100):}${COLOR_RESET}"
			read -p "  ID: " target_id
			
			target_id=$(echo "$target_id" | tr -d ' ')
			if ! [[ "$target_id" =~ ^[0-9]+$ ]]; then
				echo ""
echo -e  "${COLOR_RED}  ✗ ID inválido! Use apenas números.${COLOR_RESET}"
				sleep 2
				vm_config_checker
				return
			fi
			
			local found=0
			local config_file=""
			local type=""
			
			if [ -f "$QEMU_DIR/${target_id}.conf" ]; then
				config_file="$QEMU_DIR/${target_id}.conf"
				type="VM"
				found=1
			else
				shopt -s nullglob
				for file in "$QEMU_DIR"/*/"${target_id}.conf" "$QEMU_DIR"/*/*/"${target_id}.conf"; do
					if [ -f "$file" ]; then
						config_file="$file"; type="VM"; found=1; break
					fi
				done
				shopt -u nullglob
			fi
			
			if [ $found -eq 0 ]; then
				if [ -f "$LXC_DIR/${target_id}.conf" ]; then
					config_file="$LXC_DIR/${target_id}.conf"
					type="Container"
					found=1
				else
					shopt -s nullglob
					for file in "$LXC_DIR"/*/"${target_id}.conf" "$LXC_DIR"/*/*/"${target_id}.conf"; do
						if [ -f "$file" ]; then
							config_file="$file"; type="Container"; found=1; break
						fi
					done
					shopt -u nullglob
				fi
			fi
			
			if [ $found -eq 0 ]; then
				echo ""
echo -e  "${COLOR_RED}  ✗ VM/Container ${target_id} não encontrado${COLOR_RESET}"
				sleep 2
				vm_config_checker
				return
			fi
			
			clear
			echo -e "${COLOR_CYAN}${COLOR_BOLD}"
			echo -e "╔═════════════════════════════════════════════════════════════════════╗"
echo -e  "║              🤖 Análise com IA em Progresso                         ║"
			echo -e "╚═════════════════════════════════════════════════════════════════════╝"
			echo -e "${COLOR_RESET}"
			echo ""
echo -e  "${COLOR_YELLOW}  Analisando ${type} ${target_id}...${COLOR_RESET}"
			echo ""
			
			local config_content=$(cat "$config_file")
			local analysis=$(analyze_with_openai "$config_content" "$type" "$target_id")
			local ai_exit=$?
			
			clear
			echo -e "${COLOR_CYAN}${COLOR_BOLD}"
			echo -e "╔═════════════════════════════════════════════════════════════════════╗"
echo -e  "║            📊 Resultado da Análise — ${type} ${target_id}${COLOR_CYAN}                   ║"
			echo -e "╚═════════════════════════════════════════════════════════════════════╝"
			echo -e "${COLOR_RESET}"
			echo ""
			
			if [ $ai_exit -eq 0 ]; then
				echo -e "${COLOR_WHITE}${analysis}${COLOR_RESET}"
			else
				echo -e "${COLOR_RED}  ✗ ${LANG_AUDITOR_ERR_PARSE:-Erro ao analisar: }${analysis}${COLOR_RESET}"
			fi
			
			echo ""
			echo -e "${COLOR_CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${COLOR_RESET}"
			read -p "  ${LANG_AUDITOR_PRESS_BACK:-Pressione ENTER para voltar...}"
			vm_config_checker
			;;
		3)
			_vm_checker_send_all_telegram "$total" "${vm_files[@]}" "---VMS_SEP---" "${ct_files[@]}"
			vm_config_checker
			;;
		4)
			_vm_checker_send_one_telegram
			vm_config_checker
			;;
		0)
			return
			;;
		*)
			vm_config_checker
			;;
	esac
}
