#!/bin/bash

# Menu de Utilização de IA
# Versão: V003.R004
# Adicionado em: 2025-11-17
# Atualizado em: 2025-11-18
# Melhorias: Corrigido problema com filesystem FUSE do Proxmox

ia_menu(){
	clear
	NORMAL=`echo "\033[m"`
	MENU=`echo "\033[36m"`
	NUMBER=`echo "\033[33m"`
	FGRED=`echo "\033[41m"`
	RED_TEXT=`echo "\033[31m"`
	ENTER_LINE=`echo "\033[33m"`
	
	echo -e "${COLOR_CYAN}${COLOR_BOLD}"
	echo -e "╔═════════════════════════════════════════════════════════════════════╗"
	echo -e "║                                                                     ║"
	echo -e "║                    🤖 ${LANG_IA_MENU_TITLE:-Utilização de IA}                               ║"
	echo -e "║                                                                     ║"
	echo -e "╚═════════════════════════════════════════════════════════════════════╝"
	echo -e "${COLOR_RESET}"
	echo ""
	echo -e "${COLOR_BOLD}  ${LANG_SELECT_OPT:-Selecione uma opção:}${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	
	ui_print_menu_item "1" "${LANG_IA_MENU_OPT_1}"
	ui_print_menu_item "2" "${LANG_IA_MENU_OPT_2}"
	
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	
	ui_print_menu_item "0" "${LANG_VM_OP_OPT_0:-Voltar}" "${COLOR_RED}"
	
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
	echo ""
	echo -e "${COLOR_YELLOW}  ${LANG_TYPE_OPT:-Digite sua opção} ${COLOR_GRAY}${LANG_PRESS_ENTER:-(ou pressione ENTER para sair)}${COLOR_YELLOW}: ${COLOR_RESET}"
	read -rsn1 opt
	while [ opt != '' ]	
	do
		if [[ $opt = "" ]]; then
			 exit;
		else
	case $opt in
		1) clear
		vm_config_checker
		ia_menu
			;;
		2) clear
		extras_ia_menu
		ia_menu
			;;
		0)
		clear
		pve_menu
			;;
		*)
		clear
		ia_menu
			;;
	esac
		fi
	done
	ia_menu
}
