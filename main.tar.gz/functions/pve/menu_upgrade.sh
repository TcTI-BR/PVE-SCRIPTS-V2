#!/bin/bash

# Menu de upgrade de versões do Proxmox VE

upgrade_menu(){
	clear
	NORMAL=`echo "\033[m"`
	MENU=`echo "\033[36m"`
	NUMBER=`echo "\033[33m"`
	FGRED=`echo "\033[41m"`
	RED_TEXT=`echo "\033[31m"`
	ENTER_LINE=`echo "\033[33m"`
	
	echo -e "${COLOR_CYAN}${COLOR_BOLD}"
	echo -e "╔═════════════════════════════════════════════════════════════════════╗"
	echo -e "║                                                                     ║"
	echo -e "║              🚀 Upgrade de Versões do Proxmox VE                     ║"
	echo -e "║                                                                     ║"
	echo -e "╚═════════════════════════════════════════════════════════════════════╝"
	echo -e "${COLOR_RESET}"
	echo ""
	echo -e "${COLOR_YELLOW}${COLOR_BOLD}  ⚠️  ATENÇÃO:${COLOR_RESET}"
	echo -e "${COLOR_YELLOW}  Faça backup antes de realizar qualquer upgrade!${COLOR_RESET}"
	echo ""
	echo -e "${COLOR_BOLD}  Selecione a versão de destino:${COLOR_RESET}"
	echo ""
	echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}1${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}Upgrade da versão 5.x para 6.x${COLOR_RESET}                          ${COLOR_CYAN}│${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}2${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}Upgrade da versão 6.x para 7.x${COLOR_RESET}                          ${COLOR_CYAN}│${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}3${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}Upgrade da versão 7.x para 8.x${COLOR_RESET}                          ${COLOR_CYAN}│${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}4${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}Upgrade da versão 8.x para 9.x (Debian 13 Trixie)${COLOR_RESET}       ${COLOR_CYAN}│${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_RED}0${COLOR_RESET} ${COLOR_RED}➜${COLOR_RESET}  ${COLOR_WHITE}Voltar${COLOR_RESET}                                                  ${COLOR_CYAN}│${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
	echo ""
	echo -e "${COLOR_YELLOW}  Digite sua opção ${COLOR_GRAY}(ou pressione ENTER para sair)${COLOR_YELLOW}: ${COLOR_RESET}"
	read -rsn1 opt
	while [ opt != '' ]
	do
		if [[ $opt = "" ]]; then
			exit;
		else
			case $opt in
				1) clear;
				mv /etc/apt/sources.list.d/pve-enterprise.list /root/ 2>/dev/null
				clear
				systemctl stop pve-ha-lrm 2>/dev/null
				systemctl stop pve-ha-crm 2>/dev/null
				echo "deb http://download.proxmox.com/debian/corosync-3/ stretch main" > /etc/apt/sources.list.d/corosync3.list
				apt update
				apt dist-upgrade -y
				systemctl start pve-ha-lrm 2>/dev/null
				systemctl start pve-ha-crm 2>/dev/null
				apt update
				apt dist-upgrade -y
				sed -i 's/stretch/buster/g' /etc/apt/sources.list
				echo "deb http://download.proxmox.com/debian/pve buster pve-no-subscription" > /etc/apt/sources.list.d/sources.list
				sed -i -e 's/stretch/buster/g' /etc/apt/sources.list.d/pve-install-repo.list 
				echo "deb http://download.proxmox.com/debian/ceph-luminous buster main" > /etc/apt/sources.list.d/ceph.list
				apt update
				apt dist-upgrade -y
				rm /etc/apt/sources.list.d/corosync3.list
				apt update
				apt dist-upgrade -y
				apt remove linux-image-amd64 -y 2>/dev/null
				systemctl disable display-manager 2>/dev/null
				clear
				read -p "Pressione uma tecla para continuar..."
				clear
				update_menu;
					;;
				2) clear;
				mv /etc/apt/sources.list.d/pve-enterprise.list /root/ 2>/dev/null
				clear
				sed -i '/proxmox/d' /etc/apt/sources.list
				echo	"deb http://download.proxmox.com/debian/pve buster pve-no-subscription"	>> /etc/apt/sources.list
				dpkg --configure -a
				apt update
				apt upgrade -y
				sed -i '/proxmox/d' /etc/apt/sources.list
				sed -i '/debian/d' /etc/apt/sources.list
				sed -i '/update/d' /etc/apt/sources.list
				echo "deb http://security.debian.org/debian-security bullseye-security main contrib" >> /etc/apt/sources.list
				echo "deb http://ftp.debian.org/debian bullseye-updates main contrib" >> /etc/apt/sources.list
				echo "deb http://download.proxmox.com/debian/pve bullseye pve-no-subscription" >> /etc/apt/sources.list
				echo "deb http://ftp.debian.org/debian bullseye main contrib" >> /etc/apt/sources.list
				apt update
				apt upgrade -y
				apt dist-upgrade -y
				systemctl disable display-manager 2>/dev/null
				clear
				read -p "Pressione uma tecla para continuar..."
				clear
				upgrade_menu;	
					;;
				3) clear;
				mv /etc/apt/sources.list.d/pve-enterprise.list /root/ 2>/dev/null
				clear
				apt update
				apt upgrade -y
				sed -i '/proxmox/d' /etc/apt/sources.list
				sed -i '/debian/d' /etc/apt/sources.list
				sed -i '/update/d' /etc/apt/sources.list
				echo "deb http://security.debian.org/debian-security bookworm-security main contrib" >> /etc/apt/sources.list
				echo "deb http://ftp.debian.org/debian bookworm-updates main contrib" >> /etc/apt/sources.list
				echo "deb http://download.proxmox.com/debian/pve bookworm pve-no-subscription" >> /etc/apt/sources.list
				echo "deb http://ftp.debian.org/debian bookworm main contrib" >> /etc/apt/sources.list
				apt update
				apt upgrade -y
				apt dist-upgrade -y
				systemctl disable display-manager 2>/dev/null
				clear
				read -p "Pressione uma tecla para continuar..."
				clear
				upgrade_menu;	
					;;
				4) clear;
				echo -e "${COLOR_CYAN}${COLOR_BOLD}╔═════════════════════════════════════════════════════════════════════╗${COLOR_RESET}"
				echo -e "${COLOR_CYAN}${COLOR_BOLD}║       🚀 Assistente de Upgrade: Proxmox VE 8.x ➜ 9.x                ║${COLOR_RESET}"
				echo -e "${COLOR_CYAN}${COLOR_BOLD}╚═════════════════════════════════════════════════════════════════════╝${COLOR_RESET}"
				echo ""
				echo -e "${COLOR_YELLOW}🔍 Executando verificação prévia de compatibilidade (pve8to9 --full)...${COLOR_RESET}"
				echo ""
				
				if command -v pve8to9 >/dev/null 2>&1; then
					pve8to9 --full
				else
					echo -e "${COLOR_YELLOW}Instalando utilitário pve8to9 para análise prévia...${COLOR_RESET}"
					apt update && apt install -y pve8to9 2>/dev/null
					if command -v pve8to9 >/dev/null 2>&1; then
						pve8to9 --full
					else
						echo -e "${COLOR_YELLOW}Aviso: pve8to9 não encontrado. Certifique-se de estar atualizado no PVE 8.x.${COLOR_RESET}"
					fi
				fi
				
				echo ""
				echo -e "${COLOR_RED_TEXT}${COLOR_BOLD}⚠️  ATENÇÃO CRÍTICA:${COLOR_RESET}"
				echo -e "${COLOR_YELLOW}Revise o relatório do 'pve8to9' exibido acima!${COLOR_RESET}"
				echo -e "${COLOR_RED_TEXT}Se houver qualquer item em VERMELHO (FAIL/ERRO), o upgrade PODE QUEBRAR O BOOT!${COLOR_RESET}"
				echo -e "${COLOR_WHITE}Corrija todas as pendências em vermelho antes de avançar.${COLOR_RESET}"
				echo ""
				echo -e "${COLOR_CYAN}Deseja realmente continuar com o upgrade para PVE 9.x agora? (s/N): ${COLOR_RESET}"
				read -r conf_upg
				if [[ "$conf_upg" != "s" && "$conf_upg" != "S" ]]; then
					echo -e "${COLOR_YELLOW}Upgrade cancelado com segurança. Retornando ao menu...${COLOR_RESET}"
					sleep 2
					upgrade_menu
					return
				fi

				echo ""
				echo -e "${COLOR_GREEN}1/6 💾 Criando backup de segurança das configurações (/etc/apt, /etc/network/interfaces)...${COLOR_RESET}"
				mkdir -p /root/pve8_upgrade_bkp
				cp -r /etc/apt /root/pve8_upgrade_bkp/ 2>/dev/null
				cp /etc/network/interfaces /root/pve8_upgrade_bkp/ 2>/dev/null
				cp -r /var/lib/pve-cluster /root/pve8_upgrade_bkp/ 2>/dev/null

				echo -e "${COLOR_GREEN}2/6 🧩 Instalando microcódigo de processador (Intel/AMD)...${COLOR_RESET}"
				if grep -q "Intel" /proc/cpuinfo 2>/dev/null; then
					apt update && apt install -y intel-microcode 2>/dev/null
				elif grep -q "AMD" /proc/cpuinfo 2>/dev/null; then
					apt update && apt install -y amd64-microcode 2>/dev/null
				fi

				echo -e "${COLOR_GREEN}3/6 🔄 Configurando repositórios para Debian 13 Trixie / PVE 9.x...${COLOR_RESET}"
				[ -f /etc/apt/sources.list.d/pve-enterprise.list ] && mv /etc/apt/sources.list.d/pve-enterprise.list /root/pve8_upgrade_bkp/
				[ -f /etc/apt/sources.list.d/pve-enterprise.sources ] && mv /etc/apt/sources.list.d/pve-enterprise.sources /root/pve8_upgrade_bkp/

				sed -i 's/bookworm/trixie/g' /etc/apt/sources.list 2>/dev/null
				if [ -f /etc/apt/sources.list.d/debian.sources ]; then
					sed -i 's/bookworm/trixie/g' /etc/apt/sources.list.d/debian.sources
				fi

				echo "deb http://download.proxmox.com/debian/pve trixie pve-no-subscription" > /etc/apt/sources.list.d/pve-no-subscription.list

				echo -e "${COLOR_GREEN}4/6 📥 Atualizando listas de pacotes...${COLOR_RESET}"
				apt update

				echo -e "${COLOR_GREEN}5/6 🚀 Executando dist-upgrade para Proxmox VE 9.x...${COLOR_RESET}"
				apt dist-upgrade -y

				echo -e "${COLOR_GREEN}6/6 🛠️ Atualizando inicializador do boot (GRUB / systemd-boot)...${COLOR_RESET}"
				if [ -d /sys/firmware/efi ]; then
					echo -e "Sistema UEFI detectado. Atualizando systemd-boot/grub-efi..."
					proxmox-boot-tool refresh 2>/dev/null || update-grub
				else
					echo -e "Sistema BIOS Legacy detectado. Atualizando GRUB..."
					update-grub 2>/dev/null
				fi

				echo ""
				echo -e "${COLOR_GREEN}${COLOR_BOLD}✅ Upgrade do Proxmox VE para a versão 9.x concluído com sucesso!${COLOR_RESET}"
				echo -e "${COLOR_YELLOW}Recomenda-se reiniciar o servidor para carregar o novo Kernel.${COLOR_RESET}"
				echo ""
				read -p "Pressione ENTER para voltar ao menu..."
				upgrade_menu
					;;
				0) clear;
				update_menu;
					;;
				*)clear;
				update_menu;
					;;
			esac
		fi
	done
}

