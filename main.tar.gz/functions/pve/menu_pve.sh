#!/bin/bash

# Menu principal do Proxmox Virtual Environment
# Atualizado: V003.R002 - Adicionada opção 9 (Utilização de IA)
# Data: 2025-11-17

pve_menu(){
	clear
	NORMAL=`echo "\033[m"`
	MENU=`echo "\033[36m"`
	NUMBER=`echo "\033[33m"`
	FGRED=`echo "\033[41m"`
	RED_TEXT=`echo "\033[31m"`
	ENTER_LINE=`echo "\033[33m"`
	
	echo -e "${COLOR_CYAN}${COLOR_BOLD}"
	echo -e "╔═════════════════════════════════════════════════════════════════════╗"
	ui_print_header_line "" "" 69
	ui_print_header_line "🖥️  ${LANG_PVE_MENU_TITLE:-Proxmox Virtual Environment - Menu Principal}" "${COLOR_WHITE}" 69
	ui_print_header_line "${LANG_MAIN_VERSION:-Versão:} ${version}" "${COLOR_YELLOW}" 69
	ui_print_header_line "" "" 69
	echo -e "╚═════════════════════════════════════════════════════════════════════╝"
	echo -e "${COLOR_RESET}"
	echo ""

	echo -e "${COLOR_BOLD}  ${LANG_SELECT_OPT:-Selecione uma opção:}${COLOR_RESET}"
	echo ""
	echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	
	ui_print_menu_item "1" "${LANG_PVE_MENU_OPT_1}"
	ui_print_menu_item "2" "${LANG_PVE_MENU_OPT_2}"
	ui_print_menu_item "3" "${LANG_PVE_MENU_OPT_3}"
	ui_print_menu_item "4" "${LANG_PVE_MENU_OPT_4}"
	ui_print_menu_item "5" "${LANG_PVE_MENU_OPT_5}"
	ui_print_menu_item "6" "${LANG_PVE_MENU_OPT_6}"
	
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	
	ui_print_menu_item "0" "${LANG_PVE_MENU_OPT_0}" "${COLOR_RED}"
	
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
	echo ""
	echo -e "${COLOR_YELLOW}  ${LANG_TYPE_OPT:-Digite sua opção} ${COLOR_GRAY}${LANG_PRESS_ENTER:-(ou pressione ENTER para sair)}${COLOR_YELLOW}: ${COLOR_RESET}"
	read -rsn1 opt
	while [ opt != '' ]
	do
		if [[ $opt = "" ]]; then
			exit;
		else
			case $opt in
				1) clear;
				update_menu
					;;
				2) clear;
				disco_menu
					;;
				3) clear;
				bkp_menu
					;;
				4) clear;
				vm_operations_menu
					;;
				5) clear;
				ia_menu
					;;
				6) clear;
				webui_sensors_menu
					;;
				0)
					clear
					main_menu
						;;
					*)
					clear
					main_menu
						;;
			esac
		fi
	done
	pve_menu
}

