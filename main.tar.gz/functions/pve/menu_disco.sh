#!/bin/bash

# Menu de ferramentas de disco do Proxmox VE

disco_menu(){
	clear
	NORMAL=`echo "\033[m"`
	MENU=`echo "\033[36m"`
	NUMBER=`echo "\033[33m"`
	FGRED=`echo "\033[41m"`
	RED_TEXT=`echo "\033[31m"`
	ENTER_LINE=`echo "\033[33m"`
	
	echo -e "${COLOR_CYAN}${COLOR_BOLD}"
	echo -e "╔═════════════════════════════════════════════════════════════════════╗"
	ui_print_header_line "" "" 69
	ui_print_header_line "💾 ${LANG_DISCO_MENU_TITLE:-Ferramentas de Disco e Sistemas de Arquivos}" "${COLOR_WHITE}" 69
	ui_print_header_line "" "" 69
	echo -e "╚═════════════════════════════════════════════════════════════════════╝"
	echo -e "${COLOR_RESET}"
	echo ""
	echo -e "${COLOR_BOLD}  ${LANG_SELECT_OPT:-Selecione uma opção:}${COLOR_RESET}"
	echo ""
	echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	
	ui_print_menu_item "1" "${LANG_DISCO_MENU_OPT_1}"
	ui_print_menu_item "2" "${LANG_DISCO_MENU_OPT_2}"
	ui_print_menu_item "3" "${LANG_DISCO_MENU_OPT_3}"
	
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	
	ui_print_menu_item "0" "${LANG_VM_OP_OPT_0:-Voltar}" "${COLOR_RED}"
	
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
	echo ""
	echo -e "${COLOR_YELLOW}  ${LANG_TYPE_OPT:-Digite sua opção} ${COLOR_GRAY}${LANG_PRESS_ENTER:-(ou pressione ENTER para sair)}${COLOR_YELLOW}: ${COLOR_RESET}"
	read -rsn1 opt
		while [ opt != '' ]	
	do
		if [[ $opt = "" ]]; then
			exit;
		else
	case $opt in
		1) clear
		lsblk -o NAME,SIZE,LABEL,MOUNTPOINT,FSTYPE
		echo -e "  ${COLOR_WHITE}${LANG_DISK_PREP:-Qual o disco que vai ser preparado? EX: sda / nvme0n1}${COLOR_RESET}"
read -p  "${LANG_AUTO_MENU_DISCO_489:-  Disco: }" FORMATADISCO
		echo -e "  ${COLOR_WHITE}${LANG_DISK_NAME:-Qual o nome do Storage? EX: VM01 / RECOVER / BACKUP_2HD / BACKUP_REDE / EXTERNO_TERCA / EXTERNO_QUINTA}${COLOR_RESET}"
read -p  "${LANG_AUTO_MENU_DISCO_490:-  Storage: }" STORAGE
		echo -e "  ${COLOR_WHITE}${LANG_DISK_USAGE:-O disco será para ${COLOR_RED}BACKUP${COLOR_WHITE} ou ${COLOR_RED}VM${COLOR_WHITE}?: Digite exatamente ${COLOR_RED}images${COLOR_WHITE} para VM ou ${COLOR_RED}backup${COLOR_WHITE} para BACKUP sem as aspas}${COLOR_RESET}"
read -p  "${LANG_AUTO_MENU_DISCO_491:-  Opção: }" IMAGEBACKUP
		pvesm remove $STORAGE 2>/dev/null
		umount /dev/$FORMATADISCO 2>/dev/null
		umount /dev/${FORMATADISCO}1 2>/dev/null
		umount /dev/${FORMATADISCO}p1 2>/dev/null
		wipefs -a /dev/$FORMATADISCO 2>/dev/null
		echo -e "g\nn\np\n1\n\n\nw" | fdisk /dev/$FORMATADISCO >/dev/null 2>&1
		partprobe /dev/$FORMATADISCO 2>/dev/null
		sleep 2
		if [[ "$FORMATADISCO" =~ (nvme|mmcblk) ]]; then
			PART_DEV="/dev/${FORMATADISCO}p1"
		else
			PART_DEV="/dev/${FORMATADISCO}1"
		fi
		mkfs.ext4 -F -L $STORAGE $PART_DEV
		mkdir -p /mnt/$STORAGE
		sed -i /"$STORAGE"/d /etc/fstab
		echo "" >> /etc/fstab
		echo "LABEL=$STORAGE /mnt/$STORAGE ext4 defaults,auto,nofail 0 0" >> /etc/fstab
		mount -a
		pvesm add dir $STORAGE --path /mnt/$STORAGE --content $IMAGEBACKUP 
		read -p "${LANG_PVE_PRESS_CONT:-Pressione uma tecla para continuar...}"
		clear
		disco_menu
			;;
		2) clear
		lvremove -y /dev/pve/data
		lvresize -l +100%FREE /dev/pve/root
		resize2fs /dev/mapper/pve-root
		pvesm remove local-lvm
		read -p "${LANG_PVE_PRESS_CONT:-Pressione uma tecla para continuar...}"
		disco_menu
			;;
		3) clear
		# Carregar menu_ceph.sh se ainda não foi carregado
		if ! type ceph_menu &>/dev/null; then
			# Tentar vários caminhos possíveis
			local ceph_script=""
			if [ -n "$SCRIPT_DIR" ] && [ -f "$SCRIPT_DIR/functions/pve/menu_ceph.sh" ]; then
				ceph_script="$SCRIPT_DIR/functions/pve/menu_ceph.sh"
			elif [ -n "$FUNCTIONS_DIR" ] && [ -f "$FUNCTIONS_DIR/pve/menu_ceph.sh" ]; then
				ceph_script="$FUNCTIONS_DIR/pve/menu_ceph.sh"
			elif [ -f "$(dirname "${BASH_SOURCE[0]}")/menu_ceph.sh" ]; then
				ceph_script="$(dirname "${BASH_SOURCE[0]}")/menu_ceph.sh"
			elif [ -f "/TcTI/SCRIPTS/PROXMOX/functions/pve/menu_ceph.sh" ]; then
				ceph_script="/TcTI/SCRIPTS/PROXMOX/functions/pve/menu_ceph.sh"
			elif [ -f "functions/pve/menu_ceph.sh" ]; then
				ceph_script="functions/pve/menu_ceph.sh"
			fi
			
			if [ -n "$ceph_script" ] && [ -f "$ceph_script" ]; then
				source "$ceph_script"
			fi
		fi
		
		if type ceph_menu &>/dev/null; then
			ceph_menu
		else
echo -e  "${LANG_AUTO_MENU_DISCO_494:-${COLOR_RED}${COLOR_BOLD}✗ ERRO: Função ceph_menu não encontrada${COLOR_RESET}}"
			echo ""
echo -e  "${LANG_AUTO_MENU_DISCO_495:-${COLOR_YELLOW}O arquivo menu_ceph.sh não foi carregado corretamente.${COLOR_RESET}}"
echo -e  "${LANG_AUTO_MENU_DISCO_496:-${COLOR_YELLOW}Verifique se o arquivo existe em:${COLOR_RESET}}"
echo -e  "${LANG_AUTO_MENU_DISCO_497:-${COLOR_GRAY}  - functions/pve/menu_ceph.sh${COLOR_RESET}}"
echo -e  "${LANG_AUTO_MENU_DISCO_498:-${COLOR_GRAY}  - /TcTI/SCRIPTS/PROXMOX/functions/pve/menu_ceph.sh${COLOR_RESET}}"
			echo ""
			read -p "${LANG_PVE_PRESS_CONT:-Pressione uma tecla para continuar...}"
			disco_menu
		fi
			;;			
		0) clear;
		pve_menu;
			;;
		*)clear;
		pve_menu;
			;;
      esac
    fi
  done
}

