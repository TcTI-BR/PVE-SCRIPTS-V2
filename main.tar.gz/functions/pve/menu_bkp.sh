#!/bin/bash

# Menu de tarefas de backup do Proxmox VE
# Atualizado com:
#   - Seleção numérica simplificada de pastas em /mnt/ (1, 2, 3...)
#   - Backup e Restauração de Containers LXC (/etc/pve/nodes/$PVENAME/lxc/*.conf)
#   - Política de retenção de 120 dias (limpeza automática de backups antigos)
#   - Layout moderno e consistente

bkp_menu(){
	clear
	
	echo -e "${COLOR_CYAN}${COLOR_BOLD}"
	echo -e "╔═════════════════════════════════════════════════════════════════════╗"
	ui_print_header_line "" "" 69
	ui_print_header_line "💼 ${LANG_BKP_MENU_TITLE:-Tarefas de Backup}" "${COLOR_WHITE}" 69
	ui_print_header_line "" "" 69
	echo -e "╚═════════════════════════════════════════════════════════════════════╝"
	echo -e "${COLOR_RESET}"
	echo ""
	echo -e "${COLOR_BOLD}  ${LANG_SELECT_OPT:-Selecione uma opção:}${COLOR_RESET}"
	echo ""
	echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	
	ui_print_menu_item "1" "${LANG_BKP_MENU_OPT_1}"
	ui_print_menu_item "2" "${LANG_BKP_MENU_OPT_2}"
	ui_print_menu_item "3" "${LANG_BKP_MENU_OPT_3}"
	ui_print_menu_item "4" "${LANG_BKP_MENU_OPT_4}"
	
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	
	ui_print_menu_item "0" "${LANG_VM_OP_OPT_0:-Voltar}" "${COLOR_RED}"
	
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
	echo ""
	echo -e "${COLOR_YELLOW}  ${LANG_TYPE_OPT:-Digite sua opção} ${COLOR_GRAY}${LANG_PRESS_ENTER:-(ou pressione ENTER para sair)}${COLOR_YELLOW}: ${COLOR_RESET}"
	read -rsn1 opt
	while [ "$opt" != '' ]	
	do
		if [[ $opt = "" ]]; then
			exit;
		else
			case $opt in
				1) clear
echo -e  "${COLOR_CYAN}${COLOR_BOLD}Configuração do Serviço NFS para Backup${COLOR_RESET}\n"
				echo -e "${COLOR_WHITE}${LANG_BKP_ASK_IP:-Qual o IP do computador cliente?} ${COLOR_GRAY}(Ex: 192.168.0.230)${COLOR_RESET}"
				read -p "  IP: " IPDOCLIENTENFS
				echo -e "${COLOR_WHITE}${LANG_BKP_ASK_STG:-Qual o Storage de Backup?} ${COLOR_GRAY}(Ex: BACKUP_2HD)${COLOR_RESET}"
read -p  "  Storage: " STORAGEBACKUP
				
				apt-get install nfs-kernel-server -y
echo "/mnt/$STORAGEBACKUP/ $IPDOCLIENTENFS(rw,async,no_subtree_check)" > /etc/exports
				service nfs-kernel-server restart
				exportfs -a
				chmod -R 777 /mnt/$STORAGEBACKUP/dump 2>/dev/null
				echo ""
echo -e  "${COLOR_GREEN}✓ Serviço NFS configurado com sucesso!${COLOR_RESET}"
				read -p "  ${LANG_PBS_PRESS_CONT:-${LANG_PVE_PRESS_ENTER:-Pressione ENTER para continuar...}}"
				clear
				bkp_menu
				;;
				2) clear
echo -e  "${COLOR_CYAN}${COLOR_BOLD}Instalação do Proxmox Backup Server Lado a Lado${COLOR_RESET}\n"
echo "deb http://download.proxmox.com/debian/pbs $distribution pbs-no-subscription" >> /etc/apt/sources.list
				apt update
				apt-get install proxmox-backup-server -y
				echo ""
				echo -e "${COLOR_GREEN}✓ ${LANG_BKP_PBS_SUC:-PBS Instalado com sucesso!}${COLOR_RESET}"
				read -p "  ${LANG_PBS_PRESS_CONT:-${LANG_PVE_PRESS_ENTER:-Pressione ENTER para continuar...}}"
				clear
				bkp_menu
				;;
				3) clear
				echo -e "${COLOR_CYAN}${COLOR_BOLD}"
				echo -e "╔═════════════════════════════════════════════════════════════════════╗"
echo -e  "║          📅 Agendamento de Backup de Configurações PVE               ║"
				echo -e "╚═════════════════════════════════════════════════════════════════════╝"
				echo -e "${COLOR_RESET}"
				echo ""
				
				local mnt_dirs=()
				echo -e "${COLOR_CYAN}  📁 ${LANG_BKP_SEL_MNT:-Selecione a pasta em /mnt/ para armazenar os backups:}${COLOR_RESET}"
				shopt -s nullglob
				for d in /mnt/*/; do
					[ -d "$d" ] || continue
					local dname=$(basename "$d")
					[ "$dname" = "RECUPERAPVE" ] && continue
					mnt_dirs+=("$dname")
				done
				shopt -u nullglob

				local CAMINHOBKP=""
				if [ ${#mnt_dirs[@]} -gt 0 ]; then
					local idx=1
					for dname in "${mnt_dirs[@]}"; do
						local df_info=$(df -h "/mnt/$dname" 2>/dev/null | tail -n1 | awk '{print $4 " livre de " $2}')
echo -e  "    ${COLOR_YELLOW}${idx})${COLOR_RESET} ${COLOR_WHITE}${dname}${COLOR_RESET} ${COLOR_GRAY}(/mnt/${dname} — ${df_info})${COLOR_RESET}"
						idx=$((idx + 1))
					done
echo -e  "    ${COLOR_YELLOW}${idx})${COLOR_RESET} ${COLOR_GRAY}Digitar nome manualmente${COLOR_RESET}"
					echo ""
					read -p "  ${LANG_BKP_SEL_OPT:-Selecione a opção} [1-${idx}]: " choice_dir

					if [[ "$choice_dir" =~ ^[0-9]+$ ]] && [ "$choice_dir" -ge 1 ] && [ "$choice_dir" -le ${#mnt_dirs[@]} ]; then
						CAMINHOBKP="${mnt_dirs[$((choice_dir - 1))]}"
					elif [ "$choice_dir" = "$idx" ]; then
						read -p "  ${LANG_BKP_TYPE_MNT:-Digite a pasta: }" CAMINHOBKP
					else
						CAMINHOBKP="$choice_dir"
					fi
				else
echo -e  "    ${COLOR_GRAY}(Nenhuma pasta encontrada em /mnt/)${COLOR_RESET}"
					echo ""
					read -p "  ${LANG_BKP_TYPE_MNT_NAME:-Digite o nome da pasta em /mnt/: }" CAMINHOBKP
				fi

				if [ -z "$CAMINHOBKP" ]; then
echo -e  "${COLOR_RED}  ✗ Nenhuma pasta selecionada. Operação cancelada.${COLOR_RESET}"
					sleep 2
					bkp_menu
					return
				fi
echo -e  "${COLOR_GREEN}  ✓ Pasta selecionada: /mnt/${CAMINHOBKP}${COLOR_RESET}"
				echo ""
				echo -e "${COLOR_WHITE}  ${LANG_BKP_ASK_EMAIL:-Qual o e-mail para receber cópia das configurações?}${COLOR_RESET}"
read -p  "  E-mail: " CAMINHOEMAILBKP

				mkdir -p "/mnt/$CAMINHOBKP/BKP-PVE"
				mkdir -p "/TcTI/SCRIPTS/BKP-PVE/TEMP-BKP/QEMU"
				mkdir -p "/TcTI/SCRIPTS/BKP-PVE/TEMP-BKP/LXC"

				cat > /TcTI/SCRIPTS/BKP-PVE/BKP-PVE.sh << 'EOF'
#!/bin/bash
EOF
echo "CAMINHOLOCAL=\"$CAMINHOBKP\"" >> /TcTI/SCRIPTS/BKP-PVE/BKP-PVE.sh
echo "PVENAME=\"$(hostname)\"" >> /TcTI/SCRIPTS/BKP-PVE/BKP-PVE.sh
echo "CAMINHOEMAIL=\"$CAMINHOEMAILBKP\"" >> /TcTI/SCRIPTS/BKP-PVE/BKP-PVE.sh

				cat >> /TcTI/SCRIPTS/BKP-PVE/BKP-PVE.sh << 'EOF'

# Prepara diretórios temporários para QEMU e LXC
mkdir -p /TcTI/SCRIPTS/BKP-PVE/TEMP-BKP/QEMU
mkdir -p /TcTI/SCRIPTS/BKP-PVE/TEMP-BKP/LXC

# Copia configurações de VMs KVM e Containers LXC
cp -r /etc/pve/nodes/$PVENAME/qemu-server/*.conf /TcTI/SCRIPTS/BKP-PVE/TEMP-BKP/QEMU/ 2>/dev/null
cp -r /etc/pve/nodes/$PVENAME/lxc/*.conf /TcTI/SCRIPTS/BKP-PVE/TEMP-BKP/LXC/ 2>/dev/null

# Compacta os arquivos essenciais do Proxmox
BKP_ZIP="/mnt/$CAMINHOLOCAL/BKP-PVE/$(date +%d-%m-%Y).zip"

zip "$BKP_ZIP" /etc/pve/vzdump.cron 2>/dev/null
zip "$BKP_ZIP" /etc/pve/storage.cfg 2>/dev/null
zip "$BKP_ZIP" /etc/pve/user.cfg 2>/dev/null
zip "$BKP_ZIP" /etc/pve/datacenter.cfg 2>/dev/null
zip "$BKP_ZIP" /etc/pve/jobs.cfg 2>/dev/null
zip "$BKP_ZIP" /etc/network/interfaces 2>/dev/null
zip "$BKP_ZIP" /etc/resolv.conf 2>/dev/null
zip "$BKP_ZIP" /var/spool/cron/crontabs/root 2>/dev/null
zip "$BKP_ZIP" /etc/hostname 2>/dev/null
zip "$BKP_ZIP" /etc/hosts 2>/dev/null
zip "$BKP_ZIP" /etc/fstab 2>/dev/null
zip "$BKP_ZIP" /etc/postfix/ 2>/dev/null
zip "$BKP_ZIP" /TcTI/SCRIPTS/BKP-PVE/TEMP-BKP/QEMU/*.conf 2>/dev/null
zip "$BKP_ZIP" /TcTI/SCRIPTS/BKP-PVE/TEMP-BKP/LXC/*.conf 2>/dev/null

# Limpeza automática: mantém backups dos últimos 120 dias
find "/mnt/$CAMINHOLOCAL/BKP-PVE/" -name "*.zip" -type f -mtime +120 -delete 2>/dev/null

# Envio por e-mail se mutt estiver disponível
if command -v mutt &>/dev/null && [ -n "$CAMINHOEMAIL" ]; then
echo "Log de backup do dia $(date +%d-%m-%Y)" > /TcTI/SCRIPTS/BKP-PVE/msg.txt
    mutt -s "$(hostname -f) - Backup diário das configurações" "$CAMINHOEMAIL" < /TcTI/SCRIPTS/BKP-PVE/msg.txt -a "$BKP_ZIP" 2>/dev/null
fi
EOF

				chmod +x /TcTI/SCRIPTS/BKP-PVE/BKP-PVE.sh
				sed -i '/BKP-PVE/d' /var/spool/cron/crontabs/root
echo "0 0 * * * /TcTI/SCRIPTS/BKP-PVE/BKP-PVE.sh" >> /var/spool/cron/crontabs/root
				
				# Executa primeiro backup
				/TcTI/SCRIPTS/BKP-PVE/BKP-PVE.sh

				clear
				echo -e "${COLOR_GREEN}${COLOR_BOLD}  ✓ ${LANG_BKP_CONF_SCHED_SUC:-Backup de Configurações Agendado com Sucesso!}${COLOR_RESET}"
				echo -e "  ${COLOR_CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${COLOR_RESET}"
echo -e  "    ${COLOR_WHITE}Frequência:${COLOR_RESET}   ${COLOR_YELLOW}Todos os dias às 00:00 (Cron)${COLOR_RESET}"
echo -e  "    ${COLOR_WHITE}Destino Local:${COLOR_RESET} ${COLOR_YELLOW}/mnt/${CAMINHOBKP}/BKP-PVE/${COLOR_RESET}"
echo -e  "    ${COLOR_WHITE}E-mail:${COLOR_RESET}        ${COLOR_YELLOW}${CAMINHOEMAILBKP}${COLOR_RESET}"
echo -e  "    ${COLOR_WHITE}Inclui:${COLOR_RESET}        ${COLOR_YELLOW}VMs (KVM), Containers (LXC), Rede, Storages, Crontab${COLOR_RESET}"
echo -e  "    ${COLOR_WHITE}Retenção:${COLOR_RESET}      ${COLOR_YELLOW}120 dias (limpeza automática dos anteriores)${COLOR_RESET}"
				echo -e "  ${COLOR_CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${COLOR_RESET}"
				echo ""
				read -p "  ${LANG_PBS_PRESS_CONT:-${LANG_PVE_PRESS_ENTER:-Pressione ENTER para continuar...}}"
				clear
				bkp_menu
				;;
				4) clear
				echo -e "${COLOR_RED}${COLOR_BOLD}"
				echo -e "╔═════════════════════════════════════════════════════════════════════╗"
echo -e  "║      ⚠️  ATENÇÃO: RESTAURAÇÃO DE CONFIGURAÇÕES DO PROXMOX           ║"
				echo -e "╚═════════════════════════════════════════════════════════════════════╝"
				echo -e "${COLOR_RESET}"
				echo -e "${COLOR_YELLOW}  ${LANG_BKP_RESTORE_WARN:-Esta opção irá restaurar as configurações selecionadas do backup.}${COLOR_RESET}"
				echo ""

				local mnt_dirs=()
				echo -e "${COLOR_CYAN}  📁 ${LANG_BKP_RESTORE_DIR:-Selecione a pasta em /mnt/ onde estão os backups:}${COLOR_RESET}"
				shopt -s nullglob
				for d in /mnt/*/; do
					[ -d "$d" ] || continue
					local dname=$(basename "$d")
					[ "$dname" = "RECUPERAPVE" ] && continue
					mnt_dirs+=("$dname")
				done
				shopt -u nullglob

				local RECUPERABKP=""
				if [ ${#mnt_dirs[@]} -gt 0 ]; then
					local idx=1
					for dname in "${mnt_dirs[@]}"; do
						local df_info=$(df -h "/mnt/$dname" 2>/dev/null | tail -n1 | awk '{print $4 " livre de " $2}')
echo -e  "    ${COLOR_YELLOW}${idx})${COLOR_RESET} ${COLOR_WHITE}${dname}${COLOR_RESET} ${COLOR_GRAY}(/mnt/${dname} — ${df_info})${COLOR_RESET}"
						idx=$((idx + 1))
					done
echo -e  "    ${COLOR_YELLOW}${idx})${COLOR_RESET} ${COLOR_GRAY}Digitar nome manualmente${COLOR_RESET}"
					echo ""
					read -p "  ${LANG_BKP_SEL_OPT:-Selecione a opção} [1-${idx}]: " choice_dir

					if [[ "$choice_dir" =~ ^[0-9]+$ ]] && [ "$choice_dir" -ge 1 ] && [ "$choice_dir" -le ${#mnt_dirs[@]} ]; then
						RECUPERABKP="${mnt_dirs[$((choice_dir - 1))]}"
					elif [ "$choice_dir" = "$idx" ]; then
						read -p "  ${LANG_BKP_TYPE_MNT:-Digite a pasta: }" RECUPERABKP
					else
						RECUPERABKP="$choice_dir"
					fi
				else
echo -e  "    ${COLOR_GRAY}(Nenhuma pasta encontrada em /mnt/)${COLOR_RESET}"
					echo ""
					read -p "  ${LANG_BKP_TYPE_MNT_NAME:-Digite o nome da pasta em /mnt/: }" RECUPERABKP
				fi

				if [ -z "$RECUPERABKP" ]; then
echo -e  "${COLOR_RED}  ✗ Nenhuma pasta selecionada. Operação cancelada.${COLOR_RESET}"
					sleep 2
					bkp_menu
					return
				fi

				mkdir -p /mnt/RECUPERAPVE
				local PVENAME=$(hostname)
				mount LABEL=$RECUPERABKP /mnt/RECUPERAPVE 2>/dev/null
				if [ ! -d "/mnt/RECUPERAPVE/BKP-PVE" ]; then
					mount "/mnt/$RECUPERABKP" /mnt/RECUPERAPVE 2>/dev/null
				fi

				local bkp_path=""
				if [ -d "/mnt/RECUPERAPVE/BKP-PVE" ]; then
					bkp_path="/mnt/RECUPERAPVE/BKP-PVE"
				elif [ -d "/mnt/$RECUPERABKP/BKP-PVE" ]; then
					bkp_path="/mnt/$RECUPERABKP/BKP-PVE"
				else
echo -e  "${COLOR_RED}  ✗ Pasta BKP-PVE não encontrada em /mnt/${RECUPERABKP}.${COLOR_RESET}"
					umount /mnt/RECUPERAPVE/ 2>/dev/null
					rmdir /mnt/RECUPERAPVE/ 2>/dev/null
					sleep 3
					bkp_menu
					return
				fi

				echo ""
echo -e  "${COLOR_CYAN}  Backups encontrados em ${bkp_path}:${COLOR_RESET}"
				ls -t "$bkp_path" | grep "\.zip$"
				echo ""
				echo -e "${COLOR_WHITE}  ${LANG_BKP_ASK_DATE:-Digite a data do arquivo a recuperar }${COLOR_GRAY}(Ex: 25-07-2026)${COLOR_RESET}:"
read -p  "  Data: " RESTAURABKP

				local zip_file="${bkp_path}/${RESTAURABKP}.zip"
				if [ ! -f "$zip_file" ]; then
					echo -e "${COLOR_RED}  ✗ ${LANG_BKP_ERR_FILE:-Arquivo não encontrado.} ('${zip_file}')${COLOR_RESET}"
					umount /mnt/RECUPERAPVE/ 2>/dev/null
					rmdir /mnt/RECUPERAPVE/ 2>/dev/null
					sleep 3
					bkp_menu
					return
				fi

				apt-get update -qq
				apt-get install zip unzip -y -qq
				mkdir -p /TcTI/SCRIPTS/TMP-RECUPERA
				rm -rf /TcTI/SCRIPTS/TMP-RECUPERA/*

				unzip "$zip_file" -d /TcTI/SCRIPTS/TMP-RECUPERA > /dev/null 2>&1

				echo ""
echo -e  "${COLOR_CYAN}  Iniciando processo de restauração selecionada:${COLOR_RESET}"
				echo ""

				# 1. Restaura VMs (QEMU)
				if [ -d "/TcTI/SCRIPTS/TMP-RECUPERA/TcTI/SCRIPTS/BKP-PVE/TEMP-BKP/QEMU" ]; then
read -p  "$(echo -e ${COLOR_YELLOW}"  ${LANG_BKP_RES_QEMU:-Deseja restaurar configurações de VMs (QEMU)? (s/N): }"${COLOR_RESET})" res_qemu
					if [[ "$res_qemu" =~ ^[Ss]$ ]]; then
						mkdir -p "/etc/pve/nodes/$PVENAME/qemu-server/"
						cp -r /TcTI/SCRIPTS/TMP-RECUPERA/TcTI/SCRIPTS/BKP-PVE/TEMP-BKP/QEMU/*.conf "/etc/pve/nodes/$PVENAME/qemu-server/" 2>/dev/null
echo -e  "${COLOR_GREEN}  ✓ Configurações de VMs QEMU restauradas.${COLOR_RESET}"
					fi
				fi

				# 2. Restaura Containers (LXC)
				if [ -d "/TcTI/SCRIPTS/TMP-RECUPERA/TcTI/SCRIPTS/BKP-PVE/TEMP-BKP/LXC" ]; then
read -p  "$(echo -e ${COLOR_YELLOW}"  ${LANG_BKP_RES_LXC:-Deseja restaurar configurações de Containers (LXC)? (s/N): }"${COLOR_RESET})" res_lxc
					if [[ "$res_lxc" =~ ^[Ss]$ ]]; then
						mkdir -p "/etc/pve/nodes/$PVENAME/lxc/"
						cp -r /TcTI/SCRIPTS/TMP-RECUPERA/TcTI/SCRIPTS/BKP-PVE/TEMP-BKP/LXC/*.conf "/etc/pve/nodes/$PVENAME/lxc/" 2>/dev/null
echo -e  "${COLOR_GREEN}  ✓ Configurações de Containers LXC restauradas.${COLOR_RESET}"
					fi
				fi

				# 3. Restaura fstab
				if [ -f "/TcTI/SCRIPTS/TMP-RECUPERA/etc/fstab" ]; then
read -p  "$(echo -e ${COLOR_YELLOW}"  ${LANG_BKP_RES_FSTAB:-Deseja restaurar o /etc/fstab? (s/N): }"${COLOR_RESET})" res_fstab
					if [[ "$res_fstab" =~ ^[Ss]$ ]]; then
						cp /TcTI/SCRIPTS/TMP-RECUPERA/etc/fstab /etc/fstab
echo -e  "${COLOR_GREEN}  ✓ /etc/fstab restaurado.${COLOR_RESET}"
					fi
				fi

				# 4. Restaura vzdump.cron
				if [ -f "/TcTI/SCRIPTS/TMP-RECUPERA/etc/pve/vzdump.cron" ]; then
read -p  "$(echo -e ${COLOR_YELLOW}"  ${LANG_BKP_RES_VZDUMP:-Deseja restaurar vzdump.cron? (s/N): }"${COLOR_RESET})" res_vzdump
					if [[ "$res_vzdump" =~ ^[Ss]$ ]]; then
						cp /TcTI/SCRIPTS/TMP-RECUPERA/etc/pve/vzdump.cron /etc/pve/vzdump.cron
echo -e  "${COLOR_GREEN}  ✓ vzdump.cron restaurado.${COLOR_RESET}"
					fi
				fi

				# 5. Restaura storage.cfg
				if [ -f "/TcTI/SCRIPTS/TMP-RECUPERA/etc/pve/storage.cfg" ]; then
read -p  "$(echo -e ${COLOR_YELLOW}"  ${LANG_BKP_RES_STG:-Deseja restaurar storage.cfg? (s/N): }"${COLOR_RESET})" res_storage
					if [[ "$res_storage" =~ ^[Ss]$ ]]; then
						cp /TcTI/SCRIPTS/TMP-RECUPERA/etc/pve/storage.cfg /etc/pve/storage.cfg
echo -e  "${COLOR_GREEN}  ✓ storage.cfg restaurado.${COLOR_RESET}"
					fi
				fi

				# 6. Restaura user.cfg
				if [ -f "/TcTI/SCRIPTS/TMP-RECUPERA/etc/pve/user.cfg" ]; then
read -p  "$(echo -e ${COLOR_YELLOW}"  Deseja restaurar user.cfg? (s/N): "${COLOR_RESET})" res_user
					if [[ "$res_user" =~ ^[Ss]$ ]]; then
						cp /TcTI/SCRIPTS/TMP-RECUPERA/etc/pve/user.cfg /etc/pve/user.cfg
echo -e  "${COLOR_GREEN}  ✓ user.cfg restaurado.${COLOR_RESET}"
					fi
				fi

				# 7. Restaura datacenter.cfg
				if [ -f "/TcTI/SCRIPTS/TMP-RECUPERA/etc/pve/datacenter.cfg" ]; then
read -p  "$(echo -e ${COLOR_YELLOW}"  Deseja restaurar datacenter.cfg? (s/N): "${COLOR_RESET})" res_dc
					if [[ "$res_dc" =~ ^[Ss]$ ]]; then
						cp /TcTI/SCRIPTS/TMP-RECUPERA/etc/pve/datacenter.cfg /etc/pve/datacenter.cfg
echo -e  "${COLOR_GREEN}  ✓ datacenter.cfg restaurado.${COLOR_RESET}"
					fi
				fi

				# 8. Restaura interfaces de rede
				if [ -f "/TcTI/SCRIPTS/TMP-RECUPERA/etc/network/interfaces" ]; then
read -p  "$(echo -e ${COLOR_YELLOW}"  Deseja restaurar /etc/network/interfaces? (s/N): "${COLOR_RESET})" res_net
					if [[ "$res_net" =~ ^[Ss]$ ]]; then
						cp /TcTI/SCRIPTS/TMP-RECUPERA/etc/network/interfaces /etc/network/interfaces
echo -e  "${COLOR_GREEN}  ✓ interfaces de rede restauradas.${COLOR_RESET}"
					fi
				fi

				# 9. Restaura resolv.conf
				if [ -f "/TcTI/SCRIPTS/TMP-RECUPERA/etc/resolv.conf" ]; then
read -p  "$(echo -e ${COLOR_YELLOW}"  Deseja restaurar /etc/resolv.conf? (s/N): "${COLOR_RESET})" res_resolv
					if [[ "$res_resolv" =~ ^[Ss]$ ]]; then
						cp /TcTI/SCRIPTS/TMP-RECUPERA/etc/resolv.conf /etc/resolv.conf
echo -e  "${COLOR_GREEN}  ✓ resolv.conf restaurado.${COLOR_RESET}"
					fi
				fi

				# 10. Restaura crontab do root
				if [ -f "/TcTI/SCRIPTS/TMP-RECUPERA/var/spool/cron/crontabs/root" ]; then
read -p  "$(echo -e ${COLOR_YELLOW}"  Deseja restaurar o crontab do root? (s/N): "${COLOR_RESET})" res_cron
					if [[ "$res_cron" =~ ^[Ss]$ ]]; then
						cp /TcTI/SCRIPTS/TMP-RECUPERA/var/spool/cron/crontabs/root /var/spool/cron/crontabs/root
echo -e  "${COLOR_GREEN}  ✓ crontab do root restaurado.${COLOR_RESET}"
					fi
				fi

				# 11. Restaura hostname
				if [ -f "/TcTI/SCRIPTS/TMP-RECUPERA/etc/hostname" ]; then
read -p  "$(echo -e ${COLOR_YELLOW}"  Deseja restaurar /etc/hostname? (s/N): "${COLOR_RESET})" res_host
					if [[ "$res_host" =~ ^[Ss]$ ]]; then
						cp /TcTI/SCRIPTS/TMP-RECUPERA/etc/hostname /etc/hostname
echo -e  "${COLOR_GREEN}  ✓ /etc/hostname restaurado.${COLOR_RESET}"
					fi
				fi

				# 12. Restaura hosts
				if [ -f "/TcTI/SCRIPTS/TMP-RECUPERA/etc/hosts" ]; then
read -p  "$(echo -e ${COLOR_YELLOW}"  Deseja restaurar /etc/hosts? (s/N): "${COLOR_RESET})" res_hosts
					if [[ "$res_hosts" =~ ^[Ss]$ ]]; then
						cp /TcTI/SCRIPTS/TMP-RECUPERA/etc/hosts /etc/hosts
echo -e  "${COLOR_GREEN}  ✓ /etc/hosts restaurado.${COLOR_RESET}"
					fi
				fi

				# 13. Restaura jobs.cfg
				if [ -f "/TcTI/SCRIPTS/TMP-RECUPERA/etc/pve/jobs.cfg" ]; then
read -p  "$(echo -e ${COLOR_YELLOW}"  Deseja restaurar /etc/pve/jobs.cfg? (s/N): "${COLOR_RESET})" res_jobs
					if [[ "$res_jobs" =~ ^[Ss]$ ]]; then
						cp /TcTI/SCRIPTS/TMP-RECUPERA/etc/pve/jobs.cfg /etc/pve/jobs.cfg
echo -e  "${COLOR_GREEN}  ✓ /etc/pve/jobs.cfg restaurado.${COLOR_RESET}"
					fi
				fi

				# 14. Restaura postfix
				if [ -d "/TcTI/SCRIPTS/TMP-RECUPERA/etc/postfix" ]; then
read -p  "$(echo -e ${COLOR_YELLOW}"  Deseja restaurar as configurações do Postfix (/etc/postfix/)? (s/N): "${COLOR_RESET})" res_post
					if [[ "$res_post" =~ ^[Ss]$ ]]; then
						cp -r /TcTI/SCRIPTS/TMP-RECUPERA/etc/postfix/ /etc/postfix/
echo -e  "${COLOR_GREEN}  ✓ /etc/postfix/ restaurado.${COLOR_RESET}"
					fi
				fi

				echo ""
echo -e  "${COLOR_GREEN}${COLOR_BOLD}  ✓ Restauração concluída!${COLOR_RESET}"
read -p  "  Deseja reiniciar o Proxmox agora? (s/N): " reb_opt
				umount /mnt/RECUPERAPVE/ 2>/dev/null
				rmdir /mnt/RECUPERAPVE/ 2>/dev/null
				rm -rf /TcTI/SCRIPTS/TMP-RECUPERA

				if [[ "$reb_opt" =~ ^[Ss]$ ]]; then
					reboot
				fi
				clear
				bkp_menu
				;;
				0) clear;
				pve_menu;
				;;
				*) clear;
				pve_menu;
				;;
			esac
		fi
	done
}
