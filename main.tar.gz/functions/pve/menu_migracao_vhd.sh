#!/bin/bash

# Assistente de Migração e Importação de Discos de Outros Hypervisors (Hyper-V, VMware, VirtualBox, KVM)
# Autor: TcTI-BR
# Suporta: .vhd, .vhdx, .vmdk, .vdi, .raw, .img, .qcow2
# Recursos:
#   - Criação assistida de nova VM ou seleção de VM existente
#   - Leitura estritamente segura/Read-Only dos discos de origem
#   - Progresso interativo com Porcentagem, Velocidade (MB/s) e Tempo Restante (ETA)
#   - Pergunta e anexo automático do disco na VM (scsi0) + ajuste da ordem de boot
#   - Notificação no início e fim via Bot de Notificações do Telegram

migracao_vhd_menu() {
    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}"
    echo -e "╔═════════════════════════════════════════════════════════════════════╗"
    echo -e "║                                                                     ║"
    echo -e "║    🚚 Assistente de Migração e Importação de Discos (VHD/VMDK/VDI)   ║"
    echo -e "║                                                                     ║"
    echo -e "╚═════════════════════════════════════════════════════════════════════╝"
    echo -e "${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_WHITE}  Suporta discos de: ${COLOR_YELLOW}Hyper-V (.vhd/.vhdx)${COLOR_WHITE}, ${COLOR_YELLOW}VMware (.vmdk)${COLOR_WHITE}, ${COLOR_YELLOW}VirtualBox (.vdi)${COLOR_WHITE}, ${COLOR_YELLOW}KVM (.qcow2/.raw)${COLOR_RESET}"
    echo -e "  ${COLOR_GRAY}Garantia de leitura 100% segura (Read-Only) nos arquivos de origem.${COLOR_RESET}"
    echo ""

    local vmid=""
    local vm_created=0

    # --------------------------------------------------------------------------
    # Passo 1: Criar VM ou Usar Existente?
    # --------------------------------------------------------------------------
    echo -e "${COLOR_BOLD}  Passo 1: Identificação da VM de Destino${COLOR_RESET}"
    read -p "  Deseja criar uma nova VM no Proxmox? (s/N): " criar_vm_opt

    if [[ "$criar_vm_opt" =~ ^[Ss]$ ]]; then
        local default_nextid
        default_nextid=$(pvesh get /cluster/nextid 2>/dev/null || echo "100")

        echo ""
        echo -e "${COLOR_CYAN}  ⚙️  Configuração da Nova VM:${COLOR_RESET}"
        read -p "    ID da VM [Padrão: ${default_nextid}]: " vmid_input
        vmid="${vmid_input:-$default_nextid}"

        # Validação do ID
        if ! [[ "$vmid" =~ ^[0-9]+$ ]]; then
            echo -e "${COLOR_RED}  ✗ ID inválido. Use apenas números.${COLOR_RESET}"
            sleep 2
            return
        fi

        if qm status "$vmid" &>/dev/null; then
            echo -e "${COLOR_RED}  ✗ Já existe uma VM com o ID ${vmid}!${COLOR_RESET}"
            sleep 2
            return
        fi

        read -p "    Nome da VM (Ex: VM-MIGRADA-01): " vm_name
        vm_name="${vm_name:-VM-MIGRADA-$vmid}"

        echo -e "    Tipo de Sistema Operacional:"
        echo -e "      1) Linux (Kernel 2.6/3.x/4.x/5.x/6.x) [Padrão]"
        echo -e "      2) Windows 10 / 11 / Server 2016-2022"
        echo -e "      3) Outro / Genérico"
        read -p "    Opção [1-3]: " ostype_opt
        local ostype="l26"
        case "$ostype_opt" in
            2) ostype="win11" ;;
            3) ostype="other" ;;
            *) ostype="l26" ;;
        esac

        echo -e "    Firmware / BIOS:"
        echo -e "      1) BIOS Legacy (SeaBIOS) [Padrão]"
        echo -e "      2) UEFI (OVMF)"
        read -p "    Opção [1-2]: " bios_opt
        local bios="seabios"
        if [ "$bios_opt" = "2" ]; then
            bios="ovmf"
        fi

        read -p "    Memória RAM em MB [Padrão: 4096]: " ram_input
        local ram="${ram_input:-4096}"

        read -p "    Núcleos de CPU (Cores) [Padrão: 2]: " cores_input
        local cores="${cores_input:-2}"

        read -p "    Interface de Rede (Bridge) [Padrão: vmbr0]: " bridge_input
        local bridge="${bridge_input:-vmbr0}"

        echo ""
        echo -e "${COLOR_YELLOW}  Criando VM ${vmid} (${vm_name})...${COLOR_RESET}"
        qm create "$vmid" \
            --name "$vm_name" \
            --ostype "$ostype" \
            --bios "$bios" \
            --cores "$cores" \
            --sockets 1 \
            --memory "$ram" \
            --net0 "virtio,bridge=$bridge" \
            --scsihw "virtio-scsi-pci" &>/dev/null

        if [ $? -ne 0 ]; then
            echo -e "${COLOR_RED}  ✗ Erro ao criar a VM ${vmid}.${COLOR_RESET}"
            sleep 2
            return
        fi

        vm_created=1
        echo -e "${COLOR_GREEN}  ✓ VM ${vmid} criada com sucesso!${COLOR_RESET}"
    else
        echo ""
        read -p "  Digite o ID da VM existente no Proxmox (Ex: 100): " vmid
        vmid=$(echo "$vmid" | tr -d ' ')

        if ! [[ "$vmid" =~ ^[0-9]+$ ]] || ! qm status "$vmid" &>/dev/null; then
            echo -e "${COLOR_RED}  ✗ VM ID ${vmid} não existe neste servidor.${COLOR_RESET}"
            sleep 2
            return
        fi
        echo -e "${COLOR_GREEN}  ✓ VM ${vmid} localizada com sucesso.${COLOR_RESET}"
    fi

    # --------------------------------------------------------------------------
    # Passo 2: Seleção da Pasta de Origem
    # --------------------------------------------------------------------------
    echo ""
    echo -e "${COLOR_BOLD}  Passo 2: Pasta onde estão os arquivos de disco${COLOR_RESET}"
    read -p "  Caminho do diretório (Ex: /mnt/hd_externo ou /root/disks): " src_dir

    if [ ! -d "$src_dir" ]; then
        echo -e "${COLOR_RED}  ✗ O diretório '${src_dir}' não existe ou não é acessível.${COLOR_RESET}"
        sleep 2
        return
    fi

    # --------------------------------------------------------------------------
    # Passo 3: Listar e Selecionar o Arquivo de Disco
    # --------------------------------------------------------------------------
    echo ""
    echo -e "${COLOR_YELLOW}  🔎 Buscando imagens de disco em '${src_dir}'...${COLOR_RESET}"

    local disk_files=()
    shopt -s nullglob nocaseglob
    for f in "$src_dir"/*.{vhd,vhdx,vmdk,vdi,raw,img,qcow2,qcow} "$src_dir"/*/*.{vhd,vhdx,vmdk,vdi,raw,img,qcow2,qcow}; do
        [ -f "$f" ] || continue
        disk_files+=("$f")
    done
    shopt -u nullglob nocaseglob

    if [ ${#disk_files[@]} -eq 0 ]; then
        echo -e "${COLOR_RED}  ✗ Nenhuma imagem de disco (.vhd, .vhdx, .vmdk, .vdi, .qcow2, .raw) encontrada em '${src_dir}'.${COLOR_RESET}"
        sleep 3
        return
    fi

    echo ""
    echo -e "${COLOR_CYAN}  Discos encontrados:${COLOR_RESET}"
    local idx=1
    for f in "${disk_files[@]}"; do
        local fname
        fname=$(basename "$f")
        local fsize
        fsize=$(ls -lh "$f" 2>/dev/null | awk '{print $5}')
        echo -e "    ${COLOR_YELLOW}${idx})${COLOR_RESET} ${COLOR_WHITE}${fname}${COLOR_RESET} ${COLOR_GRAY}(${fsize})${COLOR_RESET}"
        idx=$((idx + 1))
    done

    echo ""
    read -p "  Selecione o número do disco a importar [1-${#disk_files[@]}]: " disk_choice

    if ! [[ "$disk_choice" =~ ^[0-9]+$ ]] || [ "$disk_choice" -lt 1 ] || [ "$disk_choice" -gt ${#disk_files[@]} ]; then
        echo -e "${COLOR_RED}  ✗ Escolha inválida.${COLOR_RESET}"
        sleep 2
        return
    fi

    local selected_disk="${disk_files[$((disk_choice - 1))]}"
    local selected_filename
    selected_filename=$(basename "$selected_disk")
    local selected_size
    selected_size=$(ls -lh "$selected_disk" 2>/dev/null | awk '{print $5}')

    echo -e "${COLOR_GREEN}  ✓ Disco selecionado: ${selected_filename} (${selected_size})${COLOR_RESET}"

    # --------------------------------------------------------------------------
    # Passo 4: Escolha do Formato de Destino
    # --------------------------------------------------------------------------
    echo ""
    echo -e "${COLOR_BOLD}  Passo 4: Formato do Disco no Proxmox${COLOR_RESET}"
    echo -e "    1) qcow2 (QEMU Copy-On-Write — Recomendado para arquivos/NFS/CIFS) [Padrão]"
    echo -e "    2) raw   (Raw Disk Image — Desempenho máximo / Padrão ZFS/LVM-Thin)"
    echo -e "    3) vmdk  (VMware Format)"
    read -p "  Opção [1-3]: " fmt_choice

    local target_format="qcow2"
    case "$fmt_choice" in
        2) target_format="raw" ;;
        3) target_format="vmdk" ;;
        *) target_format="qcow2" ;;
    esac

    # --------------------------------------------------------------------------
    # Passo 5: Escolha do Storage de Destino
    # --------------------------------------------------------------------------
    echo ""
    echo -e "${COLOR_BOLD}  Passo 5: Storage de Destino no Proxmox${COLOR_RESET}"

    local storage_list=()
    while read -r line; do
        [ -z "$line" ] && continue
        local sname
        sname=$(echo "$line" | awk '{print $1}')
        local stype
        stype=$(echo "$line" | awk '{print $2}')
        local sstatus
        sstatus=$(echo "$line" | awk '{print $3}')
        if [ "$sstatus" = "active" ]; then
            storage_list+=("$sname")
        fi
    done < <(pvesm status 2>/dev/null | tail -n +2)

    if [ ${#storage_list[@]} -eq 0 ]; then
        echo -e "${COLOR_RED}  ✗ Nenhum storage ativo encontrado no Proxmox.${COLOR_RESET}"
        sleep 2
        return
    fi

    echo -e "${COLOR_CYAN}  Storages ativos disponíveis:${COLOR_RESET}"
    idx=1
    for s in "${storage_list[@]}"; do
        echo -e "    ${COLOR_YELLOW}${idx})${COLOR_RESET} ${COLOR_WHITE}${s}${COLOR_RESET}"
        idx=$((idx + 1))
    done

    echo ""
    read -p "  Selecione o storage de destino [1-${#storage_list[@]}]: " stg_choice

    if ! [[ "$stg_choice" =~ ^[0-9]+$ ]] || [ "$stg_choice" -lt 1 ] || [ "$stg_choice" -gt ${#storage_list[@]} ]; then
        echo -e "${COLOR_RED}  ✗ Escolha de storage inválida.${COLOR_RESET}"
        sleep 2
        return
    fi

    local target_storage="${storage_list[$((stg_choice - 1))]}"
    echo -e "${COLOR_GREEN}  ✓ Storage de destino: ${target_storage}${COLOR_RESET}"

    # --------------------------------------------------------------------------
    # Passo 6: Pergunta de Anexo Automático & Ordem de Boot
    # --------------------------------------------------------------------------
    echo ""
    echo -e "${COLOR_BOLD}  Passo 6: Configuração de Anexo Automático${COLOR_RESET}"
    read -p "  Deseja anexar automaticamente como 'scsi0' e ajustar a ordem de boot? (S/n): " auto_attach_opt
    local auto_attach=1
    if [[ "$auto_attach_opt" =~ ^[Nn]$ ]]; then
        auto_attach=0
    fi

    # --------------------------------------------------------------------------
    # Resumo Final & Confirmação
    # --------------------------------------------------------------------------
    echo ""
    echo -e "${COLOR_CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${COLOR_RESET}"
    echo -e "${COLOR_BOLD}  📋 RESUMO DA MIGRAÇÃO:${COLOR_RESET}"
    echo -e "    ${COLOR_WHITE}VM ID:${COLOR_RESET}            ${COLOR_YELLOW}${vmid}${COLOR_RESET}"
    echo -e "    ${COLOR_WHITE}Arquivo Origem:${COLOR_RESET}   ${COLOR_YELLOW}${selected_filename}${COLOR_RESET} (${selected_size})"
    echo -e "    ${COLOR_WHITE}Storage Destino:${COLOR_RESET}  ${COLOR_YELLOW}${target_storage}${COLOR_RESET}"
    echo -e "    ${COLOR_WHITE}Formato Destino:${COLOR_RESET}  ${COLOR_YELLOW}${target_format}${COLOR_RESET}"
    echo -e "    ${COLOR_WHITE}Anexar como scsi0:${COLOR_RESET}${COLOR_YELLOW}$([ $auto_attach -eq 1 ] && echo 'Sim' || echo 'Não')${COLOR_RESET}"
    echo -e "${COLOR_CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${COLOR_RESET}"
    echo ""

    read -p "  Iniciar a importação agora? (s/N): " confirm_start
    if [[ ! "$confirm_start" =~ ^[Ss]$ ]]; then
        echo -e "${COLOR_GRAY}  Operação cancelada pelo usuário.${COLOR_RESET}"
        sleep 2
        return
    fi

    # --------------------------------------------------------------------------
    # Telegram: Notificação de Início
    # --------------------------------------------------------------------------
    local notif_file="/TcTI/SCRIPTS/telegram/.env_notificacoes"
    local has_telegram=0
    if [ -f "$NOTIF_CONFIG_FILE" ]; then
        has_telegram=1
    elif [ -f "$notif_file" ]; then
        has_telegram=1
        NOTIF_CONFIG_FILE="$notif_file"
    fi

    if [ $has_telegram -eq 1 ]; then
        source "$NOTIF_CONFIG_FILE" 2>/dev/null
        if [ -n "$NOTIF_BOT_TOKEN" ] && [ -n "$NOTIF_CHAT_ID" ]; then
            local host_name
            host_name=$(hostname)
            local msg_start="📣 *INÍCIO DE MIGRAÇÃO DE DISCO - TcTI PVE*%0A"
            msg_start+="Servidor: *${NOTIF_SERVER_NAME:-$host_name}*%0A"
            msg_start+="VM ID: *${vmid}*%0A"
            msg_start+="Arquivo Origem: *${selected_filename}* (${selected_size})%0A"
            msg_start+="Storage Destino: *${target_storage}* (${target_format})%0A"
            msg_start+="Status: Importação iniciada..."

            curl -s -o /dev/null -w "%{http_code}" -X POST \
                "https://api.telegram.org/bot${NOTIF_BOT_TOKEN}/sendMessage" \
                -d "chat_id=${NOTIF_CHAT_ID}&text=${msg_start}&parse_mode=Markdown" &>/dev/null &
        fi
    fi

    # --------------------------------------------------------------------------
    # Passo 7: Execução da Importação com Barra de Progresso Interativa (Python)
    # --------------------------------------------------------------------------
    echo ""
    echo -e "${COLOR_YELLOW}  🚀 Iniciando importação do disco... (Aguarde)${COLOR_RESET}"
    echo ""

    local start_time
    start_time=$(date +%s)

    # Executa a importação via script Python inline para barra de progresso com %, MB/s e ETA
    python3 - "$vmid" "$selected_disk" "$target_storage" "$target_format" << 'PYEOF'
import sys
import subprocess
import time
import re

vmid = sys.argv[1]
src_file = sys.argv[2]
storage = sys.argv[3]
fmt = sys.argv[4]

cmd = ["qm", "importdisk", vmid, src_file, storage, "--format", fmt]

process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, universal_newlines=True)

start_t = time.time()
last_transferred = 0

print("  ┌──────────────────────────────────────────────────────────────┐")

for line in process.stdout:
    line_clean = line.strip()
    
    # Procura por padrões de progresso do qm importdisk / qemu-img
    # Exemplo: transferred 1.5 GiB of 20.0 GiB (7.50%)
    # ou: (7.50/100%)
    match_pct = re.search(r'\((\d+\.?\d*)%\)', line_clean)
    match_trans = re.search(r'transferred\s+([\d\.]+)\s*(\w+)\s+of\s+([\d\.]+)\s*(\w+)', line_clean, re.IGNORECASE)
    
    if match_pct:
        pct = float(match_pct.group(1))
        now = time.time()
        elapsed = max(now - start_t, 1.0)
        
        # Desenha barra de progresso (30 caracteres)
        bar_len = 30
        filled = int(bar_len * pct / 100.0)
        bar = '█' * filled + '░' * (bar_len - filled)
        
        # Calcula ETA
        if pct > 0:
            total_est = (elapsed / pct) * 100.0
            eta_sec = max(int(total_est - elapsed), 0)
            eta_m, eta_s = divmod(eta_sec, 60)
            eta_str = f"{eta_m:02d}m {eta_s:02d}s"
        else:
            eta_str = "--m --s"
            
        sys.stdout.write(f"\r  │ [{bar}] {pct:5.1f}% | ETA: {eta_str} ")
        sys.stdout.flush()

process.wait()
print("\n  └──────────────────────────────────────────────────────────────┘")

sys.exit(process.returncode)
PYEOF

    local import_exit=$?
    local end_time
    end_time=$(date +%s)
    local duration=$((end_time - start_time))
    local dur_min=$((duration / 60))
    local dur_sec=$((duration % 60))
    local dur_str="${dur_min}m ${dur_sec}s"

    if [ $import_exit -ne 0 ]; then
        echo ""
        echo -e "${COLOR_RED}  ✗ Ocorreu um erro durante a importação do disco.${COLOR_RESET}"

        if [ $has_telegram -eq 1 ] && [ -n "$NOTIF_BOT_TOKEN" ] && [ -n "$NOTIF_CHAT_ID" ]; then
            local msg_err="🚨 *ERRO NA MIGRAÇÃO DE DISCO - TcTI PVE*%0A"
            msg_err+="VM ID: *${vmid}*%0A"
            msg_err+="Arquivo: *${selected_filename}*%0A"
            msg_err+="Status: Falha ao importar disco."
            curl -s -o /dev/null -w "%{http_code}" -X POST \
                "https://api.telegram.org/bot${NOTIF_BOT_TOKEN}/sendMessage" \
                -d "chat_id=${NOTIF_CHAT_ID}&text=${msg_err}&parse_mode=Markdown" &>/dev/null &
        fi
        sleep 3
        return
    fi

    echo ""
    echo -e "${COLOR_GREEN}  ✓ Importação concluída com sucesso em ${dur_str}!${COLOR_RESET}"

    # --------------------------------------------------------------------------
    # Passo 8: Anexo Automático & Ordem de Boot
    # --------------------------------------------------------------------------
    if [ $auto_attach -eq 1 ]; then
        echo ""
        echo -e "${COLOR_YELLOW}  🔌 Anexando disco à VM ${vmid} como 'scsi0'...${COLOR_RESET}"

        # Procura disco não utilizado na VM (unused0, unused1...)
        local unused_ref
        unused_ref=$(qm config "$vmid" | grep "^unused" | head -n1 | awk '{print $2}')

        if [ -n "$unused_ref" ]; then
            qm set "$vmid" --scsi0 "$unused_ref" &>/dev/null
            qm set "$vmid" --boot "order=scsi0" &>/dev/null
            echo -e "${COLOR_GREEN}  ✓ Disco anexado como 'scsi0' e definido como padrão na ordem de boot!${COLOR_RESET}"
        else
            # Tenta padrão de nome de disco Proxmox
            qm set "$vmid" --scsi0 "${target_storage}:vm-${vmid}-disk-0" &>/dev/null
            qm set "$vmid" --boot "order=scsi0" &>/dev/null
            echo -e "${COLOR_GREEN}  ✓ Ordem de boot configurada para 'scsi0'.${COLOR_RESET}"
        fi
    fi

    # --------------------------------------------------------------------------
    # Telegram: Notificação de Conclusão
    # --------------------------------------------------------------------------
    if [ $has_telegram -eq 1 ] && [ -n "$NOTIF_BOT_TOKEN" ] && [ -n "$NOTIF_CHAT_ID" ]; then
        local msg_end="✅ *MIGRAÇÃO DE DISCO CONCLUÍDA - TcTI PVE*%0A"
        msg_end+="Servidor: *${NOTIF_SERVER_NAME:-$(hostname)}*%0A"
        msg_end+="VM ID: *${vmid}*%0A"
        msg_end+="Arquivo: *${selected_filename}* (${selected_size})%0A"
        msg_end+="Storage: *${target_storage}*%0A"
        msg_end+="Tempo Total: *${dur_str}*%0A"
        msg_end+="Status: Sucesso! Disco importado e pronto para uso."

        curl -s -o /dev/null -w "%{http_code}" -X POST \
            "https://api.telegram.org/bot${NOTIF_BOT_TOKEN}/sendMessage" \
            -d "chat_id=${NOTIF_CHAT_ID}&text=${msg_end}&parse_mode=Markdown" &>/dev/null &
    fi

    echo ""
    echo -e "${COLOR_CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${COLOR_RESET}"
    read -p "  Pressione ENTER para voltar..."
}
