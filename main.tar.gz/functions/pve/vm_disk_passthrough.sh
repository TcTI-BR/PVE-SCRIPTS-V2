#!/bin/bash

# Assistente de Repasse de Discos Físicos (Passthrough) para VMs
# Criado para auxiliar P2V e clonagem direta de discos em modo Bloco.

vm_disk_passthrough_menu() {
    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}"
    echo -e "╔═════════════════════════════════════════════════════════════════════╗"
    echo -e "║                                                                     ║"
    echo -e "║    💽 ${LANG_PASSTHROUGH_MENU_TITLE:-Assistente de Repasse de Discos Físicos (Passthrough)}        ║"
    echo -e "║                                                                     ║"
    echo -e "╚═════════════════════════════════════════════════════════════════════╝"
    echo -e "${COLOR_RESET}"
    echo -e "  ${LANG_PASSTHROUGH_MENU_DESC_1:-Este assistente permite conectar um HD/SSD físico (via USB ou SATA)}"
    echo -e "  ${LANG_PASSTHROUGH_MENU_DESC_2:-diretamente a uma Máquina Virtual como um dispositivo de bloco.}"
    echo -e "  ${LANG_PASSTHROUGH_MENU_DESC_3:-➜ Ideal para P2V, clonagem com Clonezilla ou TrueNAS.}"
    echo ""
    echo -e "  ${COLOR_BOLD}${LANG_SELECT_OPT:-Selecione uma opção:}${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
    
    ui_print_menu_item "1" "${LANG_PASSTHROUGH_MENU_OPT_1}" "${COLOR_YELLOW}"
    ui_print_menu_item "2" "${LANG_PASSTHROUGH_MENU_OPT_2}" "${COLOR_YELLOW}"
    
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    
    ui_print_menu_item "0" "${LANG_VM_OP_OPT_0:-Voltar}" "${COLOR_RED}"
    
    echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_YELLOW}  ${LANG_TYPE_OPT:-Digite sua opção} ${COLOR_GRAY}${LANG_PRESS_ENTER:-(ou pressione ENTER para sair)}${COLOR_YELLOW}: ${COLOR_RESET}"
    
    read -rsn1 opt
    case $opt in
        1) attach_physical_disk ;;
        2) detach_physical_disk ;;
        0) clear; vm_operations_menu ;;
        *) vm_disk_passthrough_menu ;;
    esac
}

attach_physical_disk() {
    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}=== 🔗 ANEXAR DISCO FÍSICO ===${COLOR_RESET}\n"
    
    # 1. Selecionar VM
    echo -e "${COLOR_YELLOW}Buscando VMs disponíveis...${COLOR_RESET}"
    local vms=$(qm list | awk 'NR>1 {print $1"|"$2}')
    if [ -z "$vms" ]; then
        echo -e "${COLOR_RED}Nenhuma VM encontrada no servidor.${COLOR_RESET}"
        sleep 3
        vm_disk_passthrough_menu
        return
    fi
    
    local vm_ids=()
    local vm_names=()
    local i=1
    
    echo -e "\n${COLOR_BOLD}Selecione a VM que vai receber o disco físico:${COLOR_RESET}"
    for vm in $vms; do
        local id=$(echo "$vm" | cut -d'|' -f1)
        local name=$(echo "$vm" | cut -d'|' -f2)
        vm_ids+=($id)
        vm_names+=($name)
        echo -e "  ${COLOR_YELLOW}$i)${COLOR_RESET} VM ${id} - ${COLOR_CYAN}${name}${COLOR_RESET}"
        ((i++))
    done
    echo -e "  ${COLOR_RED}0)${COLOR_RESET} Cancelar e Voltar"
    
    echo -n -e "\n${COLOR_BOLD}Digite o número da VM:${COLOR_RESET} "
    read -r vm_choice
    
    if [ "$vm_choice" == "0" ] || [ -z "$vm_choice" ]; then
        vm_disk_passthrough_menu
        return
    fi
    
    if ! [[ "$vm_choice" =~ ^[0-9]+$ ]] || [ "$vm_choice" -lt 1 ] || [ "$vm_choice" -gt ${#vm_ids[@]} ]; then
        echo -e "${COLOR_RED}Opção inválida!${COLOR_RESET}"
        sleep 2
        attach_physical_disk
        return
    fi
    
    local selected_vmid=${vm_ids[$((vm_choice-1))]}
    local selected_vmname=${vm_names[$((vm_choice-1))]}
    
    # 2. Encontrar o próximo slot SCSI livre
    local free_scsi=-1
    for s in {1..14}; do
        if ! qm config $selected_vmid 2>/dev/null | grep -q "^scsi$s:"; then
            free_scsi=$s
            break
        fi
    done
    
    if [ $free_scsi -eq -1 ]; then
        echo -e "${COLOR_RED}Erro: A VM ${selected_vmid} não tem slots SCSI livres (scsi1 até scsi14 estão em uso).${COLOR_RESET}"
        sleep 3
        vm_disk_passthrough_menu
        return
    fi

    # 3. Listar discos físicos
    echo -e "\n${COLOR_YELLOW}Lendo discos físicos (USB/SATA/NVMe) conectados...${COLOR_RESET}"
    
    local disk_paths=()
    local disk_displays=()
    local d_idx=1
    
    echo -e "\n${COLOR_BOLD}Discos Encontrados no Servidor:${COLOR_RESET}"
    echo -e "${COLOR_GRAY}(Aviso: NUNCA selecione o disco onde o Proxmox está instalado!)${COLOR_RESET}\n"
    
    # Listar blocos físicos puros
    for dev_path in $(lsblk -n -p -d -o NAME | grep -v loop | grep -v sr); do
        local dev_name=$(basename "$dev_path")
        local size=$(lsblk -n -d -o SIZE "$dev_path" 2>/dev/null)
        local model=$(lsblk -n -d -o MODEL "$dev_path" 2>/dev/null | xargs)
        local tran=$(lsblk -n -d -o TRAN "$dev_path" 2>/dev/null)
        local fstype=$(lsblk -n -d -o FSTYPE "$dev_path" 2>/dev/null)
        
        # Pular discos LVM/ZFS que muito provavelmente são o root do Proxmox
        if [[ "$fstype" == "zfs_member" ]] || [[ "$fstype" == "LVM2_member" ]]; then
            continue
        fi
        
        # Encontrar o by-id correspondente (persistente)
        local by_id_path=""
        for p in /dev/disk/by-id/*; do
            if [[ "$p" == *"-part"* ]] || [[ "$p" == *"wwn-"* ]] || [[ "$p" == *"nvme-eui"* ]] || [[ "$p" == *"lvm-pv"* ]]; then
                continue
            fi
            if [ "$(readlink -f "$p")" == "$dev_path" ]; then
                by_id_path="$p"
                break
            fi
        done
        
        if [ -n "$by_id_path" ]; then
            local tran_color="${COLOR_WHITE}"
            if [[ "$tran" == "usb" ]]; then tran_color="${COLOR_GREEN}[USB]${COLOR_RESET}"; fi
            if [[ "$tran" == "sata" ]]; then tran_color="${COLOR_CYAN}[SATA]${COLOR_RESET}"; fi
            if [[ "$tran" == "nvme" ]]; then tran_color="${COLOR_MAGENTA}[NVMe]${COLOR_RESET}"; fi
            
            echo -e "  ${COLOR_YELLOW}$d_idx)${COLOR_RESET} ${tran_color} Disco: ${COLOR_WHITE}$dev_name${COLOR_RESET} | Tam: ${COLOR_YELLOW}$size${COLOR_RESET} | Modelo: ${COLOR_CYAN}${model:-Desconhecido}${COLOR_RESET}"
            disk_paths+=("$by_id_path")
            disk_displays+=("[$dev_name] $model ($size)")
            ((d_idx++))
        fi
    done
    
    if [ ${#disk_paths[@]} -eq 0 ]; then
        echo -e "${COLOR_RED}Nenhum disco físico secundário encontrado (ou todos pertencem ao Proxmox).${COLOR_RESET}"
        sleep 3
        vm_disk_passthrough_menu
        return
    fi
    
    echo -e "  ${COLOR_RED}0)${COLOR_RESET} Cancelar e Voltar"
    echo -n -e "\n${COLOR_BOLD}Qual disco deseja anexar à VM ${selected_vmname}?${COLOR_RESET} "
    read -r disk_choice
    
    if [ "$disk_choice" == "0" ] || [ -z "$disk_choice" ]; then
        vm_disk_passthrough_menu
        return
    fi
    
    if ! [[ "$disk_choice" =~ ^[0-9]+$ ]] || [ "$disk_choice" -lt 1 ] || [ "$disk_choice" -gt ${#disk_paths[@]} ]; then
        echo -e "${COLOR_RED}Opção inválida!${COLOR_RESET}"
        sleep 2
        attach_physical_disk
        return
    fi
    
    local selected_disk=${disk_paths[$((disk_choice-1))]}
    local display_disk=${disk_displays[$((disk_choice-1))]}
    
    echo -e "\n${COLOR_CYAN}Anexando disco ao slot scsi${free_scsi} da VM ${selected_vmid}...${COLOR_RESET}"
    echo -e "${COLOR_GRAY}Comando: qm set ${selected_vmid} -scsi${free_scsi} ${selected_disk}${COLOR_RESET}"
    
    if qm set ${selected_vmid} -scsi${free_scsi} "${selected_disk}"; then
        echo -e "\n${COLOR_GREEN}✅ SUCESSO!${COLOR_RESET}"
        echo -e "O disco físico ${COLOR_YELLOW}${display_disk}${COLOR_RESET} foi mapeado como disco nativo na VM ${selected_vmname}!"
        echo -e "Você já pode ligar a VM e ele aparecerá como um disco normal super rápido."
    else
        echo -e "\n${COLOR_RED}❌ ERRO ao anexar o disco!${COLOR_RESET}"
    fi
    
    echo -e "\nPressione ENTER para voltar..."
    read -r
    vm_disk_passthrough_menu
}

detach_physical_disk() {
    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}=== 🔓 DESANEXAR DISCO FÍSICO ===${COLOR_RESET}\n"
    
    echo -e "${COLOR_YELLOW}Buscando VMs com discos físicos mapeados...${COLOR_RESET}"
    local vms=$(qm list | awk 'NR>1 {print $1"|"$2}')
    local found_any=0
    
    local menu_items=()
    local menu_vmids=()
    local menu_slots=()
    local i=1
    
    for vm in $vms; do
        local id=$(echo "$vm" | cut -d'|' -f1)
        local name=$(echo "$vm" | cut -d'|' -f2)
        
        # Checa se a VM tem discos físicos em /dev/disk/
        local disks=$(qm config $id 2>/dev/null | grep -E "^scsi[0-9]+: /dev/disk/")
        if [ -n "$disks" ]; then
            while IFS= read -r line; do
                local slot=$(echo "$line" | cut -d':' -f1)
                local disk_path=$(echo "$line" | cut -d':' -f2 | awk '{print $1}')
                
                menu_items+=("VM $id ($name) -> Slot $slot ($disk_path)")
                menu_vmids+=("$id")
                menu_slots+=("$slot")
                found_any=1
            done <<< "$disks"
        fi
    done
    
    if [ $found_any -eq 0 ]; then
        echo -e "\n${COLOR_RED}Nenhum disco físico (Passthrough) encontrado em nenhuma VM.${COLOR_RESET}"
        sleep 3
        vm_disk_passthrough_menu
        return
    fi
    
    echo -e "\n${COLOR_BOLD}Discos Físicos Atualmente Conectados:${COLOR_RESET}"
    for (( idx=0; idx<${#menu_items[@]}; idx++ )); do
        echo -e "  ${COLOR_YELLOW}$((idx+1)))${COLOR_RESET} ${menu_items[$idx]}"
    done
    echo -e "  ${COLOR_RED}0)${COLOR_RESET} Cancelar e Voltar"
    
    echo -n -e "\n${COLOR_BOLD}Qual disco deseja DESCONECTAR da VM?${COLOR_RESET} "
    read -r detach_choice
    
    if [ "$detach_choice" == "0" ] || [ -z "$detach_choice" ]; then
        vm_disk_passthrough_menu
        return
    fi
    
    if ! [[ "$detach_choice" =~ ^[0-9]+$ ]] || [ "$detach_choice" -lt 1 ] || [ "$detach_choice" -gt ${#menu_items[@]} ]; then
        echo -e "${COLOR_RED}Opção inválida!${COLOR_RESET}"
        sleep 2
        detach_physical_disk
        return
    fi
    
    local sel_idx=$((detach_choice-1))
    local sel_vmid=${menu_vmids[$sel_idx]}
    local sel_slot=${menu_slots[$sel_idx]}
    
    echo -e "\n${COLOR_CYAN}Desconectando o disco ${sel_slot} da VM ${sel_vmid}...${COLOR_RESET}"
    echo -e "${COLOR_GRAY}Comando: qm unlink ${sel_vmid} --idlist ${sel_slot}${COLOR_RESET}"
    
    if qm unlink ${sel_vmid} --idlist ${sel_slot}; then
        echo -e "\n${COLOR_GREEN}✅ SUCESSO! O disco foi removido da VM com segurança.${COLOR_RESET}"
    else
        echo -e "\n${COLOR_RED}❌ ERRO ao remover o disco da VM! A VM está desligada?${COLOR_RESET}"
    fi
    
    echo -e "\nPressione ENTER para voltar..."
    read -r
    vm_disk_passthrough_menu
}
