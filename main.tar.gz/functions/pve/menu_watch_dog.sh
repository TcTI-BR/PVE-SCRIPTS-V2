#!/bin/bash

# Menu para configurar watchdog de VMs

watch_dog(){
	clear
	NORMAL=`echo "\033[m"`
	MENU=`echo "\033[36m"`
	NUMBER=`echo "\033[33m"`
	FGRED=`echo "\033[41m"`
	RED_TEXT=`echo "\033[31m"`
	ENTER_LINE=`echo "\033[33m"`
	
	echo -e "${COLOR_CYAN}${COLOR_BOLD}"
	echo -e "╔═════════════════════════════════════════════════════════════════════╗"
	echo -e "║                                                                     ║"
	echo -e "║                  🐕 ${LANG_WD_MENU_TITLE:-Configuração do Watchdog}                         ║"
	echo -e "║                                                                     ║"
	echo -e "╚═════════════════════════════════════════════════════════════════════╝"
	echo -e "${COLOR_RESET}"
	echo ""
	echo -e "${COLOR_WHITE}  ${LANG_WD_MENU_DESC:-Watchdog: Monitora VMs e reinicia automaticamente caso offline}${COLOR_RESET}"
	echo ""
	echo -e "${COLOR_BOLD}  ${LANG_SELECT_OPT:-Selecione uma opção:}${COLOR_RESET}"
	echo ""
	echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	
	ui_print_menu_item "1" "${LANG_WD_MENU_OPT_1}"
	ui_print_menu_item "2" "${LANG_WD_MENU_OPT_2}"
	ui_print_menu_item "3" "${LANG_WD_MENU_OPT_3}"
	ui_print_menu_item "4" "${LANG_WD_MENU_OPT_4}"
	ui_print_menu_item "5" "${LANG_WD_MENU_OPT_5}"
	
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	
	ui_print_menu_item "0" "${LANG_VM_OP_OPT_0:-Voltar}" "${COLOR_RED}"
	
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
	echo ""
	echo -e "${COLOR_YELLOW}  ${LANG_TYPE_OPT:-Digite sua opção} ${COLOR_GRAY}${LANG_PRESS_ENTER:-(ou pressione ENTER para sair)}${COLOR_YELLOW}: ${COLOR_RESET}"
	read -rsn1 opt
	while [ opt != '' ]	
	do
		if [[ $opt = "" ]]; then
			 exit;
		else
			case $opt in
				1) clear;
				sed -i '/WATCHDOG/d' /var/spool/cron/crontabs/root
				echo "*/10 * * * * /TcTI/SCRIPTS/WATCHDOG/*.sh" >> /var/spool/cron/crontabs/root
				read -p "Pressione uma tecla para continuar..."
				clear	  
				watch_dog
					;;
				2) clear;
				sed -i '/WATCHDOG/d' /var/spool/cron/crontabs/root
				read -p "Pressione uma tecla para continuar..."
				clear
				watch_dog
					;;
				3) clear;
				ls -t /TcTI/SCRIPTS/WATCHDOG/
				read -p "Pressione uma tecla para continuar..."
				clear
				watch_dog
					;;
				4) clear;
				echo "Qual ID da VM? EX: 230"
				read WATCHDOGVMID
				echo "Qual IP da VM? EX: 192.168.0.230"
				read WATCHDOGVMIP
				mkdir /TcTI/SCRIPTS/WATCHDOG/
				touch /TcTI/SCRIPTS/WATCHDOG/$WATCHDOGVMID.sh
				echo '#!/bin/bash' > /TcTI/SCRIPTS/WATCHDOG/$WATCHDOGVMID.sh
				echo 'ping -c4 $WATCHDOGVMIP > /dev/null' >> /TcTI/SCRIPTS/WATCHDOG/$WATCHDOGVMID.sh
				echo 'if [ $? != 1 ]' >> /TcTI/SCRIPTS/WATCHDOG/$WATCHDOGVMID.sh
				echo 'then' >> /TcTI/SCRIPTS/WATCHDOG/$WATCHDOGVMID.sh
				echo 'echo "Host encontrado"' >> /TcTI/SCRIPTS/WATCHDOG/$WATCHDOGVMID.sh
				echo 'qm status $WATCHDOGVMID' >> /TcTI/SCRIPTS/WATCHDOG/$WATCHDOGVMID.sh
				echo 'else' >> /TcTI/SCRIPTS/WATCHDOG/$WATCHDOGVMID.sh
				echo 'echo "host não encontaado - reiniciando...."' >> /TcTI/SCRIPTS/WATCHDOG/$WATCHDOGVMID.sh
				echo 'qm stop $WATCHDOGVMID' >> /TcTI/SCRIPTS/WATCHDOG/$WATCHDOGVMID.sh
				echo 'qm start $WATCHDOGVMID' >> /TcTI/SCRIPTS/WATCHDOG/$WATCHDOGVMID.sh
				echo 'qm status $WATCHDOGVMID' >> /TcTI/SCRIPTS/WATCHDOG/$WATCHDOGVMID.sh
				echo 'fi' >> /TcTI/SCRIPTS/WATCHDOG/$WATCHDOGVMID.sh
				clear	 
				echo "Monitoramento da VM ativada" 
				read -p "Pressione uma tecla para continuar..."
				clear	  
				watch_dog
					;;	
				5) clear;
				echo "Qual ID da VM? EX: 230"
				read WATCHDOGVMIDDEL
				rm /TcTI/SCRIPTS/WATCHDOG/$WATCHDOGVMIDDEL.sh
				read -p "Pressione uma tecla para continuar..."
				clear
				watch_dog
					;;			
				0) clear;
				extras_sistema_menu;
					;;				
				*)clear;
				extras_sistema_menu;
				;;
			esac
		fi
	done
	watch_dog
}

