#!/bin/bash

# ==========================================
# Idioma: Español (España/América Latina)
# ==========================================

# --- Geral ---
LANG_SELECT_OPT="Seleccione una opción:"
LANG_TYPE_OPT="Escriba su opción"
LANG_PRESS_ENTER="(o presione ENTER para salir)"

# --- menu_vm_operations.sh ---
LANG_VM_OP_TITLE="Operaciones de VMs"
LANG_VM_OP_OPT_1="Live Migration sin Clúster"
LANG_VM_OP_OPT_2="Desbloquear, Apagar y Reiniciar VM"
LANG_VM_OP_OPT_3="🚚 Migración / Importación de Discos (VHD/VMDK/VDI)"
LANG_VM_OP_OPT_4="💽 Passthrough de HD/SSD Físico para VM"
LANG_VM_OP_OPT_0="Volver"
