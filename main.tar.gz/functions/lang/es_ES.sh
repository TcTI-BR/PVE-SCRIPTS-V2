#!/bin/bash

# ==========================================
# Idioma: Español (España/América Latina)
# ==========================================

# --- Geral ---
LANG_SELECT_OPT="Seleccione una opción:"
LANG_TYPE_OPT="Escriba su opción"
LANG_PRESS_ENTER="(o presione ENTER para salir)"

# --- menu_vm_operations.sh ---
LANG_VM_OP_TITLE="Operaciones de VMs"
LANG_VM_OP_OPT_1="Live Migration sin Clúster"
LANG_VM_OP_OPT_2="Desbloquear, Apagar y Reiniciar VM"
LANG_VM_OP_OPT_3="🚚 Migración / Importación de Discos (VHD/VMDK/VDI)"
LANG_VM_OP_OPT_4="💽 Passthrough de HD/SSD Físico para VM"
LANG_VM_OP_OPT_0="Volver"

# --- main.sh (Menu Principal) ---
LANG_MAIN_TITLE="Menú Principal"
LANG_MAIN_OPT_1="Proxmox Virtual Environment (PVE)"
LANG_MAIN_DESC_1="Gestión completa de Proxmox VE"
LANG_MAIN_OPT_2="Proxmox Backup Server (PBS)"
LANG_MAIN_DESC_2="Gestión de Proxmox Backup Server"
LANG_MAIN_OPT_3="Herramientas Generales y Extras"
LANG_MAIN_DESC_3="Pruebas de disco, badblocks, SMART, etc."
LANG_MAIN_OPT_4="Configuración del Script"
LANG_MAIN_DESC_4="Cambiar idioma y opciones globales"
LANG_MAIN_OPT_0="Salir"

# --- menu_config.sh ---
LANG_CONF_TITLE="Configuración del Script"
LANG_CONF_OPT_1="Cambiar Idioma / Change Language"
LANG_CONF_LANG_CHOSEN="¡Idioma seleccionado y guardado correctamente!"
LANG_CONF_RESTARTING="Reiniciando el script para aplicar los cambios..."
