#!/bin/bash

# ==========================================
# Idioma: Español (España/América Latina)
# ==========================================

# --- Geral ---
LANG_SELECT_OPT="Seleccione una opción:"
LANG_TYPE_OPT="Escriba su opción"
LANG_PRESS_ENTER="(o presione ENTER para salir)"

# --- menu_vm_operations.sh ---
LANG_VM_OP_TITLE="Operaciones de VMs"
LANG_VM_OP_OPT_1="Live Migration sin Clúster"
LANG_VM_OP_OPT_2="Desbloquear, Apagar y Reiniciar VM"
LANG_VM_OP_OPT_3="🚚 Migración / Importación de Discos (VHD/VMDK/VDI)"
LANG_VM_OP_OPT_4="💽 Passthrough de HD/SSD Físico para VM"
LANG_VM_OP_OPT_0="Volver"

# --- main.sh (Menu Principal) ---
LANG_MAIN_TITLE="Menú Principal"
LANG_MAIN_OPT_1="Proxmox Virtual Environment (PVE)"
LANG_MAIN_DESC_1="Gestión completa de Proxmox VE"
LANG_MAIN_OPT_2="Proxmox Backup Server (PBS)"
LANG_MAIN_DESC_2="Gestión de Proxmox Backup Server"
LANG_MAIN_OPT_3="Herramientas Generales y Extras"
LANG_MAIN_DESC_3="Pruebas de disco, badblocks, SMART, etc."
LANG_MAIN_OPT_4="Configuración del Script"
LANG_MAIN_DESC_4="Cambiar idioma y opciones globales"
LANG_MAIN_OPT_0="Salir"

# --- menu_config.sh ---
LANG_CONF_TITLE="Configuración del Script"
LANG_CONF_OPT_1="Cambiar Idioma / Change Language"
LANG_CONF_LANG_CHOSEN="¡Idioma seleccionado y guardado correctamente!"
LANG_CONF_RESTARTING="Reiniciando el script para aplicar los cambios..."

# --- menu_pve.sh ---
LANG_PVE_MENU_TITLE="Proxmox Virtual Environment - Menú Principal"
LANG_PVE_MENU_OPT_1="Actualización, instalación y mejora del sistema"
LANG_PVE_MENU_OPT_2="Herramientas de disco y sistemas de archivos"
LANG_PVE_MENU_OPT_3="Tareas de backup"
LANG_PVE_MENU_OPT_4="Operaciones de VMs"
LANG_PVE_MENU_OPT_5="Utilización de IA"
LANG_PVE_MENU_OPT_6="Sensores WebUI (Temp/Frec/Watts)"
LANG_PVE_MENU_OPT_0="Volver al menú principal"

# --- menu_pbs.sh ---
LANG_PBS_MENU_TITLE="Proxmox Backup Server - Menú Principal"
LANG_PBS_MENU_OPT_1="Actualización, instalación y mejora del sistema"
LANG_PBS_MENU_OPT_2="Herramientas de disco"
LANG_PBS_MENU_OPT_0="Volver al menú principal"

# --- menu_update.sh ---
LANG_UPDATE_MENU_TITLE="Actualización, Instalación y Mejora del Sistema"
LANG_UPDATE_MENU_OPT_1="Upgrade de versiones"
LANG_UPDATE_MENU_OPT_2="Actualización del sistema y aplicaciones comunes"
LANG_UPDATE_MENU_OPT_3="Instalar aplicaciones"

# --- menu_disco.sh ---
LANG_DISCO_MENU_TITLE="Herramientas de Disco y Sistemas de Archivos"
LANG_DISCO_MENU_OPT_1="Configurar discos"
LANG_DISCO_MENU_OPT_2="Eliminar almacenamiento local-lvm"
LANG_DISCO_MENU_OPT_3="Ceph Utils - Gestión del Clúster Ceph"

# --- menu_bkp.sh ---
LANG_BKP_MENU_TITLE="Tareas de Backup"
LANG_BKP_MENU_OPT_1="Configurar servicio NFS para backup en red"
LANG_BKP_MENU_OPT_2="Instalar PBS lado a lado con PVE"
LANG_BKP_MENU_OPT_3="Programar backup de configuraciones de Proxmox"
LANG_BKP_MENU_OPT_4="Restaurar backup de configuraciones de Proxmox"

# --- menu_extras.sh ---
LANG_EXTRAS_MENU_TITLE="Herramientas Generales y Diagnósticos (Extras)"
LANG_EXTRAS_MENU_OPT_1="Herramientas y Diagnósticos de Disco"
LANG_EXTRAS_MENU_DESC_1="Speed test, Badblocks, SMART info"
LANG_EXTRAS_MENU_OPT_2="Configuración de Notificaciones por Correo"
LANG_EXTRAS_MENU_DESC_2="Configurar Postfix, SMTP, aliases y alertas"
LANG_EXTRAS_MENU_OPT_3="Configuraciones de Red"
LANG_EXTRAS_MENU_DESC_3="Interfaces (/etc/network), DNS y Hosts"
LANG_EXTRAS_MENU_OPT_4="Ajustes de Sistema, Host y Watchdog"
LANG_EXTRAS_MENU_DESC_4="Temperatura, SWAP, Uptime, Auto-start, Watchdog"
LANG_EXTRAS_MENU_OPT_5="Comandos e Información Útil"
LANG_EXTRAS_MENU_DESC_5="Cheat-sheet: Linux, PVE (qm/pct) y rutas"
LANG_EXTRAS_MENU_OPT_6="Gestión de Claves de IA"
LANG_EXTRAS_MENU_DESC_6="Registrar/Probar claves API (OpenAI, Gemini, Claude)"
LANG_EXTRAS_MENU_OPT_7="Central de Gestión y Notificaciones"
LANG_EXTRAS_MENU_DESC_7="Telegram Bot, WhatsApp e integraciones"

# --- menu_ia.sh ---
LANG_IA_MENU_TITLE="Utilización de IA"
LANG_IA_MENU_OPT_1="Verificar configuraciones de VMs y Contenedores"
LANG_IA_MENU_OPT_2="Gestionar Claves de IA (OpenAI, Gemini, Claude)"

# --- menu_upgrade.sh ---
LANG_UPGRADE_MENU_TITLE="Upgrade de Versiones de Proxmox VE"
LANG_UPGRADE_MENU_ATTENTION="ATENCIÓN:"
LANG_UPGRADE_MENU_WARNING="¡Haga una copia de seguridad antes de realizar cualquier upgrade!"
LANG_UPGRADE_MENU_SELECT="Seleccione la versión de destino:"
LANG_UPGRADE_MENU_OPT_1="Upgrade de la versión 5.x a 6.x"
LANG_UPGRADE_MENU_OPT_2="Upgrade de la versión 6.x a 7.x"
LANG_UPGRADE_MENU_OPT_3="Upgrade de la versión 7.x a 8.x"
LANG_UPGRADE_MENU_OPT_4="Upgrade de la versión 8.x a 9.x (Debian 13 Trixie)"

# --- menu_instala_aplicativos.sh ---
LANG_APPS_MENU_TITLE="Instalación de Aplicaciones y Herramientas"
LANG_APPS_MENU_OPT_1="TacticalRMM - Remote Monitoring & Management"
LANG_APPS_MENU_OPT_2="Cloudflare Tunnel - Túnel inverso seguro"
LANG_APPS_MENU_OPT_3="Zabbix Agent - Monitorización de infraestructura"
LANG_APPS_MENU_OPT_4="Otras aplicaciones (Próximamente)"

# --- menu_ceph.sh ---
LANG_CEPH_MENU_TITLE="Ceph Utils - Gestión"
LANG_CEPH_MENU_OPT_1="Diagnóstico y Salud (Read-Only)"
LANG_CEPH_MENU_OPT_2="Benchmark (Prueba de Rendimiento)"
LANG_CEPH_MENU_OPT_3="Gestión de Pools"
LANG_CEPH_MENU_OPT_4="Optimización y Tuning (Hardware Check)"
LANG_CEPH_MENU_OPT_5="Utilidades de OSD (Device Classes)"

# --- menu_watch_dog.sh ---
LANG_WD_MENU_TITLE="Configuración de Watchdog"
LANG_WD_MENU_DESC="Watchdog: Monitoriza VMs y reinicia automáticamente si están fuera de línea"
LANG_WD_MENU_OPT_1="Crear programación (se ejecuta cada 10 minutos)"
LANG_WD_MENU_OPT_2="Eliminar la programación"
LANG_WD_MENU_OPT_3="Lista de VMs monitorizadas"
LANG_WD_MENU_OPT_4="Añadir VM a la monitorización"
LANG_WD_MENU_OPT_5="Eliminar VM de la monitorización"

# --- menu_webui_sensors.sh ---
LANG_WEBUI_MENU_TITLE="Personalización y Sensores de Hardware en WebUI de PVE"
LANG_WEBUI_MENU_INFO="INFORMACIÓN DE SEGURIDAD:"
LANG_WEBUI_MENU_INFO_1="Los archivos originales limpios se guardan en:"
LANG_WEBUI_MENU_INFO_2="Puede restaurar la WebUI oficial en cualquier momento."
LANG_WEBUI_MENU_STATUS_ON="[ACTIVADO] Sensores de Hardware Activos en WebUI"
LANG_WEBUI_MENU_STATUS_OFF="[DESACTIVADO] WebUI Estándar de Proxmox"
LANG_WEBUI_MENU_STATUS="Estado Actual:"
LANG_WEBUI_MENU_OPT_1="Activar Sensores de Temp, MHz, Watts y Discos en WebUI"
LANG_WEBUI_MENU_OPT_2="Restaurar WebUI Original (Restaurar desde Copia de Seguridad)"
LANG_WEBUI_MENU_OPT_3="Reinstalar Paquetes Oficiales de Proxmox (Restauración Total Limpia)"

# --- menu_instala_zabbix.sh ---
LANG_ZABBIX_MENU_TITLE="Zabbix Agent - Monitorización"
LANG_ZABBIX_MENU_STATUS_TITLE="ESTADO DEL AGENTE:"
LANG_ZABBIX_MENU_ACTIVE="Servicio activo y en ejecución"
LANG_ZABBIX_MENU_STOPPED="Servicio detenido"
LANG_ZABBIX_MENU_NOT_INSTALLED="Zabbix Agent no instalado"
LANG_ZABBIX_MENU_OPT_1="Instalar/Configurar Zabbix Agent"
LANG_ZABBIX_MENU_OPT_2="Eliminar Zabbix Agent"
LANG_ZABBIX_MENU_ALREADY_INSTALLED="(ya instalado)"
LANG_ZABBIX_MENU_REQ_INSTALL="(requiere instalación)"

# --- menu_instala_tactical_rmm.sh ---
LANG_TRMM_MENU_TITLE="Gestor del Agente TacticalRMM"
LANG_TRMM_MENU_STATUS_INSTALLED="TacticalRMM Agent instalado"
LANG_TRMM_MENU_STATUS_NOT_INSTALLED="TacticalRMM Agent no instalado"
LANG_TRMM_MENU_OPT_1="Instalar nuevo agente"
LANG_TRMM_MENU_OPT_2="Desinstalar agente / Limpiar rastros"

# --- menu_instala_cloudflared.sh ---
LANG_CF_MENU_TITLE="Túnel Inverso Cloudflare"
LANG_CF_MENU_STATUS_INSTALLED="Cloudflared instalado"
LANG_CF_MENU_STATUS_NOT_INSTALLED="Cloudflared no instalado"
LANG_CF_MENU_STATUS_RUNNING="Servicio activo y en ejecución"
LANG_CF_MENU_STATUS_STOPPED="Servicio configurado pero no en ejecución"
LANG_CF_MENU_STATUS_NOT_CONFIGURED="Servicio no configurado"
LANG_CF_MENU_OPT_1="Instalación del túnel Cloudflare"
LANG_CF_MENU_OPT_2="Configurar servicio y clave de cliente"
LANG_CF_MENU_OPT_3="Eliminar el túnel"

# --- menu_instala_script.sh ---
LANG_AUTOSTART_MENU_TITLE="Auto-Inicio del Script"
LANG_AUTOSTART_MENU_OPT_1="Instalar script al iniciar sesión de usuario"
LANG_AUTOSTART_MENU_OPT_2="Desinstalar script al iniciar sesión de usuario"

# --- vm_disk_passthrough.sh ---
LANG_PASSTHROUGH_MENU_TITLE="Asistente de Passthrough de Discos Físicos"
LANG_PASSTHROUGH_MENU_DESC_1="Este asistente permite conectar un HDD/SSD físico (vía USB o SATA)"
LANG_PASSTHROUGH_MENU_DESC_2="directamente a una Máquina Virtual como un dispositivo de bloque."
LANG_PASSTHROUGH_MENU_DESC_3="➜ Ideal para P2V, clonación con Clonezilla o TrueNAS."
LANG_PASSTHROUGH_MENU_OPT_1="Adjuntar un HDD/SSD físico a una VM"
LANG_PASSTHROUGH_MENU_OPT_2="Desadjuntar (Eliminar) un disco físico de una VM"

# --- vm_config_checker.sh ---
LANG_CONFIG_CHECKER_MENU_TITLE="Auditor IA de VMs / CTs"
LANG_CONFIG_CHECKER_MENU_OPT_1="Verificar TODAS las VMs y Contenedores"
LANG_CONFIG_CHECKER_MENU_OPT_2="Verificar una VM/Contenedor específico"
LANG_CONFIG_CHECKER_MENU_OPT_3="📨 Enviar informe de TODAS vía Telegram"
LANG_CONFIG_CHECKER_MENU_OPT_4="📨 Enviar informe de una VM/CT vía Telegram"

# --- destranca_desliga.sh ---
LANG_UNLOCK_MENU_TITLE="Desbloquear, Apagar y Reiniciar VM"
LANG_UNLOCK_MENU_OPT_1="Desbloquear VM"
LANG_UNLOCK_MENU_OPT_2="Desbloquear y apagar la VM"
LANG_UNLOCK_MENU_OPT_3="Desbloquear, apagar y reiniciar la VM"

# --- menu_upgrade_pbs.sh ---
LANG_PBS_UPGRADE_TITLE="Actualización de Versiones de Proxmox PBS"
LANG_PBS_UPGRADE_WARN="¡Haga una copia de seguridad antes de realizar cualquier actualización!"
LANG_PBS_UPGRADE_SELECT="Seleccione la versión de destino:"
LANG_PBS_UPGRADE_OPT_1="Actualización de la versión 1.x a la 2.x"

# --- menu_update_pbs.sh ---
LANG_PBS_UPDATE_TITLE="Actualización, Instalación y Upgrade del Sistema"
LANG_PBS_UPDATE_OPT_1="Actualización de versiones"
LANG_PBS_UPDATE_OPT_2="Actualización del sistema y aplicaciones comunes"

# --- menu_disco_pbs.sh ---
LANG_PBS_DISK_TITLE="Herramientas de Disco (PBS)"
LANG_PBS_DISK_OPT_1="Configurar disco y crear Datastore PBS"

# --- menu_telegram.sh ---
LANG_TELEGRAM_MENU_TITLE="Gestión vía Telegram"
LANG_TELEGRAM_MENU_STATUS_TITLE="Estado:"
LANG_TELEGRAM_MENU_STATUS_ACTIVE="Activo y ejecutándose"
LANG_TELEGRAM_MENU_STATUS_INACTIVE="Inactivo o con error"
LANG_TELEGRAM_MENU_STATUS_UNINSTALLED="No instalado"
LANG_TELEGRAM_MENU_OPT_1_INSTALL="Instalar y Configurar Bot"
LANG_TELEGRAM_MENU_OPT_1_RECONFIG="Reconfigurar Bot"
LANG_TELEGRAM_MENU_OPT_2="Desinstalar Bot"
LANG_TELEGRAM_MENU_OPT_3="Reiniciar Servicio"
LANG_TELEGRAM_MENU_OPT_4="Ver Registros del Bot"
LANG_TELEGRAM_MENU_OPT_5="Actualizar Bot"
LANG_TELEGRAM_MENU_OPT_5_DESC="(mantener credenciales)"

# --- menu_extras_sistema.sh ---
LANG_EXTRAS_SYS_MENU_TITLE="Ajustes de Sistema, Host y Watchdog"
LANG_EXTRAS_SYS_MENU_OPT_1="🔥 Monitorización Térmica y Protección de Hardware"
LANG_EXTRAS_SYS_MENU_OPT_2="Configurar SWAP (swappiness)"
LANG_EXTRAS_SYS_MENU_OPT_3="Información de rendimiento del Host"
LANG_EXTRAS_SYS_MENU_OPT_4="Instalar/desinstalar script al iniciar el shell"
LANG_EXTRAS_SYS_MENU_OPT_5="Configuración del Watchdog de VMs (Auto-reinicio vía Ping)"

# Disclaimer
LANG_DISCLAIMER_TITLE="AVISO DE RESPONSABILIDAD"
LANG_DISCLAIMER_1="El uso de este script es de ${COLOR_RED}ENTERA RESPONSABILIDAD${COLOR_YELLOW} del usuario."
LANG_DISCLAIMER_2_1="La persona o empresa que proporcionó el script ${COLOR_RED}NO SERÁ RESPONSABLE${COLOR_WHITE}"
LANG_DISCLAIMER_2_2="por cualquier ${COLOR_RED}problema o daño causado${COLOR_WHITE} por su uso."
LANG_DISCLAIMER_3_1="Antes de usarlo, haga una ${COLOR_GREEN}evaluación cuidadosa${COLOR_WHITE} y comprenda"
LANG_DISCLAIMER_3_2="las implicaciones de su uso."
LANG_DISCLAIMER_4_1="${COLOR_RED}Asegúrese${COLOR_WHITE} de que el script sea ${COLOR_GREEN}seguro y adecuado${COLOR_WHITE} para"
LANG_DISCLAIMER_4_2="sus necesidades antes de utilizarlo."
LANG_DISCLAIMER_AGREE="Al presionar ENTER usted ${COLOR_RED}ACEPTA${COLOR_CYAN} los términos anteriores"

# Updater strings
LANG_UPD_TITLE="TcTI Proxmox Scripts - Sistema de Actualización"
LANG_UPD_DISABLED="Actualización automática desactivada en la configuración."
LANG_UPD_LOCAL="Iniciando con la versión local."
LANG_UPD_CONN="Verificando conexión a internet..."
LANG_UPD_OFFLINE="Modo Offline: Sin conexión. Iniciando con la versión local."
LANG_UPD_CHECK="Buscando actualizaciones..."
LANG_UPD_REPO_FAIL="Fallo al consultar el repositorio. Iniciando versión local."
LANG_UPD_LATEST="¡El script ya está en la última versión!"
LANG_UPD_NEW="¡Nueva versión detectada! Descargando actualización (tar.gz)..."
LANG_UPD_DL_OK="Descarga y extracción completadas."
LANG_UPD_APPLY="Aplicando actualización..."
LANG_UPD_SUCCESS="¡Actualización aplicada con éxito!"
LANG_UPD_RESTART="Reiniciando el script automáticamente..."
LANG_UPD_ERR_FOLDER="Error: Carpeta extraída no encontrada."
LANG_UPD_DL_FAIL="Fallo al descargar o extraer el paquete. Iniciando versión local."
LANG_UPD_LOAD_MODS="Cargando módulos..."
LANG_UPD_PVE="Proxmox Virtual Environment (PVE)"
LANG_UPD_PBS="Proxmox Backup Server (PBS)"
LANG_UPD_EXTRAS="Herramientas Generales (Extras)"
LANG_UPD_PVE_LOADED="módulos PVE cargados"
LANG_UPD_PBS_LOADED="módulos PBS cargados"
LANG_UPD_EXTRAS_LOADED="módulos Extras cargados"

