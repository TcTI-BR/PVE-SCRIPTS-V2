#!/bin/bash

# ==========================================
# Idioma: Português (Brasil)
# ==========================================

# --- Geral ---
LANG_SELECT_OPT="Selecione uma opção:"
LANG_TYPE_OPT="Digite sua opção"
LANG_PRESS_ENTER="(ou pressione ENTER para sair)"

# --- menu_vm_operations.sh ---
LANG_VM_OP_TITLE="Operações de VMs"
LANG_VM_OP_OPT_1="Live Migration sem Cluster"
LANG_VM_OP_OPT_2="Destranca, desliga e reinicia VM"
LANG_VM_OP_OPT_3="🚚 Migração / Importação de Discos (VHD/VMDK/VDI)"
LANG_VM_OP_OPT_4="💽 Repasse de HD/SSD Físico para VM (Passthrough)"
LANG_VM_OP_OPT_0="Voltar"

# --- main.sh (Menu Principal) ---
LANG_MAIN_TITLE="Menu Principal"
LANG_MAIN_OPT_1="Proxmox Virtual Environment (PVE)"
LANG_MAIN_DESC_1="Gerenciamento completo do Proxmox VE"
LANG_MAIN_OPT_2="Proxmox Backup Server (PBS)"
LANG_MAIN_DESC_2="Gerenciamento do Proxmox Backup Server"
LANG_MAIN_OPT_3="Ferramentas Gerais e Extras"
LANG_MAIN_DESC_3="Testes de disco, badblocks, SMART, etc."
LANG_MAIN_OPT_4="Configurações do Script"
LANG_MAIN_DESC_4="Alterar Idioma e opções globais"
LANG_MAIN_OPT_0="Sair"

# --- menu_config.sh ---
LANG_CONF_TITLE="Configurações do Script"
LANG_CONF_OPT_1="Alterar Idioma / Change Language"
LANG_CONF_LANG_CHOSEN="Idioma selecionado e salvo com sucesso!"
LANG_CONF_RESTARTING="Reiniciando o script para aplicar as alterações..."

# --- menu_pve.sh ---
LANG_PVE_MENU_TITLE="Proxmox Virtual Environment - Menu Principal"
LANG_PVE_MENU_OPT_1="Atualização, instalação e upgrade do sistema"
LANG_PVE_MENU_OPT_2="Ferramentas de disco e sistemas de arquivos"
LANG_PVE_MENU_OPT_3="Tarefas de backup"
LANG_PVE_MENU_OPT_4="Operações de VMs"
LANG_PVE_MENU_OPT_5="Utilização de IA"
LANG_PVE_MENU_OPT_6="Sensores WebUI (Temp/Freq/Watts)"
LANG_PVE_MENU_OPT_0="Voltar ao menu principal"

# --- menu_pbs.sh ---
LANG_PBS_MENU_TITLE="Proxmox Backup Server - Menu Principal"
LANG_PBS_MENU_OPT_1="Atualização, instalação e upgrade do sistema"
LANG_PBS_MENU_OPT_2="Ferramentas de disco"
LANG_PBS_MENU_OPT_0="Voltar ao menu principal"

# --- menu_update.sh ---
LANG_UPDATE_MENU_TITLE="Atualização, Instalação e Upgrade do Sistema"
LANG_UPDATE_MENU_OPT_1="Upgrade de versões"
LANG_UPDATE_MENU_OPT_2="Atualização do sistema e aplicativos comuns"
LANG_UPDATE_MENU_OPT_3="Instala aplicativos"

# --- menu_disco.sh ---
LANG_DISCO_MENU_TITLE="Ferramentas de Disco e Sistemas de Arquivos"
LANG_DISCO_MENU_OPT_1="Configura discos"
LANG_DISCO_MENU_OPT_2="Remove o storage local-lvm"
LANG_DISCO_MENU_OPT_3="Ceph Utils - Gerenciamento de Cluster Ceph"

# --- menu_bkp.sh ---
LANG_BKP_MENU_TITLE="Tarefas de Backup"
LANG_BKP_MENU_OPT_1="Configura serviço de NFS para backup em rede"
LANG_BKP_MENU_OPT_2="Instala o PBS lado a lado com o PVE"
LANG_BKP_MENU_OPT_3="Agenda backup das configurações do Proxmox"
LANG_BKP_MENU_OPT_4="Restaura backup das configurações do Proxmox"

# --- menu_extras.sh ---
LANG_EXTRAS_MENU_TITLE="Ferramentas Gerais e Diagnósticos (Extras)"
LANG_EXTRAS_MENU_OPT_1="Ferramentas e Diagnósticos de Disco"
LANG_EXTRAS_MENU_DESC_1="Speed test, Badblocks, SMART info"
LANG_EXTRAS_MENU_OPT_2="Configuração de Notificações por E-mail"
LANG_EXTRAS_MENU_DESC_2="Configurar Postfix, SMTP, aliases e alertas"
LANG_EXTRAS_MENU_OPT_3="Configurações de Rede"
LANG_EXTRAS_MENU_DESC_3="Interfaces (/etc/network), DNS e Hosts"
LANG_EXTRAS_MENU_OPT_4="Ajustes de Sistema, Host e Watchdog"
LANG_EXTRAS_MENU_DESC_4="Temperatura, SWAP, Uptime, Auto-start e Watchdog"
LANG_EXTRAS_MENU_OPT_5="Comandos e Informações Úteis"
LANG_EXTRAS_MENU_DESC_5="Cheat-sheet: Linux, PVE (qm/pct) e caminhos"
LANG_EXTRAS_MENU_OPT_6="Gerenciamento de Chaves de IA"
LANG_EXTRAS_MENU_DESC_6="Cadastrar/Testar chaves API (OpenAI, Gemini, Claude)"
LANG_EXTRAS_MENU_OPT_7="Central de Gerenciamento e Notificações"
LANG_EXTRAS_MENU_DESC_7="Telegram Bot, WhatsApp e Integrações de Mensageria"

# --- menu_ia.sh ---
LANG_IA_MENU_TITLE="Utilização de IA"
LANG_IA_MENU_OPT_1="Verificar configurações de VMs e Containers"
LANG_IA_MENU_OPT_2="Gerenciar Chaves de IA (OpenAI, Gemini, Claude)"

# --- menu_upgrade.sh ---
LANG_UPGRADE_MENU_TITLE="Upgrade de Versões do Proxmox VE"
LANG_UPGRADE_MENU_ATTENTION="ATENÇÃO:"
LANG_UPGRADE_MENU_WARNING="Faça backup antes de realizar qualquer upgrade!"
LANG_UPGRADE_MENU_SELECT="Selecione a versão de destino:"
LANG_UPGRADE_MENU_OPT_1="Upgrade da versão 5.x para 6.x"
LANG_UPGRADE_MENU_OPT_2="Upgrade da versão 6.x para 7.x"
LANG_UPGRADE_MENU_OPT_3="Upgrade da versão 7.x para 8.x"
LANG_UPGRADE_MENU_OPT_4="Upgrade da versão 8.x para 9.x (Debian 13 Trixie)"

# --- menu_instala_aplicativos.sh ---
LANG_APPS_MENU_TITLE="Instalação de Aplicativos e Ferramentas"
LANG_APPS_MENU_OPT_1="TacticalRMM - Remote Monitoring & Management"
LANG_APPS_MENU_OPT_2="Cloudflare Tunnel - Túnel reverso seguro"
LANG_APPS_MENU_OPT_3="Zabbix Agent - Monitoramento de infraestrutura"
LANG_APPS_MENU_OPT_4="Outros aplicativos (Em breve)"

# --- menu_ceph.sh ---
LANG_CEPH_MENU_TITLE="Ceph Utils - Gerenciamento"
LANG_CEPH_MENU_OPT_1="Diagnóstico e Saúde (Read-Only)"
LANG_CEPH_MENU_OPT_2="Benchmark (Teste de Performance)"
LANG_CEPH_MENU_OPT_3="Gerenciamento de Pools"
LANG_CEPH_MENU_OPT_4="Otimização e Tuning (Hardware Check)"
LANG_CEPH_MENU_OPT_5="Utilitários de OSD (Device Classes)"

# --- menu_watch_dog.sh ---
LANG_WD_MENU_TITLE="Configuração do Watchdog"
LANG_WD_MENU_DESC="Watchdog: Monitora VMs e reinicia automaticamente caso offline"
LANG_WD_MENU_OPT_1="Cria agendamento (executa a cada 10 minutos)"
LANG_WD_MENU_OPT_2="Remove o agendamento"
LANG_WD_MENU_OPT_3="Lista VMs monitoradas"
LANG_WD_MENU_OPT_4="Adiciona VM ao monitoramento"
LANG_WD_MENU_OPT_5="Remove VM do monitoramento"

# --- menu_webui_sensors.sh ---
LANG_WEBUI_MENU_TITLE="Customização & Sensores de Hardware na WebUI do PVE"
LANG_WEBUI_MENU_INFO="INFORMAÇÕES DE SEGURANÇA:"
LANG_WEBUI_MENU_INFO_1="Os arquivos originais limpos são salvos em:"
LANG_WEBUI_MENU_INFO_2="Você pode restaurar a WebUI oficial a qualquer momento."
LANG_WEBUI_MENU_STATUS_ON="[ATIVADO] Sensores de Hardware Ativos na WebUI"
LANG_WEBUI_MENU_STATUS_OFF="[DESATIVADO] WebUI Padrão do Proxmox"
LANG_WEBUI_MENU_STATUS="Status Atual:"
LANG_WEBUI_MENU_OPT_1="Ativar Sensores de Temp, MHz, Watts & Discos na WebUI"
LANG_WEBUI_MENU_OPT_2="Restaurar WebUI Original (Restaurar do Backup)"
LANG_WEBUI_MENU_OPT_3="Reinstalar Pacotes Oficiais Proxmox (Restauração Total Limpa)"

# --- menu_instala_zabbix.sh ---
LANG_ZABBIX_MENU_TITLE="Zabbix Agent - Monitoramento"
LANG_ZABBIX_MENU_STATUS_TITLE="STATUS DO AGENTE:"
LANG_ZABBIX_MENU_ACTIVE="Serviço ativo e rodando"
LANG_ZABBIX_MENU_STOPPED="Serviço parado"
LANG_ZABBIX_MENU_NOT_INSTALLED="Zabbix Agent não instalado"
LANG_ZABBIX_MENU_OPT_1="Instalar/Configurar Zabbix Agent"
LANG_ZABBIX_MENU_OPT_2="Remover Zabbix Agent"
LANG_ZABBIX_MENU_ALREADY_INSTALLED="(já instalado)"
LANG_ZABBIX_MENU_REQ_INSTALL="(requer instalação)"

# --- menu_instala_tactical_rmm.sh ---
LANG_TRMM_MENU_TITLE="Gerenciador de Agente TacticalRMM"
LANG_TRMM_MENU_STATUS_INSTALLED="TacticalRMM Agent instalado"
LANG_TRMM_MENU_STATUS_NOT_INSTALLED="TacticalRMM Agent não instalado"
LANG_TRMM_MENU_OPT_1="Instalar novo agente"
LANG_TRMM_MENU_OPT_2="Desinstalar agente / Limpar vestígios"

# --- menu_instala_cloudflared.sh ---
LANG_CF_MENU_TITLE="Túnel Reverso Cloudflare"
LANG_CF_MENU_STATUS_INSTALLED="Cloudflared instalado"
LANG_CF_MENU_STATUS_NOT_INSTALLED="Cloudflared não instalado"
LANG_CF_MENU_STATUS_RUNNING="Serviço ativo e rodando"
LANG_CF_MENU_STATUS_STOPPED="Serviço configurado mas não está rodando"
LANG_CF_MENU_STATUS_NOT_CONFIGURED="Serviço não configurado"
LANG_CF_MENU_OPT_1="Instalação do túnel Cloudflare"
LANG_CF_MENU_OPT_2="Configurar serviço e chave do cliente"
LANG_CF_MENU_OPT_3="Remover o túnel"

# --- menu_instala_script.sh ---
LANG_AUTOSTART_MENU_TITLE="Auto-Inicialização do Script"
LANG_AUTOSTART_MENU_OPT_1="Instala script ao carregar o usuário"
LANG_AUTOSTART_MENU_OPT_2="Desinstala script ao carregar o usuário"

# --- vm_disk_passthrough.sh ---
LANG_PASSTHROUGH_MENU_TITLE="Assistente de Repasse de Discos Físicos (Passthrough)"
LANG_PASSTHROUGH_MENU_DESC_1="Este assistente permite conectar um HD/SSD físico (via USB ou SATA)"
LANG_PASSTHROUGH_MENU_DESC_2="diretamente a uma Máquina Virtual como um dispositivo de bloco."
LANG_PASSTHROUGH_MENU_DESC_3="➜ Ideal para P2V, clonagem com Clonezilla ou TrueNAS."
LANG_PASSTHROUGH_MENU_OPT_1="Anexar um HD/SSD físico a uma VM"
LANG_PASSTHROUGH_MENU_OPT_2="Desanexar (Remover) um disco físico de uma VM"

# --- vm_config_checker.sh ---
LANG_CONFIG_CHECKER_MENU_TITLE="IA Auditor de VMs / CTs"
LANG_CONFIG_CHECKER_MENU_OPT_1="Verificar TODAS as VMs e Containers"
LANG_CONFIG_CHECKER_MENU_OPT_2="Verificar uma VM/Container específico"
LANG_CONFIG_CHECKER_MENU_OPT_3="📨 Enviar relatório de TODAS via Telegram"
LANG_CONFIG_CHECKER_MENU_OPT_4="📨 Enviar relatório de uma VM/CT via Telegram"

# --- destranca_desliga.sh ---
LANG_UNLOCK_MENU_TITLE="Destranca, Desliga e Reinicia VM"

# Disk prep
LANG_DISK_PREP="Qual o disco que vai ser preparado? EX: sda / nvme0n1"
LANG_DISK_NAME="Qual o nome do Storage? EX: VM01 / RECOVER / BACKUP_2HD / BACKUP_REDE / EXTERNO_TERCA / EXTERNO_QUINTA"
LANG_DISK_USAGE="O disco será para ${COLOR_RED}BACKUP${COLOR_RESET} ou ${COLOR_RED}VM${COLOR_RESET}?: Digite exatamente ${COLOR_RED}images${COLOR_RESET} para VM ou ${COLOR_RED}backup${COLOR_RESET} para BACKUP sem as aspas"
LANG_DISK_PBS_NAME="Qual o nome do Datastore? EX: BACKUP_REDE / STORE_01"

# Ceph Utils - Submenus
LANG_CEPH_DIAG_TITLE="Diagnóstico e Saúde do Cluster Ceph"
LANG_CEPH_DIAG_OPT_1="Status Rápido (ceph -s)"
LANG_CEPH_DIAG_OPT_2="Capacidade de Storage (ceph df)"
LANG_CEPH_DIAG_OPT_3="Mapa de Árvore OSD (ceph osd tree)"
LANG_CEPH_DIAG_OPT_4="Top 5 OSDs com Maior Latência"

LANG_CEPH_BENCH_TITLE="Benchmark e Teste de Performance Ceph"
LANG_CEPH_BENCH_OPT_1="Teste de Escrita Sequencial (Throughput)"
LANG_CEPH_BENCH_OPT_2="Teste de IOPS (Random)"
LANG_CEPH_BENCH_OPT_3="Teste de OSD Individual (Hardware)"

LANG_CEPH_POOL_TITLE="Gerenciamento de Pools Ceph"
LANG_CEPH_POOL_OPT_1="Listar Detalhes dos Pools"
LANG_CEPH_POOL_OPT_2="Criar Novo Pool"
LANG_CEPH_POOL_OPT_3="Alterar Regra CRUSH de Pool"
LANG_CEPH_POOL_OPT_4="Deletar Pool (DESTRUTIVO)"

LANG_CEPH_OPT_TITLE="Otimização e Tuning de Hardware"
LANG_CEPH_OPT_OPT_1="Verificar Governor CPU"
LANG_CEPH_OPT_OPT_2="Verificar Cache de Disco NVMe"
LANG_CEPH_OPT_OPT_3="Verificar Configuração de Rede (MTU)"

LANG_CEPH_OSD_TITLE="Utilitários de OSD (Device Classes)"
LANG_CEPH_OSD_OPT_1="Alterar Classe de OSD"
LANG_CEPH_OSD_OPT_2="Reiniciar OSD Local"

LANG_CEPH_MSG_NO_POOL="Nenhum pool encontrado no cluster."
LANG_CEPH_MSG_AVAIL_POOLS="Pools disponíveis:"
LANG_CEPH_MSG_SEL_POOL="Selecione o número do pool: "
LANG_CEPH_MSG_INV_SEL="Seleção inválida."
LANG_CEPH_MSG_CONT="Pressione uma tecla para continuar..."

# Status Menu
LANG_MAIN_ST_TITLE="STATUS DOS SERVIÇOS E CONFIGURAÇÕES:"
LANG_MAIN_ST_BKP="Backup Configs PVE"
LANG_MAIN_ST_TEMP="Monitor Temp (Cron)"
LANG_MAIN_ST_WEBUI="Sensores WebUI (PVE)"
LANG_MAIN_ST_AUTOSTART="Auto-Start Shell"
LANG_MAIN_ST_WATCHDOG="Watchdog de VMs"
LANG_MAIN_ST_TG_BOT="Bot Telegram (Inter)"
LANG_MAIN_ST_TG_NOTIF="Notificação Telegram"
LANG_MAIN_ST_UPDATE="Auto-Update Script"
LANG_MAIN_ST_IA="Assistente de IA"

LANG_ST_UNSCHEDULED="Não agendado"
LANG_ST_SCHED_CRON="Agendado (Cron)"
LANG_ST_CREATED_NOCRON="Criado (sem Cron)"
LANG_ST_ACTIVE_CRON2="Ativo (Cron 2min)"
LANG_ST_ACTIVE_CRON="Ativo (Cron)"
LANG_ST_DISABLED="Desativado"
LANG_ST_ENABLED="Ativado"
LANG_ST_INACTIVE="Inativo"
LANG_ST_CONFIGURED="Configurado"
LANG_ST_ACTIVE_RUN="Ativo (Rodando)"
LANG_ST_CONF_STOPPED="Configurado (Parado)"
LANG_ST_UNCONFIGURED="Não configurado"
LANG_ST_ENABLED_DEF="Ativada (Padrão)"
LANG_ST_DISABLED_FIX="Desativada (Versão Fixa)"
LANG_ST_UNCONFIGURED_F="Não configurada"
