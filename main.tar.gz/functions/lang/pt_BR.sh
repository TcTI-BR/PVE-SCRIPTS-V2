#!/bin/bash

# ==========================================
# Idioma: Português (Brasil)
# ==========================================

# --- Geral ---
LANG_SELECT_OPT="Selecione uma opção:"
LANG_TYPE_OPT="Digite sua opção"
LANG_PRESS_ENTER="(ou pressione ENTER para sair)"

# --- menu_vm_operations.sh ---
LANG_VM_OP_TITLE="Operações de VMs"
LANG_VM_OP_OPT_1="Live Migration sem Cluster"
LANG_VM_OP_OPT_2="Destranca, desliga e reinicia VM"
LANG_VM_OP_OPT_3="🚚 Migração / Importação de Discos (VHD/VMDK/VDI)"
LANG_VM_OP_OPT_4="💽 Repasse de HD/SSD Físico para VM (Passthrough)"
LANG_VM_OP_OPT_0="Voltar"
