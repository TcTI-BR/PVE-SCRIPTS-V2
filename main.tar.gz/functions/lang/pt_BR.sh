#!/bin/bash

# ==========================================
# Idioma: Português (Brasil)
# ==========================================

# --- Geral ---
LANG_SELECT_OPT="Selecione uma opção:"
LANG_TYPE_OPT="Digite sua opção"
LANG_PRESS_ENTER="(ou pressione ENTER para sair)"

# --- menu_vm_operations.sh ---
LANG_VM_OP_TITLE="Operações de VMs"
LANG_VM_OP_OPT_1="Live Migration sem Cluster"
LANG_VM_OP_OPT_2="Destranca, desliga e reinicia VM"
LANG_VM_OP_OPT_3="🚚 Migração / Importação de Discos (VHD/VMDK/VDI)"
LANG_VM_OP_OPT_4="💽 Repasse de HD/SSD Físico para VM (Passthrough)"
LANG_VM_OP_OPT_0="Voltar"

# --- main.sh (Menu Principal) ---
LANG_MAIN_TITLE="Menu Principal"
LANG_MAIN_OPT_1="Proxmox Virtual Environment (PVE)"
LANG_MAIN_DESC_1="Gerenciamento completo do Proxmox VE"
LANG_MAIN_OPT_2="Proxmox Backup Server (PBS)"
LANG_MAIN_DESC_2="Gerenciamento do Proxmox Backup Server"
LANG_MAIN_OPT_3="Ferramentas Gerais e Extras"
LANG_MAIN_DESC_3="Testes de disco, badblocks, SMART, etc."
LANG_MAIN_OPT_4="Configurações do Script"
LANG_MAIN_DESC_4="Alterar Idioma e opções globais"
LANG_MAIN_OPT_0="Sair"

# --- menu_config.sh ---
LANG_CONF_TITLE="Configurações do Script"
LANG_CONF_OPT_1="Alterar Idioma / Change Language"
LANG_CONF_LANG_CHOSEN="Idioma selecionado e salvo com sucesso!"
LANG_CONF_RESTARTING="Reiniciando o script para aplicar as alterações..."
