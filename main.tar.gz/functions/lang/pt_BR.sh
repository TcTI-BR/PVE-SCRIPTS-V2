#!/bin/bash

# ==========================================
# Idioma: Português (Brasil)
# ==========================================

# --- Geral ---
LANG_SELECT_OPT="Selecione uma opção:"
LANG_TYPE_OPT="Digite sua opção"
LANG_PRESS_ENTER="(ou pressione ENTER para sair)"

# --- menu_vm_operations.sh ---
LANG_VM_OP_TITLE="Operações de VMs"
LANG_VM_OP_OPT_1="Live Migration sem Cluster"
LANG_VM_OP_OPT_2="Destranca, desliga e reinicia VM"
LANG_VM_OP_OPT_3="🚚 Migração / Importação de Discos (VHD/VMDK/VDI)"
LANG_VM_OP_OPT_4="💽 Repasse de HD/SSD Físico para VM (Passthrough)"
LANG_VM_OP_OPT_0="Voltar"

# --- main.sh (Menu Principal) ---
LANG_MAIN_TITLE="Menu Principal"
LANG_MAIN_OPT_1="Proxmox Virtual Environment (PVE)"
LANG_MAIN_DESC_1="Gerenciamento completo do Proxmox VE"
LANG_MAIN_OPT_2="Proxmox Backup Server (PBS)"
LANG_MAIN_DESC_2="Gerenciamento do Proxmox Backup Server"
LANG_MAIN_OPT_3="Ferramentas Gerais e Extras"
LANG_MAIN_DESC_3="Testes de disco, badblocks, SMART, etc."
LANG_MAIN_OPT_4="Configurações do Script"
LANG_MAIN_DESC_4="Alterar Idioma e opções globais"
LANG_MAIN_OPT_0="Sair"

# --- menu_config.sh ---
LANG_CONF_TITLE="Configurações do Script"
LANG_CONF_OPT_1="Alterar Idioma / Change Language"
LANG_CONF_LANG_CHOSEN="Idioma selecionado e salvo com sucesso!"
LANG_CONF_RESTARTING="Reiniciando o script para aplicar as alterações..."

# --- menu_pve.sh ---
LANG_PVE_MENU_TITLE="Proxmox Virtual Environment - Menu Principal"
LANG_PVE_MENU_OPT_1="Atualização, instalação e upgrade do sistema"
LANG_PVE_MENU_OPT_2="Ferramentas de disco e sistemas de arquivos"
LANG_PVE_MENU_OPT_3="Tarefas de backup"
LANG_PVE_MENU_OPT_4="Operações de VMs"
LANG_PVE_MENU_OPT_5="Utilização de IA"
LANG_PVE_MENU_OPT_6="Sensores WebUI (Temp/Freq/Watts)"
LANG_PVE_MENU_OPT_0="Voltar ao menu principal"

# --- menu_pbs.sh ---
LANG_PBS_MENU_TITLE="Proxmox Backup Server - Menu Principal"
LANG_PBS_MENU_OPT_1="Atualização, instalação e upgrade do sistema"
LANG_PBS_MENU_OPT_2="Ferramentas de disco"
LANG_PBS_MENU_OPT_0="Voltar ao menu principal"

# --- menu_update.sh ---
LANG_UPDATE_MENU_TITLE="Atualização, Instalação e Upgrade do Sistema"
LANG_UPDATE_MENU_OPT_1="Upgrade de versões"
LANG_UPDATE_MENU_OPT_2="Atualização do sistema e aplicativos comuns"
LANG_UPDATE_MENU_OPT_3="Instala aplicativos"

# --- menu_disco.sh ---
LANG_DISCO_MENU_TITLE="Ferramentas de Disco e Sistemas de Arquivos"
LANG_DISCO_MENU_OPT_1="Configura discos"
LANG_DISCO_MENU_OPT_2="Remove o storage local-lvm"
LANG_DISCO_MENU_OPT_3="Ceph Utils - Gerenciamento de Cluster Ceph"

# --- menu_bkp.sh ---
LANG_BKP_MENU_TITLE="Tarefas de Backup"
LANG_BKP_MENU_OPT_1="Configura serviço de NFS para backup em rede"
LANG_BKP_MENU_OPT_2="Instala o PBS lado a lado com o PVE"
LANG_BKP_MENU_OPT_3="Agenda backup das configurações do Proxmox"
LANG_BKP_MENU_OPT_4="Restaura backup das configurações do Proxmox"

# --- menu_extras.sh ---
LANG_EXTRAS_MENU_TITLE="Ferramentas Gerais e Diagnósticos (Extras)"
LANG_EXTRAS_MENU_OPT_1="Ferramentas e Diagnósticos de Disco"
LANG_EXTRAS_MENU_DESC_1="Speed test, Badblocks, SMART info"
LANG_EXTRAS_MENU_OPT_2="Configuração de Notificações por E-mail"
LANG_EXTRAS_MENU_DESC_2="Configurar Postfix, SMTP, aliases e alertas"
LANG_EXTRAS_MENU_OPT_3="Configurações de Rede"
LANG_EXTRAS_MENU_DESC_3="Interfaces (/etc/network), DNS e Hosts"
LANG_EXTRAS_MENU_OPT_4="Ajustes de Sistema, Host e Watchdog"
LANG_EXTRAS_MENU_DESC_4="Temperatura, SWAP, Uptime, Auto-start e Watchdog"
LANG_EXTRAS_MENU_OPT_5="Comandos e Informações Úteis"
LANG_EXTRAS_MENU_DESC_5="Cheat-sheet: Linux, PVE (qm/pct) e caminhos"
LANG_EXTRAS_MENU_OPT_6="Gerenciamento de Chaves de IA"
LANG_EXTRAS_MENU_DESC_6="Cadastrar/Testar chaves API (OpenAI, Gemini, Claude)"
LANG_EXTRAS_MENU_OPT_7="Central de Gerenciamento e Notificações"
LANG_EXTRAS_MENU_DESC_7="Telegram Bot, WhatsApp e Integrações de Mensageria"

# --- menu_ia.sh ---
LANG_IA_MENU_TITLE="Utilização de IA"
LANG_IA_MENU_OPT_1="Verificar configurações de VMs e Containers"
LANG_IA_MENU_OPT_2="Gerenciar Chaves de IA (OpenAI, Gemini, Claude)"

# --- menu_upgrade.sh ---
LANG_UPGRADE_MENU_TITLE="Upgrade de Versões do Proxmox VE"
LANG_UPGRADE_MENU_ATTENTION="ATENÇÃO:"
LANG_UPGRADE_MENU_WARNING="Faça backup antes de realizar qualquer upgrade!"
LANG_UPGRADE_MENU_SELECT="Selecione a versão de destino:"
LANG_UPGRADE_MENU_OPT_1="Upgrade da versão 5.x para 6.x"
LANG_UPGRADE_MENU_OPT_2="Upgrade da versão 6.x para 7.x"
LANG_UPGRADE_MENU_OPT_3="Upgrade da versão 7.x para 8.x"
LANG_UPGRADE_MENU_OPT_4="Upgrade da versão 8.x para 9.x (Debian 13 Trixie)"

# --- menu_instala_aplicativos.sh ---
LANG_APPS_MENU_TITLE="Instalação de Aplicativos e Ferramentas"
LANG_APPS_MENU_OPT_1="TacticalRMM - Remote Monitoring & Management"
LANG_APPS_MENU_OPT_2="Cloudflare Tunnel - Túnel reverso seguro"
LANG_APPS_MENU_OPT_3="Zabbix Agent - Monitoramento de infraestrutura"
LANG_APPS_MENU_OPT_4="Outros aplicativos (Em breve)"

# --- menu_ceph.sh ---
LANG_CEPH_MENU_TITLE="Ceph Utils - Gerenciamento"
LANG_CEPH_MENU_OPT_1="Diagnóstico e Saúde (Read-Only)"
LANG_CEPH_MENU_OPT_2="Benchmark (Teste de Performance)"
LANG_CEPH_MENU_OPT_3="Gerenciamento de Pools"
LANG_CEPH_MENU_OPT_4="Otimização e Tuning (Hardware Check)"
LANG_CEPH_MENU_OPT_5="Utilitários de OSD (Device Classes)"

# --- menu_watch_dog.sh ---
LANG_WD_MENU_TITLE="Configuração do Watchdog"
LANG_WD_MENU_DESC="Watchdog: Monitora VMs e reinicia automaticamente caso offline"
LANG_WD_MENU_OPT_1="Cria agendamento (executa a cada 10 minutos)"
LANG_WD_MENU_OPT_2="Remove o agendamento"
LANG_WD_MENU_OPT_3="Lista VMs monitoradas"
LANG_WD_MENU_OPT_4="Adiciona VM ao monitoramento"
LANG_WD_MENU_OPT_5="Remove VM do monitoramento"

# --- menu_webui_sensors.sh ---
LANG_WEBUI_MENU_TITLE="Customização & Sensores de Hardware na WebUI do PVE"
LANG_WEBUI_MENU_INFO="INFORMAÇÕES DE SEGURANÇA:"
LANG_WEBUI_MENU_INFO_1="Os arquivos originais limpos são salvos em:"
LANG_WEBUI_MENU_INFO_2="Você pode restaurar a WebUI oficial a qualquer momento."
LANG_WEBUI_MENU_STATUS_ON="[ATIVADO] Sensores de Hardware Ativos na WebUI"
LANG_WEBUI_MENU_STATUS_OFF="[DESATIVADO] WebUI Padrão do Proxmox"
LANG_WEBUI_MENU_STATUS="Status Atual:"
LANG_WEBUI_MENU_OPT_1="Ativar Sensores de Temp, MHz, Watts & Discos na WebUI"
LANG_WEBUI_MENU_OPT_2="Restaurar WebUI Original (Restaurar do Backup)"
LANG_WEBUI_MENU_OPT_3="Reinstalar Pacotes Oficiais Proxmox (Restauração Total Limpa)"

# --- menu_instala_zabbix.sh ---
LANG_ZABBIX_MENU_TITLE="Zabbix Agent - Monitoramento"
LANG_ZABBIX_MENU_STATUS_TITLE="STATUS DO AGENTE:"
LANG_ZABBIX_MENU_ACTIVE="Serviço ativo e rodando"
LANG_ZABBIX_MENU_STOPPED="Serviço parado"
LANG_ZABBIX_MENU_NOT_INSTALLED="Zabbix Agent não instalado"
LANG_ZABBIX_MENU_OPT_1="Instalar/Configurar Zabbix Agent"
LANG_ZABBIX_MENU_OPT_2="Remover Zabbix Agent"
LANG_ZABBIX_MENU_ALREADY_INSTALLED="(já instalado)"
LANG_ZABBIX_MENU_REQ_INSTALL="(requer instalação)"

# --- menu_instala_tactical_rmm.sh ---
LANG_TRMM_MENU_TITLE="Gerenciador de Agente TacticalRMM"
LANG_TRMM_MENU_STATUS_INSTALLED="TacticalRMM Agent instalado"
LANG_TRMM_MENU_STATUS_NOT_INSTALLED="TacticalRMM Agent não instalado"
LANG_TRMM_MENU_OPT_1="Instalar novo agente"
LANG_TRMM_MENU_OPT_2="Desinstalar agente / Limpar vestígios"

# --- menu_instala_cloudflared.sh ---
LANG_CF_MENU_TITLE="Túnel Reverso Cloudflare"
LANG_CF_MENU_STATUS_INSTALLED="Cloudflared instalado"
LANG_CF_MENU_STATUS_NOT_INSTALLED="Cloudflared não instalado"
LANG_CF_MENU_STATUS_RUNNING="Serviço ativo e rodando"
LANG_CF_MENU_STATUS_STOPPED="Serviço configurado mas não está rodando"
LANG_CF_MENU_STATUS_NOT_CONFIGURED="Serviço não configurado"
LANG_CF_MENU_OPT_1="Instalação do túnel Cloudflare"
LANG_CF_MENU_OPT_2="Configurar serviço e chave do cliente"
LANG_CF_MENU_OPT_3="Remover o túnel"

# --- menu_instala_script.sh ---
LANG_AUTOSTART_MENU_TITLE="Auto-Inicialização do Script"
LANG_AUTOSTART_MENU_OPT_1="Instala script ao carregar o usuário"
LANG_AUTOSTART_MENU_OPT_2="Desinstala script ao carregar o usuário"

# --- vm_disk_passthrough.sh ---
LANG_PASSTHROUGH_MENU_TITLE="Assistente de Repasse de Discos Físicos (Passthrough)"
LANG_PASSTHROUGH_MENU_DESC_1="Este assistente permite conectar um HD/SSD físico (via USB ou SATA)"
LANG_PASSTHROUGH_MENU_DESC_2="diretamente a uma Máquina Virtual como um dispositivo de bloco."
LANG_PASSTHROUGH_MENU_DESC_3="➜ Ideal para P2V, clonagem com Clonezilla ou TrueNAS."
LANG_PASSTHROUGH_MENU_OPT_1="Anexar um HD/SSD físico a uma VM"
LANG_PASSTHROUGH_MENU_OPT_2="Desanexar (Remover) um disco físico de uma VM"

# --- vm_config_checker.sh ---
LANG_CONFIG_CHECKER_MENU_TITLE="IA Auditor de VMs / CTs"
LANG_CONFIG_CHECKER_MENU_OPT_1="Verificar TODAS as VMs e Containers"
LANG_CONFIG_CHECKER_MENU_OPT_2="Verificar uma VM/Container específico"
LANG_CONFIG_CHECKER_MENU_OPT_3="📨 Enviar relatório de TODAS via Telegram"
LANG_CONFIG_CHECKER_MENU_OPT_4="📨 Enviar relatório de uma VM/CT via Telegram"

# --- destranca_desliga.sh ---
LANG_UNLOCK_MENU_TITLE="Destranca, Desliga e Reinicia VM"

# Disk prep
LANG_DISK_PREP="Qual o disco que vai ser preparado? EX: sda / nvme0n1"
LANG_DISK_NAME="Qual o nome do Storage? EX: VM01 / RECOVER / BACKUP_2HD / BACKUP_REDE / EXTERNO_TERCA / EXTERNO_QUINTA"
LANG_DISK_USAGE="O disco será para ${COLOR_RED}BACKUP${COLOR_RESET} ou ${COLOR_RED}VM${COLOR_RESET}?: Digite exatamente ${COLOR_RED}images${COLOR_RESET} para VM ou ${COLOR_RED}backup${COLOR_RESET} para BACKUP sem as aspas"
LANG_DISK_PBS_NAME="Qual o nome do Datastore? EX: BACKUP_REDE / STORE_01"
