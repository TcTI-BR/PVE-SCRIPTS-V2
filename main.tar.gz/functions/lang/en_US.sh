#!/bin/bash

# ==========================================
# Idioma: English (US)
# ==========================================

# --- Geral ---
LANG_SELECT_OPT="Select an option:"
LANG_TYPE_OPT="Type your option"
LANG_PRESS_ENTER="(or press ENTER to exit)"

# --- menu_vm_operations.sh ---
LANG_VM_OP_TITLE="VM Operations"
LANG_VM_OP_OPT_1="Clusterless Live Migration"
LANG_VM_OP_OPT_2="Unlock, Stop and Reboot VM"
LANG_VM_OP_OPT_3="🚚 Disk Migration / Import (VHD/VMDK/VDI)"
LANG_VM_OP_OPT_4="💽 Physical HD/SSD Passthrough for VM"
LANG_VM_OP_OPT_0="Back"
