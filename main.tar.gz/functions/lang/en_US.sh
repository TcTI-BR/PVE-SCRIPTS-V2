#!/bin/bash

# ==========================================
# Idioma: English (US)
# ==========================================

# --- Geral ---
LANG_SELECT_OPT="Select an option:"
LANG_TYPE_OPT="Type your option"
LANG_PRESS_ENTER="(or press ENTER to exit)"

# --- menu_vm_operations.sh ---
LANG_VM_OP_TITLE="VM Operations"
LANG_VM_OP_OPT_1="Clusterless Live Migration"
LANG_VM_OP_OPT_2="Unlock, Stop and Reboot VM"
LANG_VM_OP_OPT_3="🚚 Disk Migration / Import (VHD/VMDK/VDI)"
LANG_VM_OP_OPT_4="💽 Physical HD/SSD Passthrough for VM"
LANG_VM_OP_OPT_0="Back"

# --- main.sh (Menu Principal) ---
LANG_MAIN_TITLE="Main Menu"
LANG_MAIN_OPT_1="Proxmox Virtual Environment (PVE)"
LANG_MAIN_DESC_1="Full management of Proxmox VE"
LANG_MAIN_OPT_2="Proxmox Backup Server (PBS)"
LANG_MAIN_DESC_2="Proxmox Backup Server management"
LANG_MAIN_OPT_3="General Tools and Extras"
LANG_MAIN_DESC_3="Disk tests, badblocks, SMART, etc."
LANG_MAIN_OPT_4="Script Settings"
LANG_MAIN_DESC_4="Change Language and global options"
LANG_MAIN_OPT_0="Exit"

# --- menu_config.sh ---
LANG_CONF_TITLE="Script Settings"
LANG_CONF_OPT_1="Change Language / Alterar Idioma"
LANG_CONF_LANG_CHOSEN="Language selected and saved successfully!"
LANG_CONF_RESTARTING="Restarting script to apply changes..."

# --- menu_pve.sh ---
LANG_PVE_MENU_TITLE="Proxmox Virtual Environment - Main Menu"
LANG_PVE_MENU_OPT_1="System update, install and upgrade"
LANG_PVE_MENU_OPT_2="Disk tools and file systems"
LANG_PVE_MENU_OPT_3="Backup tasks"
LANG_PVE_MENU_OPT_4="VM Operations"
LANG_PVE_MENU_OPT_5="AI Utilization"
LANG_PVE_MENU_OPT_6="WebUI Sensors (Temp/Freq/Watts)"
LANG_PVE_MENU_OPT_0="Return to main menu"

# --- menu_pbs.sh ---
LANG_PBS_MENU_TITLE="Proxmox Backup Server - Main Menu"
LANG_PBS_MENU_OPT_1="System update, install and upgrade"
LANG_PBS_MENU_OPT_2="Disk tools"
LANG_PBS_MENU_OPT_0="Return to main menu"

# --- menu_update.sh ---
LANG_UPDATE_MENU_TITLE="System Update, Install, and Upgrade"
LANG_UPDATE_MENU_OPT_1="Version upgrade"
LANG_UPDATE_MENU_OPT_2="System update and common apps"
LANG_UPDATE_MENU_OPT_3="Install applications"

# --- menu_disco.sh ---
LANG_DISCO_MENU_TITLE="Disk Tools and File Systems"
LANG_DISCO_MENU_OPT_1="Configure disks"
LANG_DISCO_MENU_OPT_2="Remove local-lvm storage"
LANG_DISCO_MENU_OPT_3="Ceph Utils - Ceph Cluster Management"

# --- menu_bkp.sh ---
LANG_BKP_MENU_TITLE="Backup Tasks"
LANG_BKP_MENU_OPT_1="Configure NFS service for network backup"
LANG_BKP_MENU_OPT_2="Install PBS side-by-side with PVE"
LANG_BKP_MENU_OPT_3="Schedule Proxmox settings backup"
LANG_BKP_MENU_OPT_4="Restore Proxmox settings backup"

# --- menu_extras.sh ---
LANG_EXTRAS_MENU_TITLE="General Tools and Diagnostics (Extras)"
LANG_EXTRAS_MENU_OPT_1="Disk Tools and Diagnostics"
LANG_EXTRAS_MENU_DESC_1="Speed test, Badblocks, SMART info"
LANG_EXTRAS_MENU_OPT_2="Email Notifications Configuration"
LANG_EXTRAS_MENU_DESC_2="Configure Postfix, SMTP, aliases, and alerts"
LANG_EXTRAS_MENU_OPT_3="Network Configurations"
LANG_EXTRAS_MENU_DESC_3="Interfaces (/etc/network), DNS, and Hosts"
LANG_EXTRAS_MENU_OPT_4="System, Host, and Watchdog Tweaks"
LANG_EXTRAS_MENU_DESC_4="Temperature, SWAP, Uptime, Auto-start, Watchdog"
LANG_EXTRAS_MENU_OPT_5="Commands and Useful Information"
LANG_EXTRAS_MENU_DESC_5="Cheat-sheet: Linux, PVE (qm/pct) and paths"
LANG_EXTRAS_MENU_OPT_6="AI Keys Management"
LANG_EXTRAS_MENU_DESC_6="Register/Test API keys (OpenAI, Gemini, Claude)"
LANG_EXTRAS_MENU_OPT_7="Central Management and Notifications"
LANG_EXTRAS_MENU_DESC_7="Telegram Bot, WhatsApp and integrations"

# --- menu_ia.sh ---
LANG_IA_MENU_TITLE="AI Utilization"
LANG_IA_MENU_OPT_1="Check VMs and Containers configurations"
LANG_IA_MENU_OPT_2="Manage AI Keys (OpenAI, Gemini, Claude)"

# --- menu_upgrade.sh ---
LANG_UPGRADE_MENU_TITLE="Proxmox VE Version Upgrade"
LANG_UPGRADE_MENU_ATTENTION="ATTENTION:"
LANG_UPGRADE_MENU_WARNING="Make a backup before performing any upgrade!"
LANG_UPGRADE_MENU_SELECT="Select the destination version:"
LANG_UPGRADE_MENU_OPT_1="Upgrade from version 5.x to 6.x"
LANG_UPGRADE_MENU_OPT_2="Upgrade from version 6.x to 7.x"
LANG_UPGRADE_MENU_OPT_3="Upgrade from version 7.x to 8.x"
LANG_UPGRADE_MENU_OPT_4="Upgrade from version 8.x to 9.x (Debian 13 Trixie)"

# --- menu_instala_aplicativos.sh ---
LANG_APPS_MENU_TITLE="Applications and Tools Installation"
LANG_APPS_MENU_OPT_1="TacticalRMM - Remote Monitoring & Management"
LANG_APPS_MENU_OPT_2="Cloudflare Tunnel - Secure reverse tunnel"
LANG_APPS_MENU_OPT_3="Zabbix Agent - Infrastructure monitoring"
LANG_APPS_MENU_OPT_4="Other applications (Coming soon)"

# --- menu_ceph.sh ---
LANG_CEPH_MENU_TITLE="Ceph Utils - Management"
LANG_CEPH_MENU_OPT_1="Diagnostics and Health (Read-Only)"
LANG_CEPH_MENU_OPT_2="Benchmark (Performance Test)"
LANG_CEPH_MENU_OPT_3="Pools Management"
LANG_CEPH_MENU_OPT_4="Optimization and Tuning (Hardware Check)"
LANG_CEPH_MENU_OPT_5="OSD Utilities (Device Classes)"

# --- menu_watch_dog.sh ---
LANG_WD_MENU_TITLE="Watchdog Configuration"
LANG_WD_MENU_DESC="Watchdog: Monitors VMs and restarts automatically if offline"
LANG_WD_MENU_OPT_1="Create schedule (runs every 10 minutes)"
LANG_WD_MENU_OPT_2="Remove schedule"
LANG_WD_MENU_OPT_3="List monitored VMs"
LANG_WD_MENU_OPT_4="Add VM to monitoring"
LANG_WD_MENU_OPT_5="Remove VM from monitoring"

# --- menu_webui_sensors.sh ---
LANG_WEBUI_MENU_TITLE="Hardware Customization & Sensors in PVE WebUI"
LANG_WEBUI_MENU_INFO="SECURITY INFORMATION:"
LANG_WEBUI_MENU_INFO_1="Clean original files are saved in:"
LANG_WEBUI_MENU_INFO_2="You can restore the official WebUI at any time."
LANG_WEBUI_MENU_STATUS_ON="[ENABLED] Hardware Sensors Active in WebUI"
LANG_WEBUI_MENU_STATUS_OFF="[DISABLED] Standard Proxmox WebUI"
LANG_WEBUI_MENU_STATUS="Current Status:"
LANG_WEBUI_MENU_OPT_1="Enable Temp, MHz, Watts & Disks Sensors in WebUI"
LANG_WEBUI_MENU_OPT_2="Restore Original WebUI (Restore from Backup)"
LANG_WEBUI_MENU_OPT_3="Reinstall Official Proxmox Packages (Clean Total Restore)"

# --- menu_instala_zabbix.sh ---
LANG_ZABBIX_MENU_TITLE="Zabbix Agent - Monitoring"
LANG_ZABBIX_MENU_STATUS_TITLE="AGENT STATUS:"
LANG_ZABBIX_MENU_ACTIVE="Service active and running"
LANG_ZABBIX_MENU_STOPPED="Service stopped"
LANG_ZABBIX_MENU_NOT_INSTALLED="Zabbix Agent not installed"
LANG_ZABBIX_MENU_OPT_1="Install/Configure Zabbix Agent"
LANG_ZABBIX_MENU_OPT_2="Remove Zabbix Agent"
LANG_ZABBIX_MENU_ALREADY_INSTALLED="(already installed)"
LANG_ZABBIX_MENU_REQ_INSTALL="(requires installation)"

# --- menu_instala_tactical_rmm.sh ---
LANG_TRMM_MENU_TITLE="TacticalRMM Agent Manager"
LANG_TRMM_MENU_STATUS_INSTALLED="TacticalRMM Agent installed"
LANG_TRMM_MENU_STATUS_NOT_INSTALLED="TacticalRMM Agent not installed"
LANG_TRMM_MENU_OPT_1="Install new agent"
LANG_TRMM_MENU_OPT_2="Uninstall agent / Clean traces"

# --- menu_instala_cloudflared.sh ---
LANG_CF_MENU_TITLE="Cloudflare Reverse Tunnel"
LANG_CF_MENU_STATUS_INSTALLED="Cloudflared installed"
LANG_CF_MENU_STATUS_NOT_INSTALLED="Cloudflared not installed"
LANG_CF_MENU_STATUS_RUNNING="Service active and running"
LANG_CF_MENU_STATUS_STOPPED="Service configured but not running"
LANG_CF_MENU_STATUS_NOT_CONFIGURED="Service not configured"
LANG_CF_MENU_OPT_1="Install Cloudflare tunnel"
LANG_CF_MENU_OPT_2="Configure service and client key"
LANG_CF_MENU_OPT_3="Remove tunnel"

# --- menu_instala_script.sh ---
LANG_AUTOSTART_MENU_TITLE="Script Auto-Start"
LANG_AUTOSTART_MENU_OPT_1="Install script on user login"
LANG_AUTOSTART_MENU_OPT_2="Uninstall script on user login"

# --- vm_disk_passthrough.sh ---
LANG_PASSTHROUGH_MENU_TITLE="Physical Disk Passthrough Wizard"
LANG_PASSTHROUGH_MENU_DESC_1="This wizard allows connecting a physical HDD/SSD (via USB or SATA)"
LANG_PASSTHROUGH_MENU_DESC_2="directly to a Virtual Machine as a block device."
LANG_PASSTHROUGH_MENU_DESC_3="➜ Ideal for P2V, cloning with Clonezilla, or TrueNAS."
LANG_PASSTHROUGH_MENU_OPT_1="Attach a physical HDD/SSD to a VM"
LANG_PASSTHROUGH_MENU_OPT_2="Detach (Remove) a physical disk from a VM"

# --- vm_config_checker.sh ---
LANG_CONFIG_CHECKER_MENU_TITLE="AI VM / CT Auditor"
LANG_CONFIG_CHECKER_MENU_OPT_1="Check ALL VMs and Containers"
LANG_CONFIG_CHECKER_MENU_OPT_2="Check a specific VM/Container"
LANG_CONFIG_CHECKER_MENU_OPT_3="📨 Send report of ALL via Telegram"
LANG_CONFIG_CHECKER_MENU_OPT_4="📨 Send report of one VM/CT via Telegram"

# --- destranca_desliga.sh ---
LANG_UNLOCK_MENU_TITLE="Unlock, Power Off, and Restart VM"
LANG_UNLOCK_MENU_OPT_1="Unlock VM"
LANG_UNLOCK_MENU_OPT_2="Unlock and power off VM"
LANG_UNLOCK_MENU_OPT_3="Unlock, power off, and restart VM"

# --- menu_upgrade_pbs.sh ---
LANG_PBS_UPGRADE_TITLE="Proxmox PBS Version Upgrade"
LANG_PBS_UPGRADE_WARN="Perform a backup before doing any upgrade!"
LANG_PBS_UPGRADE_SELECT="Select the target version:"
LANG_PBS_UPGRADE_OPT_1="Upgrade from version 1.x to 2.x"

# --- menu_update_pbs.sh ---
LANG_PBS_UPDATE_TITLE="System Update, Installation, and Upgrade"
LANG_PBS_UPDATE_OPT_1="Version upgrades"
LANG_PBS_UPDATE_OPT_2="Update system and common applications"

# --- menu_disco_pbs.sh ---
LANG_PBS_DISK_TITLE="Disk Tools (PBS)"
LANG_PBS_DISK_OPT_1="Configure disk and create PBS Datastore"

# --- menu_telegram.sh ---
LANG_TELEGRAM_MENU_TITLE="Telegram Management"
LANG_TELEGRAM_MENU_STATUS_TITLE="Status:"
LANG_TELEGRAM_MENU_STATUS_ACTIVE="Active and running"
LANG_TELEGRAM_MENU_STATUS_INACTIVE="Inactive or with error"
LANG_TELEGRAM_MENU_STATUS_UNINSTALLED="Not installed"
LANG_TELEGRAM_MENU_OPT_1_INSTALL="Install and Configure Bot"
LANG_TELEGRAM_MENU_OPT_1_RECONFIG="Reconfigure Bot"
LANG_TELEGRAM_MENU_OPT_2="Uninstall Bot"
LANG_TELEGRAM_MENU_OPT_3="Restart Service"
LANG_TELEGRAM_MENU_OPT_4="View Bot Logs"
LANG_TELEGRAM_MENU_OPT_5="Update Bot"
LANG_TELEGRAM_MENU_OPT_5_DESC="(keep credentials)"

# --- menu_extras_sistema.sh ---
LANG_EXTRAS_SYS_MENU_TITLE="System, Host and Watchdog Adjustments"
LANG_EXTRAS_SYS_MENU_OPT_1="🔥 Thermal Monitoring & Hardware Protection"
LANG_EXTRAS_SYS_MENU_OPT_2="Configure SWAP (swappiness)"
LANG_EXTRAS_SYS_MENU_OPT_3="Host performance information"
LANG_EXTRAS_SYS_MENU_OPT_4="Install/uninstall script on shell startup"
LANG_EXTRAS_SYS_MENU_OPT_5="VM Watchdog Configuration (Auto-restart via Ping)"

# Disclaimer
LANG_DISCLAIMER_TITLE="DISCLAIMER OF LIABILITY"
LANG_DISCLAIMER_1="The use of this script is strictly at the ${COLOR_RED}USER'S OWN RISK${COLOR_YELLOW}."
LANG_DISCLAIMER_2_1="The person or company providing this script ${COLOR_RED}SHALL NOT BE HELD LIABLE${COLOR_WHITE}"
LANG_DISCLAIMER_2_2="for any ${COLOR_RED}issues or damages caused${COLOR_WHITE} by its use."
LANG_DISCLAIMER_3_1="Before using it, carefully ${COLOR_GREEN}evaluate and understand${COLOR_WHITE}"
LANG_DISCLAIMER_3_2="the implications of its execution."
LANG_DISCLAIMER_4_1="${COLOR_RED}Make sure${COLOR_WHITE} the script is ${COLOR_GREEN}safe and suitable${COLOR_WHITE} for"
LANG_DISCLAIMER_4_2="your needs before running it."
LANG_DISCLAIMER_AGREE="By pressing ENTER you ${COLOR_RED}AGREE${COLOR_CYAN} to the terms above"

# Updater strings
LANG_UPD_TITLE="TcTI Proxmox Scripts - Update System"
LANG_UPD_DISABLED="Automatic update disabled in settings."
LANG_UPD_LOCAL="Starting with local version."
LANG_UPD_CONN="Checking internet connection..."
LANG_UPD_OFFLINE="Offline Mode: No connection. Starting with local version."
LANG_UPD_CHECK="Checking for updates..."
LANG_UPD_REPO_FAIL="Failed to query repository. Starting with local version."
LANG_UPD_LATEST="The script is already at the latest version!"
LANG_UPD_NEW="New version detected! Downloading update (tar.gz)..."
LANG_UPD_DL_OK="Download and extraction completed."
LANG_UPD_APPLY="Applying update..."
LANG_UPD_SUCCESS="Update applied successfully!"
LANG_UPD_RESTART="Restarting script automatically..."
LANG_UPD_ERR_FOLDER="Error: Extracted folder not found."
LANG_UPD_DL_FAIL="Failed to download or extract the package. Starting with local version."
LANG_UPD_LOAD_MODS="Loading modules..."
LANG_UPD_PVE="Proxmox Virtual Environment (PVE)"
LANG_UPD_PBS="Proxmox Backup Server (PBS)"
LANG_UPD_EXTRAS="General Tools (Extras)"
LANG_UPD_PVE_LOADED="PVE modules loaded"
LANG_UPD_PBS_LOADED="PBS modules loaded"
LANG_UPD_EXTRAS_LOADED="Extras modules loaded"

