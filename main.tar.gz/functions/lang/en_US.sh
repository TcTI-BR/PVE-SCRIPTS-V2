#!/bin/bash

# ==========================================
# Idioma: English (US)
# ==========================================

# --- Geral ---
LANG_SELECT_OPT="Select an option:"
LANG_TYPE_OPT="Type your option"
LANG_PRESS_ENTER="(or press ENTER to exit)"

# --- menu_vm_operations.sh ---
LANG_VM_OP_TITLE="VM Operations"
LANG_VM_OP_OPT_1="Clusterless Live Migration"
LANG_VM_OP_OPT_2="Unlock, Stop and Reboot VM"
LANG_VM_OP_OPT_3="🚚 Disk Migration / Import (VHD/VMDK/VDI)"
LANG_VM_OP_OPT_4="💽 Physical HD/SSD Passthrough for VM"
LANG_VM_OP_OPT_0="Back"

# --- main.sh (Menu Principal) ---
LANG_MAIN_TITLE="Main Menu"
LANG_MAIN_OPT_1="Proxmox Virtual Environment (PVE)"
LANG_MAIN_DESC_1="Full management of Proxmox VE"
LANG_MAIN_OPT_2="Proxmox Backup Server (PBS)"
LANG_MAIN_DESC_2="Proxmox Backup Server management"
LANG_MAIN_OPT_3="General Tools and Extras"
LANG_MAIN_DESC_3="Disk tests, badblocks, SMART, etc."
LANG_MAIN_OPT_4="Script Settings"
LANG_MAIN_DESC_4="Change Language and global options"
LANG_MAIN_OPT_0="Exit"

# --- menu_config.sh ---
LANG_CONF_TITLE="Script Settings"
LANG_CONF_OPT_1="Change Language / Alterar Idioma"
LANG_CONF_LANG_CHOSEN="Language selected and saved successfully!"
LANG_CONF_RESTARTING="Restarting script to apply changes..."
