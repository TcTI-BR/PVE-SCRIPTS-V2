#!/bin/bash

# ==========================================
# Idioma: 简体中文 (Chinese Simplified)
# ==========================================

# --- Geral ---
LANG_SELECT_OPT="请选择一个选项:"
LANG_TYPE_OPT="输入您的选项"
LANG_PRESS_ENTER="(或按 ENTER 退出)"

# --- menu_vm_operations.sh ---
LANG_VM_OP_TITLE="虚拟机操作"
LANG_VM_OP_OPT_1="无集群实时迁移"
LANG_VM_OP_OPT_2="解锁、关闭并重启虚拟机"
LANG_VM_OP_OPT_3="🚚 磁盘迁移 / 导入 (VHD/VMDK/VDI)"
LANG_VM_OP_OPT_4="💽 物理硬盘/SSD 直通虚拟机"
LANG_VM_OP_OPT_0="返回"

# --- main.sh (Menu Principal) ---
LANG_MAIN_TITLE="主菜单"
LANG_MAIN_OPT_1="Proxmox 虚拟化环境 (PVE)"
LANG_MAIN_DESC_1="全面管理 Proxmox VE"
LANG_MAIN_OPT_2="Proxmox 备份服务器 (PBS)"
LANG_MAIN_DESC_2="管理 Proxmox Backup Server"
LANG_MAIN_OPT_3="常规工具与扩展"
LANG_MAIN_DESC_3="磁盘测试, 坏块检测, SMART 等"
LANG_MAIN_OPT_4="脚本设置"
LANG_MAIN_DESC_4="更改语言和全局选项"
LANG_MAIN_OPT_0="退出"

# --- menu_config.sh ---
LANG_CONF_TITLE="脚本设置"
LANG_CONF_OPT_1="更改语言 / Change Language"
LANG_CONF_LANG_CHOSEN="语言已成功选择并保存！"
LANG_CONF_RESTARTING="正在重启脚本以应用更改..."
