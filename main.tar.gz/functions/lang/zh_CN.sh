#!/bin/bash

# ==========================================
# Idioma: 简体中文 (Chinese Simplified)
# ==========================================

# --- Geral ---
LANG_SELECT_OPT="请选择一个选项:"
LANG_TYPE_OPT="输入您的选项"
LANG_PRESS_ENTER="(或按 ENTER 退出)"

# --- menu_vm_operations.sh ---
LANG_VM_OP_TITLE="虚拟机操作"
LANG_VM_OP_OPT_1="无集群实时迁移"
LANG_VM_OP_OPT_2="解锁、关闭并重启虚拟机"
LANG_VM_OP_OPT_3="🚚 磁盘迁移 / 导入 (VHD/VMDK/VDI)"
LANG_VM_OP_OPT_4="💽 物理硬盘/SSD 直通虚拟机"
LANG_VM_OP_OPT_0="返回"
