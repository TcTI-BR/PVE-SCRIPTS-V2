#!/bin/bash

# ==========================================
# Idioma: 简体中文 (Chinese Simplified)
# ==========================================

# --- Geral ---
LANG_SELECT_OPT="请选择一个选项:"
LANG_TYPE_OPT="输入您的选项"
LANG_PRESS_ENTER="(或按 ENTER 退出)"

# --- menu_vm_operations.sh ---
LANG_VM_OP_TITLE="虚拟机操作"
LANG_VM_OP_OPT_1="无集群实时迁移"
LANG_VM_OP_OPT_2="解锁、关闭并重启虚拟机"
LANG_VM_OP_OPT_3="🚚 磁盘迁移 / 导入 (VHD/VMDK/VDI)"
LANG_VM_OP_OPT_4="💽 物理硬盘/SSD 直通虚拟机"
LANG_VM_OP_OPT_0="返回"

# --- main.sh (Menu Principal) ---
LANG_MAIN_TITLE="主菜单"
LANG_MAIN_OPT_1="Proxmox 虚拟化环境 (PVE)"
LANG_MAIN_DESC_1="全面管理 Proxmox VE"
LANG_MAIN_OPT_2="Proxmox 备份服务器 (PBS)"
LANG_MAIN_DESC_2="管理 Proxmox Backup Server"
LANG_MAIN_OPT_3="常规工具与扩展"
LANG_MAIN_DESC_3="磁盘测试, 坏块检测, SMART 等"
LANG_MAIN_OPT_4="脚本设置"
LANG_MAIN_DESC_4="更改语言和全局选项"
LANG_MAIN_OPT_0="退出"

# --- menu_config.sh ---
LANG_CONF_TITLE="脚本设置"
LANG_CONF_OPT_1="更改语言 / Change Language"
LANG_CONF_LANG_CHOSEN="语言已成功选择并保存！"
LANG_CONF_RESTARTING="正在重启脚本以应用更改..."

# --- menu_pve.sh ---
LANG_PVE_MENU_TITLE="Proxmox 虚拟化环境 - 主菜单"
LANG_PVE_MENU_OPT_1="系统更新、安装和升级"
LANG_PVE_MENU_OPT_2="磁盘工具和文件系统"
LANG_PVE_MENU_OPT_3="备份任务"
LANG_PVE_MENU_OPT_4="虚拟机操作"
LANG_PVE_MENU_OPT_5="AI 辅助功能"
LANG_PVE_MENU_OPT_6="WebUI 传感器 (温度/频率/功耗)"
LANG_PVE_MENU_OPT_0="返回主菜单"

# --- menu_pbs.sh ---
LANG_PBS_MENU_TITLE="Proxmox 备份服务器 - 主菜单"
LANG_PBS_MENU_OPT_1="系统更新、安装和升级"
LANG_PBS_MENU_OPT_2="磁盘工具"
LANG_PBS_MENU_OPT_0="返回主菜单"

# --- menu_update.sh ---
LANG_UPDATE_MENU_TITLE="系统更新、安装和升级"
LANG_UPDATE_MENU_OPT_1="版本升级"
LANG_UPDATE_MENU_OPT_2="更新系统和常用应用程序"
LANG_UPDATE_MENU_OPT_3="安装应用程序"

# --- menu_disco.sh ---
LANG_DISCO_MENU_TITLE="磁盘工具和文件系统"
LANG_DISCO_MENU_OPT_1="配置磁盘"
LANG_DISCO_MENU_OPT_2="移除 local-lvm 存储"
LANG_DISCO_MENU_OPT_3="Ceph Utils - Ceph 集群管理"

# --- menu_bkp.sh ---
LANG_BKP_MENU_TITLE="备份任务"
LANG_BKP_MENU_OPT_1="配置网络备份 NFS 服务"
LANG_BKP_MENU_OPT_2="在 PVE 旁安装 PBS"
LANG_BKP_MENU_OPT_3="配置 Proxmox 设置的定时备份"
LANG_BKP_MENU_OPT_4="恢复 Proxmox 设置备份"

# --- menu_extras.sh ---
LANG_EXTRAS_MENU_TITLE="常规工具与诊断 (扩展)"
LANG_EXTRAS_MENU_OPT_1="磁盘工具和诊断"
LANG_EXTRAS_MENU_DESC_1="测速, Badblocks, SMART 信息"
LANG_EXTRAS_MENU_OPT_2="电子邮件通知配置"
LANG_EXTRAS_MENU_DESC_2="配置 Postfix, SMTP, 别名和警报"
LANG_EXTRAS_MENU_OPT_3="网络配置"
LANG_EXTRAS_MENU_DESC_3="接口 (/etc/network), DNS 和 Hosts"
LANG_EXTRAS_MENU_OPT_4="系统, 主机和看门狗调整"
LANG_EXTRAS_MENU_DESC_4="温度, SWAP, 运行时间, 自启, 看门狗"
LANG_EXTRAS_MENU_OPT_5="命令和实用信息"
LANG_EXTRAS_MENU_DESC_5="备忘单: Linux, PVE (qm/pct) 和路径"
LANG_EXTRAS_MENU_OPT_6="AI 密钥管理"
LANG_EXTRAS_MENU_DESC_6="注册/测试 API 密钥 (OpenAI, Gemini, Claude)"
LANG_EXTRAS_MENU_OPT_7="管理和通知中心"
LANG_EXTRAS_MENU_DESC_7="Telegram Bot, WhatsApp 和集成"

# --- menu_ia.sh ---
LANG_IA_MENU_TITLE="AI 辅助功能"
LANG_IA_MENU_OPT_1="检查虚拟机和容器配置"
LANG_IA_MENU_OPT_2="管理 AI 密钥 (OpenAI, Gemini, Claude)"

# --- menu_upgrade.sh ---
LANG_UPGRADE_MENU_TITLE="Proxmox VE 版本升级"
LANG_UPGRADE_MENU_ATTENTION="注意:"
LANG_UPGRADE_MENU_WARNING="在执行任何升级之前，请务必进行备份！"
LANG_UPGRADE_MENU_SELECT="选择目标版本:"
LANG_UPGRADE_MENU_OPT_1="从 5.x 升级到 6.x"
LANG_UPGRADE_MENU_OPT_2="从 6.x 升级到 7.x"
LANG_UPGRADE_MENU_OPT_3="从 7.x 升级到 8.x"
LANG_UPGRADE_MENU_OPT_4="从 8.x 升级到 9.x (Debian 13 Trixie)"

# --- menu_instala_aplicativos.sh ---
LANG_APPS_MENU_TITLE="应用程序和工具安装"
LANG_APPS_MENU_OPT_1="TacticalRMM - 远程监控与管理"
LANG_APPS_MENU_OPT_2="Cloudflare Tunnel - 安全反向隧道"
LANG_APPS_MENU_OPT_3="Zabbix Agent - 基础架构监控"
LANG_APPS_MENU_OPT_4="其他应用程序 (敬请期待)"

# --- menu_ceph.sh ---
LANG_CEPH_MENU_TITLE="Ceph Utils - 集群管理"
LANG_CEPH_MENU_OPT_1="诊断和健康状态 (只读)"
LANG_CEPH_MENU_OPT_2="基准测试 (性能测试)"
LANG_CEPH_MENU_OPT_3="存储池管理 (Pools)"
LANG_CEPH_MENU_OPT_4="优化和调整 (硬件检查)"
LANG_CEPH_MENU_OPT_5="OSD 实用工具 (设备类别)"

# --- menu_watch_dog.sh ---
LANG_WD_MENU_TITLE="看门狗配置"
LANG_WD_MENU_DESC="看门狗: 监控虚拟机并在离线时自动重启"
LANG_WD_MENU_OPT_1="创建计划任务 (每 10 分钟运行一次)"
LANG_WD_MENU_OPT_2="删除计划任务"
LANG_WD_MENU_OPT_3="列出受监控的虚拟机"
LANG_WD_MENU_OPT_4="添加虚拟机到监控列表"
LANG_WD_MENU_OPT_5="从监控列表中移除虚拟机"

# --- menu_webui_sensors.sh ---
LANG_WEBUI_MENU_TITLE="PVE WebUI 中的硬件自定义和传感器"
LANG_WEBUI_MENU_INFO="安全信息:"
LANG_WEBUI_MENU_INFO_1="干净的原始文件保存在:"
LANG_WEBUI_MENU_INFO_2="您可以随时恢复官方 WebUI。"
LANG_WEBUI_MENU_STATUS_ON="[已启用] WebUI 中的硬件传感器处于活动状态"
LANG_WEBUI_MENU_STATUS_OFF="[已禁用] 标准 Proxmox WebUI"
LANG_WEBUI_MENU_STATUS="当前状态:"
LANG_WEBUI_MENU_OPT_1="在 WebUI 中启用温度、频率、功率和磁盘传感器"
LANG_WEBUI_MENU_OPT_2="恢复原始 WebUI (从备份恢复)"
LANG_WEBUI_MENU_OPT_3="重新安装官方 Proxmox 软件包 (完全清理恢复)"

# --- menu_instala_zabbix.sh ---
LANG_ZABBIX_MENU_TITLE="Zabbix Agent - 监控"
LANG_ZABBIX_MENU_STATUS_TITLE="代理状态:"
LANG_ZABBIX_MENU_ACTIVE="服务处于活动状态并正在运行"
LANG_ZABBIX_MENU_STOPPED="服务已停止"
LANG_ZABBIX_MENU_NOT_INSTALLED="未安装 Zabbix Agent"
LANG_ZABBIX_MENU_OPT_1="安装/配置 Zabbix Agent"
LANG_ZABBIX_MENU_OPT_2="卸载 Zabbix Agent"
LANG_ZABBIX_MENU_ALREADY_INSTALLED="(已安装)"
LANG_ZABBIX_MENU_REQ_INSTALL="(需要安装)"

# --- menu_instala_tactical_rmm.sh ---
LANG_TRMM_MENU_TITLE="TacticalRMM 代理管理器"
LANG_TRMM_MENU_STATUS_INSTALLED="已安装 TacticalRMM Agent"
LANG_TRMM_MENU_STATUS_NOT_INSTALLED="未安装 TacticalRMM Agent"
LANG_TRMM_MENU_OPT_1="安装新代理"
LANG_TRMM_MENU_OPT_2="卸载代理 / 清理痕迹"

# --- menu_instala_cloudflared.sh ---
LANG_CF_MENU_TITLE="Cloudflare 反向隧道"
LANG_CF_MENU_STATUS_INSTALLED="已安装 Cloudflared"
LANG_CF_MENU_STATUS_NOT_INSTALLED="未安装 Cloudflared"
LANG_CF_MENU_STATUS_RUNNING="服务处于活动状态并正在运行"
LANG_CF_MENU_STATUS_STOPPED="服务已配置但未运行"
LANG_CF_MENU_STATUS_NOT_CONFIGURED="服务未配置"
LANG_CF_MENU_OPT_1="安装 Cloudflare 隧道"
LANG_CF_MENU_OPT_2="配置服务和客户端密钥"
LANG_CF_MENU_OPT_3="移除隧道"

# --- menu_instala_script.sh ---
LANG_AUTOSTART_MENU_TITLE="脚本自动启动"
LANG_AUTOSTART_MENU_OPT_1="在用户登录时安装脚本"
LANG_AUTOSTART_MENU_OPT_2="在用户登录时卸载脚本"

# --- vm_disk_passthrough.sh ---
LANG_PASSTHROUGH_MENU_TITLE="物理磁盘直通向导"
LANG_PASSTHROUGH_MENU_DESC_1="此向导允许将物理 HDD/SSD (通过 USB 或 SATA)"
LANG_PASSTHROUGH_MENU_DESC_2="作为块设备直接连接到虚拟机。"
LANG_PASSTHROUGH_MENU_DESC_3="➜ 非常适合 P2V、使用 Clonezilla 或 TrueNAS 进行克隆。"
LANG_PASSTHROUGH_MENU_OPT_1="将物理 HDD/SSD 附加到虚拟机"
LANG_PASSTHROUGH_MENU_OPT_2="从虚拟机分离 (移除) 物理磁盘"

# --- vm_config_checker.sh ---
LANG_CONFIG_CHECKER_MENU_TITLE="AI 虚拟机/容器 审计员"
LANG_CONFIG_CHECKER_MENU_OPT_1="检查所有虚拟机和容器"
LANG_CONFIG_CHECKER_MENU_OPT_2="检查特定的虚拟机/容器"
LANG_CONFIG_CHECKER_MENU_OPT_3="📨 通过 Telegram 发送所有的报告"
LANG_CONFIG_CHECKER_MENU_OPT_4="📨 通过 Telegram 发送一个虚拟机/容器的报告"

# --- destranca_desliga.sh ---
LANG_UNLOCK_MENU_TITLE="解锁、关闭和重启虚拟机"
LANG_UNLOCK_MENU_OPT_1="解锁虚拟机"
LANG_UNLOCK_MENU_OPT_2="解锁并关闭虚拟机"
LANG_UNLOCK_MENU_OPT_3="解锁、关闭并重启虚拟机"

# --- menu_upgrade_pbs.sh ---
LANG_PBS_UPGRADE_TITLE="Proxmox PBS 版本升级"
LANG_PBS_UPGRADE_WARN="在执行任何升级之前，请务必进行备份！"
LANG_PBS_UPGRADE_SELECT="选择目标版本："
LANG_PBS_UPGRADE_OPT_1="从 1.x 版本升级到 2.x"

# --- menu_update_pbs.sh ---
LANG_PBS_UPDATE_TITLE="系统更新、安装和升级"
LANG_PBS_UPDATE_OPT_1="版本升级"
LANG_PBS_UPDATE_OPT_2="系统和常用应用程序更新"

# --- menu_disco_pbs.sh ---
LANG_PBS_DISK_TITLE="磁盘工具 (PBS)"
LANG_PBS_DISK_OPT_1="配置磁盘并创建 PBS 数据存储"

# --- menu_telegram.sh ---
LANG_TELEGRAM_MENU_TITLE="Telegram 管理"
LANG_TELEGRAM_MENU_STATUS_TITLE="状态："
LANG_TELEGRAM_MENU_STATUS_ACTIVE="处于活动状态并正在运行"
LANG_TELEGRAM_MENU_STATUS_INACTIVE="不活动或出错"
LANG_TELEGRAM_MENU_STATUS_UNINSTALLED="未安装"
LANG_TELEGRAM_MENU_OPT_1_INSTALL="安装并配置 Bot"
LANG_TELEGRAM_MENU_OPT_1_RECONFIG="重新配置 Bot"
LANG_TELEGRAM_MENU_OPT_2="卸载 Bot"
LANG_TELEGRAM_MENU_OPT_3="重新启动服务"
LANG_TELEGRAM_MENU_OPT_4="查看 Bot 日志"
LANG_TELEGRAM_MENU_OPT_5="更新 Bot"
LANG_TELEGRAM_MENU_OPT_5_DESC="(保留凭据)"

# --- menu_extras_sistema.sh ---
LANG_EXTRAS_SYS_MENU_TITLE="系统、主机和 Watchdog 调整"
LANG_EXTRAS_SYS_MENU_OPT_1="🔥 热监控与硬件保护"
LANG_EXTRAS_SYS_MENU_OPT_2="配置 SWAP (swappiness)"
LANG_EXTRAS_SYS_MENU_OPT_3="主机性能信息"
LANG_EXTRAS_SYS_MENU_OPT_4="在 shell 启动时安装/卸载脚本"
LANG_EXTRAS_SYS_MENU_OPT_5="虚拟机 Watchdog 配置 (通过 Ping 自动重启)"
# --- menu_upgrade_pbs.sh ---
LANG_PBS_UPGRADE_TITLE="Proxmox PBS 版本升级"
LANG_PBS_UPGRADE_WARN="在执行任何升级之前，请务必进行备份！"
LANG_PBS_UPGRADE_SELECT="选择目标版本："
LANG_PBS_UPGRADE_OPT_1="从 1.x 版本升级到 2.x"

# --- menu_update_pbs.sh ---
LANG_PBS_UPDATE_TITLE="系统更新、安装和升级"
LANG_PBS_UPDATE_OPT_1="版本升级"
LANG_PBS_UPDATE_OPT_2="系统和常用应用程序更新"

# --- menu_disco_pbs.sh ---
LANG_PBS_DISK_TITLE="磁盘工具 (PBS)"
LANG_PBS_DISK_OPT_1="配置磁盘并创建 PBS 数据存储"
