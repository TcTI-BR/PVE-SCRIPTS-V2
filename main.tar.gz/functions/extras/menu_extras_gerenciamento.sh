#!/bin/bash

# Submenu de Central de Gerenciamento e Mensageria (Extras)
# Autor: TcTI-BR

extras_gerenciamento_menu(){
    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}"
    echo -e "╔═════════════════════════════════════════════════════════════════════╗"
    ui_print_header_line "" "" 69
    ui_print_header_line "📱 Central de Gerenciamento e Notificações" "${COLOR_WHITE}" 69
    ui_print_header_line "" "" 69
    echo -e "╚═════════════════════════════════════════════════════════════════════╝"
    echo -e "${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_BOLD}  ${LANG_EXTRAS_GER_SEL:-Selecione a opção desejada:}${COLOR_RESET}"
    echo ""
    echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}1${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}🤖 Telegram${COLOR_RESET}                                              ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}       ${COLOR_GRAY}Bot interativo, controle de VMs e alertas${COLOR_RESET}               ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}2${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}💬 WhatsApp${COLOR_RESET} ${COLOR_GRAY}(Em breve)${COLOR_RESET}                                   ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}       ${COLOR_GRAY}Notificações e comandos via API do WhatsApp${COLOR_RESET}             ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}3${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}🔄 Configuração de Atualização Automática do Script${COLOR_RESET}        ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}       ${COLOR_GRAY}Ativar ou desativar busca de atualizações no GitHub${COLOR_RESET}      ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_RED}0${COLOR_RESET} ${COLOR_RED}➜${COLOR_RESET}  ${COLOR_WHITE}Voltar ao menu de Extras${COLOR_RESET}                                ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_YELLOW}  Digite sua opção ${COLOR_GRAY}(ou pressione ENTER para sair)${COLOR_YELLOW}: ${COLOR_RESET}"
    read -rsn1 opt
    while [ "$opt" != '' ]
    do
        if [[ $opt = "" ]]; then
             exit;
        else
            case $opt in
                1) telegram_hub_menu
                   extras_gerenciamento_menu
                   ;;
                2) clear
                   echo -e "${COLOR_YELLOW}💬 Integração com WhatsApp em desenvolvimento!${COLOR_RESET}"
                   sleep 2
                   extras_gerenciamento_menu
                   ;;
                3) extras_update_config_menu
                   extras_gerenciamento_menu
                   ;;
                0) clear;
                   extras_menu
                   ;;
                *) clear;
                   extras_menu
                   ;;
            esac
        fi
    done
}

extras_update_config_menu() {
    local no_update_flag="/TcTI/SCRIPTS/.no_auto_update"
    while true; do
        clear
        echo -e "${COLOR_CYAN}${COLOR_BOLD}"
        echo -e "╔═════════════════════════════════════════════════════════════════════╗"
        ui_print_header_line "" "" 69
        ui_print_header_line "🔄 Configuração de Atualização Automática do Script" "${COLOR_WHITE}" 69
        ui_print_header_line "" "" 69
        echo -e "╚═════════════════════════════════════════════════════════════════════╝"
        echo -e "${COLOR_RESET}"
        echo ""

        if [ -f "$no_update_flag" ] || [ -f "$SCRIPT_DIR/.no_auto_update" ]; then
            echo -e "  ${COLOR_WHITE}Status Atual: ${COLOR_RED}${SYMBOL_ERROR} DESATIVADO (Versão Fixa Local)${COLOR_RESET}"
            echo -e "  ${COLOR_GRAY}O script NÃO buscará atualizações no GitHub ao iniciar.${COLOR_RESET}"
        else
            echo -e "  ${COLOR_WHITE}Status Atual: ${COLOR_GREEN}${SYMBOL_CHECK} ATIVADO (Padrão)${COLOR_RESET}"
            echo -e "  ${COLOR_GRAY}O script busca e aplica atualizações do GitHub a cada execução.${COLOR_RESET}"
        fi
        echo ""
        echo -e "${COLOR_BOLD}  ${LANG_EXTRAS_GER_SEL:-Selecione a opção desejada:}${COLOR_RESET}"
        echo ""
        echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}1${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_RED}Desativar Atualização Automática${COLOR_RESET}                       ${COLOR_CYAN}│${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}│${COLOR_RESET}       ${COLOR_GRAY}Bloqueia busca automática de novas versões no GitHub${COLOR_RESET}   ${COLOR_CYAN}│${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}2${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_GREEN}Ativar Atualização Automática${COLOR_RESET}                           ${COLOR_CYAN}│${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}│${COLOR_RESET}       ${COLOR_GRAY}Restaura sincronização automática (Padrão)${COLOR_RESET}             ${COLOR_CYAN}│${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                              ${COLOR_CYAN}│${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_RED}0${COLOR_RESET} ${COLOR_RED}➜${COLOR_RESET}  ${COLOR_WHITE}Voltar ao menu anterior${COLOR_RESET}                                 ${COLOR_CYAN}│${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
        echo ""
        echo -e "${COLOR_YELLOW}  Digite sua opção ${COLOR_GRAY}(ou pressione ENTER para sair)${COLOR_YELLOW}: ${COLOR_RESET}"
        read -rsn1 opt

        case "$opt" in
            1)
                mkdir -p /TcTI/SCRIPTS
                touch "$no_update_flag" 2>/dev/null
                touch "$SCRIPT_DIR/.no_auto_update" 2>/dev/null
                echo -e "\n${COLOR_RED}✓ ${LANG_EXTRAS_GER_UPD_OFF:-Atualizações automáticas DESATIVADAS com sucesso.}${COLOR_RESET}"
                sleep 2
                ;;
            2)
                rm -f "$no_update_flag" 2>/dev/null
                rm -f "$SCRIPT_DIR/.no_auto_update" 2>/dev/null
                echo -e "\n${COLOR_GREEN}✓ ${LANG_EXTRAS_GER_UPD_ON:-Atualizações automáticas ATIVADAS com sucesso.}${COLOR_RESET}"
                sleep 2
                ;;
            0|"")
                clear
                return 0
                ;;
            *)
                ;;
        esac
    done
}
