#!/bin/bash

# Submenu de Central de Gerenciamento e Mensageria (Extras)
# Autor: TcTI-BR

extras_gerenciamento_menu(){
    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}"
    echo -e "╔═════════════════════════════════════════════════════════════════════╗"
    ui_print_header_line "" "" 69
    ui_print_header_line "${LANG_EXT_GER_TITLE:-📱 Central de Gerenciamento e Notificações}" "${COLOR_WHITE}" 69
    ui_print_header_line "" "" 69
    echo -e "╚═════════════════════════════════════════════════════════════════════╝"
    echo -e "${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_BOLD}  ${LANG_EXTRAS_GER_SEL:-Selecione a opção desejada:}${COLOR_RESET}"
    echo ""
    echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    ui_print_menu_item "1" "${LANG_EXT_GER_OPT1:-Configuração do Telegram Bot}"
    ui_print_menu_desc "${LANG_EXT_GER_DESC1:-Bot interativo, controle de VMs e alertas}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    ui_print_menu_item "2" "${LANG_EXT_GER_OPT2:-Integração com WhatsApp}"
    ui_print_menu_desc "${LANG_EXT_GER_DESC2:-Notificações e comandos via API do WhatsApp}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    ui_print_menu_item "3" "${LANG_EXT_GER_OPT3:-Atualização Automática do Script}"
    ui_print_menu_desc "${LANG_EXT_GER_DESC3:-Ativar ou desativar busca de atualizações no GitHub}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    ui_print_menu_item "0" "${LANG_VM_OP_OPT_0:-Voltar}" "${COLOR_RED}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_YELLOW}  ${LANG_EXTRAS_TYPE_OPT:-Digite sua opção} ${COLOR_GRAY}${LANG_EXTRAS_OR_EXIT:-(ou pressione ENTER para sair)}${COLOR_YELLOW}: ${COLOR_RESET}"
    read -rsn1 opt
    while [ "$opt" != '' ]
    do
        if [[ $opt = "" ]]; then
             exit;
        else
            case $opt in
                1) telegram_hub_menu
                   extras_gerenciamento_menu
                   ;;
                2) clear
echo -e  "${LANG_AUTO_MENU_EXTRAS_GER_94:-${COLOR_YELLOW}💬 Integração com WhatsApp em desenvolvimento!${COLOR_RESET}}"
                   sleep 2
                   extras_gerenciamento_menu
                   ;;
                3) extras_update_config_menu
                   extras_gerenciamento_menu
                   ;;
                0) clear;
                   extras_menu
                   ;;
                *) clear;
                   extras_menu
                   ;;
            esac
        fi
    done
}

extras_update_config_menu() {
    local no_update_flag="/TcTI/SCRIPTS/.no_auto_update"
    while true; do
        clear
        echo -e "${COLOR_CYAN}${COLOR_BOLD}"
        echo -e "╔═════════════════════════════════════════════════════════════════════╗"
        ui_print_header_line "" "" 69
        ui_print_header_line "${LANG_EXT_UPD_TITLE:-🔄 Configuração de Atualização Automática do Script}" "${COLOR_WHITE}" 69
        ui_print_header_line "" "" 69
        echo -e "╚═════════════════════════════════════════════════════════════════════╝"
        echo -e "${COLOR_RESET}"
        echo ""

        if [ -f "$no_update_flag" ] || [ -f "$SCRIPT_DIR/.no_auto_update" ]; then
            echo -e "  ${COLOR_WHITE}${LANG_EXT_UPD_STATUS_LBL:-Status Atual:} ${COLOR_RED}${SYMBOL_ERROR} ${LANG_EXT_UPD_ST_OFF:-DESATIVADO (Versão Fixa Local)}${COLOR_RESET}"
            echo -e "  ${COLOR_GRAY}${LANG_EXT_UPD_MSG_OFF:-O script NÃO buscará atualizações no GitHub ao iniciar.}${COLOR_RESET}"
        else
            echo -e "  ${COLOR_WHITE}${LANG_EXT_UPD_STATUS_LBL:-Status Atual:} ${COLOR_GREEN}${SYMBOL_CHECK} ${LANG_EXT_UPD_ST_ON:-ATIVADO (Padrão)}${COLOR_RESET}"
            echo -e "  ${COLOR_GRAY}${LANG_EXT_UPD_MSG_ON:-O script busca e aplica atualizações do GitHub a cada execução.}${COLOR_RESET}"
        fi
        echo ""
        echo -e "${COLOR_BOLD}  ${LANG_EXTRAS_GER_SEL:-Selecione a opção desejada:}${COLOR_RESET}"
        echo ""
        echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
        ui_print_menu_item "1" "${LANG_EXT_UPD_OPT1:-Desativar Atualização Automática}" "${COLOR_RED}"
        ui_print_menu_desc "${LANG_EXT_UPD_DESC1:-Bloqueia busca automática de novas versões no GitHub}"
        echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
        ui_print_menu_item "2" "${LANG_EXT_UPD_OPT2:-Ativar Atualização Automática}" "${COLOR_GREEN}"
        ui_print_menu_desc "${LANG_EXT_UPD_DESC2:-Restaura sincronização automática (Padrão)}"
        echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
        ui_print_menu_item "0" "${LANG_VM_OP_OPT_0:-Voltar}" "${COLOR_RED}"
        echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
        echo ""
        echo -e "${COLOR_YELLOW}  ${LANG_EXTRAS_TYPE_OPT:-Digite sua opção} ${COLOR_GRAY}${LANG_EXTRAS_OR_EXIT:-(ou pressione ENTER para sair)}${COLOR_YELLOW}: ${COLOR_RESET}"
        read -rsn1 opt

        case "$opt" in
            1)
                mkdir -p /TcTI/SCRIPTS
                touch "$no_update_flag" 2>/dev/null
                touch "$SCRIPT_DIR/.no_auto_update" 2>/dev/null
                echo -e "\n${COLOR_RED}✓ ${LANG_EXTRAS_GER_UPD_OFF:-Atualizações automáticas DESATIVADAS com sucesso.}${COLOR_RESET}"
                sleep 2
                ;;
            2)
                rm -f "$no_update_flag" 2>/dev/null
                rm -f "$SCRIPT_DIR/.no_auto_update" 2>/dev/null
                echo -e "\n${COLOR_GREEN}✓ ${LANG_EXTRAS_GER_UPD_ON:-Atualizações automáticas ATIVADAS com sucesso.}${COLOR_RESET}"
                sleep 2
                ;;
            0|"")
                clear
                return 0
                ;;
            *)
                ;;
        esac
    done
}
