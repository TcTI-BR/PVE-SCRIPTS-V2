#!/bin/bash

# Submenu de Configurações de Rede (Extras)
# Autor: TcTI-BR

extras_rede_menu(){
    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}"
    echo -e "╔═════════════════════════════════════════════════════════════════════╗"
    ui_print_header_line "" "" 69
    ui_print_header_line "🌐 Configurações de Rede" "${COLOR_WHITE}" 69
    ui_print_header_line "" "" 69
    echo -e "╚═════════════════════════════════════════════════════════════════════╝"
    echo -e "${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_BOLD}  ${LANG_EXTRAS_SEL_OPT:-Selecione uma opção:}${COLOR_RESET}"
    echo ""
    echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    ui_print_menu_item "1" "${LANG_EXT_NET_OPT1:-Reiniciar Serviço de Rede}"
    ui_print_menu_item "2" "${LANG_EXT_NET_OPT2:-Exibir Interfaces de Rede (ip a)}"
    ui_print_menu_item "3" "${LANG_EXT_NET_OPT3:-Testar conectividade (ping 8.8.8.8)}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    ui_print_menu_item "0" "${LANG_VM_OP_OPT_0:-Voltar}" "${COLOR_RED}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_YELLOW}  ${LANG_EXTRAS_TYPE_OPT:-Digite sua opção} ${COLOR_GRAY}${LANG_EXTRAS_OR_EXIT:-(ou pressione ENTER para sair)}${COLOR_YELLOW}: ${COLOR_RESET}"
    read -rsn1 opt
    while [ "$opt" != '' ]
    do
        if [[ $opt = "" ]]; then
             exit;
        else
            case $opt in
                1) clear
                nano /etc/network/interfaces
read -p  "${LANG_AUTO_MENU_EXTRAS_RED_139:-Pressione uma tecla para continuar...}"
                clear
                extras_rede_menu
                    ;;
                2) clear;
                nano /etc/resolv.conf
read -p  "${LANG_AUTO_MENU_EXTRAS_RED_140:-Pressione uma tecla para continuar...}"
                clear     
                extras_rede_menu
                    ;;
                3) clear;
                nano /etc/hosts
read -p  "${LANG_AUTO_MENU_EXTRAS_RED_141:-Pressione uma tecla para continuar...}"
                clear
                extras_rede_menu
                    ;;
                0) clear;
                extras_menu;
                    ;;
                *) clear;
                extras_menu;
                    ;;
            esac
        fi
    done
}
