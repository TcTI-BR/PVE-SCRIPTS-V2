#!/bin/bash

# Submenu de Diagnósticos e Ferramentas de Disco (Extras)
# Autor: TcTI-BR

extras_disco_menu() {
    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}"
    echo -e "╔═════════════════════════════════════════════════════════════════════╗"
    ui_print_header_line "" "" 69
    ui_print_header_line "💾  ${LANG_EXT_DISC_TITLE:-Ferramentas e Diagnósticos de Disco}" "${COLOR_WHITE}" 69
    ui_print_header_line "" "" 69
    echo -e "╚═════════════════════════════════════════════════════════════════════╝"
    echo -e "${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_BOLD}  ${LANG_EXTRAS_SEL_OPT:-Selecione uma opção:}${COLOR_RESET}"
    echo ""
    echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    ui_print_menu_item "1" "${LANG_EXT_DISC_OPT1:-Teste de velocidade dos discos}"
    ui_print_menu_item "2" "${LANG_EXT_DISC_OPT2:-Verifica setores defeituosos (Badblocks)}"
    ui_print_menu_item "3" "${LANG_EXT_DISC_OPT3:-Verifica a saúde do disco (SMART)}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    ui_print_menu_item "0" "${LANG_VM_OP_OPT_0:-Voltar}" "${COLOR_RED}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_YELLOW}  ${LANG_EXTRAS_TYPE_OPT:-Digite sua opção} ${COLOR_GRAY}${LANG_EXTRAS_OR_EXIT:-(ou pressione ENTER para sair)}${COLOR_YELLOW}: ${COLOR_RESET}"
    read -rsn1 opt
    while [ "$opt" != '' ]
    do
        if [[ $opt = "" ]]; then
            exit;
        else
            case $opt in
                1) run_disk_speed_test ;;
                2) run_disk_badblocks ;;
                3) run_disk_smart ;;
                0) clear; extras_menu ;;
                *) clear; extras_menu ;;
            esac
        fi
    done
    extras_disco_menu
}
