#!/bin/bash

# Menu de Recursos e Serviços Telegram
# Autor: TcTI-BR (Gerado via IA)

NOTIF_CONFIG_FILE="/TcTI/SCRIPTS/telegram/.env_notificacoes"

telegram_notificacoes_menu() {
    while true; do
        clear
        echo -e "${COLOR_CYAN}${COLOR_BOLD}"
        echo -e "╔═════════════════════════════════════════════════════════════════════╗"
        echo -e "║                                                                     ║"
        echo -e "║                   📣 Notificações via Telegram                       ║"
        echo -e "║                                                                     ║"
        echo -e "╚═════════════════════════════════════════════════════════════════════╝"
        echo -e "${COLOR_RESET}"
        echo ""

        if [ -f "$NOTIF_CONFIG_FILE" ]; then
            source "$NOTIF_CONFIG_FILE" 2>/dev/null
            echo -e "  ${COLOR_WHITE}Status: ${COLOR_GREEN}${SYMBOL_CHECK} Configurado${COLOR_RESET}"
            echo -e "  ${COLOR_WHITE}Servidor: ${COLOR_YELLOW}${NOTIF_SERVER_NAME}${COLOR_RESET} | ${COLOR_WHITE}Chat ID: ${COLOR_CYAN}${NOTIF_CHAT_ID}${COLOR_RESET}"
        else
            echo -e "  ${COLOR_WHITE}Status: ${COLOR_GRAY}Não configurado${COLOR_RESET}"
            echo -e "  ${COLOR_YELLOW}  Cadastre um Bot de Notificações para receber alertas do sistema.${COLOR_RESET}"
        fi
        echo ""

        echo -e "${COLOR_BOLD}  Selecione a opção desejada:${COLOR_RESET}"
        echo ""
        echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}1${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}Cadastrar / Reconfigurar Bot de Notificações${COLOR_RESET}            ${COLOR_CYAN}│${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}2${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}Testar Envio de Mensagem de Notificação${COLOR_RESET}                 ${COLOR_CYAN}│${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}3${COLOR_RESET} ${COLOR_RED}➜${COLOR_RESET}  ${COLOR_RED}Deletar Configuração de Notificações${COLOR_RESET}                    ${COLOR_CYAN}│${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_RED}0${COLOR_RESET} ${COLOR_RED}➜${COLOR_RESET}  ${COLOR_WHITE}Voltar ao menu anterior${COLOR_RESET}                                 ${COLOR_CYAN}│${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
        echo ""
        echo -e "${COLOR_YELLOW}  Digite sua opção ${COLOR_GRAY}(ou pressione ENTER para sair)${COLOR_YELLOW}: ${COLOR_RESET}"
        read -rsn1 opt

        case "$opt" in
            1)
                clear
                echo -e "${COLOR_CYAN}${COLOR_BOLD}Cadastrar Bot de Notificações Telegram${COLOR_RESET}\n"
                read -p "Nome deste Servidor (Ex: SRV-PROD-01): " srv_n
                read -p "Token do Bot de Notificações: " b_tok
                read -p "Chat ID (ID do Telegram): " c_id

                if [[ -z "$srv_n" || -z "$b_tok" || -z "$c_id" ]]; then
                    echo -e "\n${COLOR_RED}Todos os campos são obrigatórios!${COLOR_RESET}"
                    sleep 2
                else
                    mkdir -p /TcTI/SCRIPTS/telegram
                    cat > "$NOTIF_CONFIG_FILE" <<EOF
NOTIF_SERVER_NAME="$srv_n"
NOTIF_BOT_TOKEN="$b_tok"
NOTIF_CHAT_ID="$c_id"
EOF
                    chmod 600 "$NOTIF_CONFIG_FILE"
                    echo -e "\n${COLOR_GREEN}✓ Configuração de Notificações salva com sucesso!${COLOR_RESET}"
                    sleep 2
                fi
                ;;
            2)
                clear
                if [ ! -f "$NOTIF_CONFIG_FILE" ]; then
                    echo -e "${COLOR_RED}Cadastre um bot primeiro (Opção 1).${COLOR_RESET}"
                    sleep 2
                else
                    source "$NOTIF_CONFIG_FILE"
                    echo -e "${COLOR_YELLOW}Enviando notificação de teste para o Telegram...${COLOR_RESET}"
                    msg="📣 *TESTE DE NOTIFICAÇÃO - TcTI PVE*%0AServidor: *${NOTIF_SERVER_NAME}*%0AStatus: O sistema de notificações via Telegram está operante!"
                    res_code=$(curl -s -o /dev/null -w "%{http_code}" -X POST "https://api.telegram.org/bot${NOTIF_BOT_TOKEN}/sendMessage" \
                        -d "chat_id=${NOTIF_CHAT_ID}&text=${msg}&parse_mode=Markdown")

                    if [ "$res_code" = "200" ]; then
                        echo -e "${COLOR_GREEN}✓ Notificação enviada com sucesso no Telegram! (HTTP 200)${COLOR_RESET}"
                    else
                        echo -e "${COLOR_RED}✗ Falha ao enviar notificação (HTTP $res_code). Verifique Token e Chat ID.${COLOR_RESET}"
                    fi
                    echo ""
                    read -p "Pressione ENTER para continuar..."
                fi
                ;;
            3)
                clear
                if [ -f "$NOTIF_CONFIG_FILE" ]; then
                    read -p "Tem certeza que deseja remover as configurações de notificações? (s/N): " conf
                    if [[ $conf =~ ^[Ss]$ ]]; then
                        rm -f "$NOTIF_CONFIG_FILE"
                        echo -e "${COLOR_GREEN}✓ Configurações de notificações removidas.${COLOR_RESET}"
                        sleep 2
                    fi
                else
                    echo -e "${COLOR_YELLOW}Nenhuma configuração salva para remover.${COLOR_RESET}"
                    sleep 2
                fi
                ;;
            0|"")
                clear
                return 0
                ;;
            *)
                ;;
        esac
    done
}

telegram_hub_menu() {
    while true; do
        clear
        echo -e "${COLOR_CYAN}${COLOR_BOLD}"
        echo -e "╔═════════════════════════════════════════════════════════════════════╗"
        echo -e "║                                                                     ║"
        echo -e "║                    🤖 Recursos e Serviços Telegram                   ║"
        echo -e "║                                                                     ║"
        echo -e "╚═════════════════════════════════════════════════════════════════════╝"
        echo -e "${COLOR_RESET}"
        echo ""
        if [ -f "/etc/systemd/system/pve-telegram-bot.service" ]; then
            status=$(systemctl is-active pve-telegram-bot 2>/dev/null)
            if [ "$status" == "active" ]; then
                echo -e "  ${COLOR_WHITE}Status Bot Interativo: ${COLOR_GREEN}${SYMBOL_CHECK} Ativo e rodando${COLOR_RESET}"
            else
                echo -e "  ${COLOR_WHITE}Status Bot Interativo: ${COLOR_RED}${SYMBOL_ERROR} Inativo ou com erro${COLOR_RESET}"
            fi
        else
            echo -e "  ${COLOR_WHITE}Status Bot Interativo: ${COLOR_GRAY}Não instalado${COLOR_RESET}"
        fi
        echo ""
        echo -e "${COLOR_BOLD}  Selecione a opção desejada:${COLOR_RESET}"
        echo ""
        echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}1${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}🤖 Gerenciamento via Telegram${COLOR_RESET}                            ${COLOR_CYAN}│${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}│${COLOR_RESET}       ${COLOR_GRAY}Bot interativo, controle de VMs/CTs, logs e status${COLOR_RESET}      ${COLOR_CYAN}│${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}2${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}📣 Notificações via Telegram${COLOR_RESET}                             ${COLOR_CYAN}│${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}│${COLOR_RESET}       ${COLOR_GRAY}Bot passivo de alertas, canal exclusivo de notificações${COLOR_RESET} ${COLOR_CYAN}│${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_RED}0${COLOR_RESET} ${COLOR_RED}➜${COLOR_RESET}  ${COLOR_WHITE}Voltar à Central de Gerenciamento${COLOR_RESET}                       ${COLOR_CYAN}│${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
        echo ""
        echo -e "${COLOR_YELLOW}  Digite sua opção ${COLOR_GRAY}(ou pressione ENTER para sair)${COLOR_YELLOW}: ${COLOR_RESET}"
        read -rsn1 opt

        case "$opt" in
            1) telegram_menu ;;
            2) telegram_notificacoes_menu ;;
            0|"") clear; return 0 ;;
            *) ;;
        esac
    done
}

telegram_menu() {
    while true; do
        clear
        echo -e "${COLOR_CYAN}${COLOR_BOLD}"
        echo -e "╔═════════════════════════════════════════════════════════════════════╗"
        echo -e "║                    🤖 ${LANG_TELEGRAM_MENU_TITLE:-Gerenciamento via Telegram}                     ║"
        echo -e "╚═════════════════════════════════════════════════════════════════════╝"
        echo -e "${COLOR_RESET}"
        
        local is_installed=0
        if [ -f "/etc/systemd/system/pve-telegram-bot.service" ]; then
            is_installed=1
            status=$(systemctl is-active pve-telegram-bot 2>/dev/null)
            if [ "$status" == "active" ]; then
                echo -e "  ${COLOR_WHITE}${LANG_TELEGRAM_MENU_STATUS_TITLE:-Status:} ${COLOR_GREEN}${SYMBOL_CHECK} ${LANG_TELEGRAM_MENU_STATUS_ACTIVE:-Ativo e rodando}${COLOR_RESET}"
            else
                echo -e "  ${COLOR_WHITE}${LANG_TELEGRAM_MENU_STATUS_TITLE:-Status:} ${COLOR_RED}${SYMBOL_ERROR} ${LANG_TELEGRAM_MENU_STATUS_INACTIVE:-Inativo ou com erro}${COLOR_RESET}"
            fi
        else
            echo -e "  ${COLOR_WHITE}${LANG_TELEGRAM_MENU_STATUS_TITLE:-Status:} ${COLOR_GRAY}${LANG_TELEGRAM_MENU_STATUS_UNINSTALLED:-Não instalado}${COLOR_RESET}"
        fi
        echo ""
        
        echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
        
        if [ $is_installed -eq 0 ]; then
            ui_print_menu_item "1" "${LANG_TELEGRAM_MENU_OPT_1_INSTALL}" "${COLOR_YELLOW}"
        else
            ui_print_menu_item "1" "${LANG_TELEGRAM_MENU_OPT_1_RECONFIG}" "${COLOR_YELLOW}"
            ui_print_menu_item "2" "${LANG_TELEGRAM_MENU_OPT_2}" "${COLOR_YELLOW}"
            ui_print_menu_item "3" "${LANG_TELEGRAM_MENU_OPT_3}" "${COLOR_YELLOW}"
            ui_print_menu_item "4" "${LANG_TELEGRAM_MENU_OPT_4}" "${COLOR_YELLOW}"
            ui_print_menu_item "5" "${LANG_TELEGRAM_MENU_OPT_5} ${LANG_TELEGRAM_MENU_OPT_5_DESC:-(manter credenciais)}" "${COLOR_YELLOW}"
        fi
        
        echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
        
        ui_print_menu_item "0" "${LANG_VM_OP_OPT_0:-Voltar}" "${COLOR_RED}"
        
        echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
        echo ""
        echo -e "${COLOR_YELLOW}  ${LANG_TYPE_OPT:-Digite sua opção} ${COLOR_GRAY}${LANG_PRESS_ENTER:-(ou pressione ENTER para sair)}${COLOR_YELLOW}: ${COLOR_RESET}"
        read -rsn1 opt

        case "$opt" in
            1) install_telegram_bot ;;
            2) if [ $is_installed -eq 1 ]; then uninstall_telegram_bot; else return 0; fi ;;
            3) if [ $is_installed -eq 1 ]; then restart_telegram_bot; else return 0; fi ;;
            4) if [ $is_installed -eq 1 ]; then logs_telegram_bot; else return 0; fi ;;
            5) if [ $is_installed -eq 1 ]; then update_telegram_bot; else return 0; fi ;;
            0|"") clear; return 0 ;;
            *) ;;
        esac
    done
}

install_telegram_bot() {
    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}╔═══════════════════════════════════════════════════════════════╗${COLOR_RESET}"
    echo -e "${COLOR_CYAN}${COLOR_BOLD}║                Instalação do Bot Telegram                     ║${COLOR_RESET}"
    echo -e "${COLOR_CYAN}${COLOR_BOLD}╚═══════════════════════════════════════════════════════════════╝${COLOR_RESET}"
    echo ""
    
    echo -e "${COLOR_WHITE}Este script criará um bot seguro que responde apenas a você.${COLOR_RESET}"
    echo -e "${COLOR_GRAY}1. Crie o bot no @BotFather no Telegram para pegar o Token${COLOR_RESET}"
    echo -e "${COLOR_GRAY}2. Pegue seu ID de usuário (ex: no @userinfobot)${COLOR_RESET}"
    echo ""
    
    read -p "$(echo -e ${COLOR_YELLOW}"Qual o nome deste servidor? (Ex: SRV-SP-01): "${COLOR_RESET})" server_name
    read -p "$(echo -e ${COLOR_YELLOW}"Cole o Token do Bot: "${COLOR_RESET})" bot_token
    read -p "$(echo -e ${COLOR_YELLOW}"Cole o seu Chat ID: "${COLOR_RESET})" chat_id
    
    if [[ -z "$server_name" || -z "$bot_token" || -z "$chat_id" ]]; then
        echo -e "\n${COLOR_RED}${SYMBOL_ERROR} Todos os campos são obrigatórios! Cancelando.${COLOR_RESET}"
        sleep 2
        return
    fi
    
    echo -e "\n${COLOR_BLUE}${SYMBOL_LOADING} Configurando ambiente seguro...${COLOR_RESET}"
    mkdir -p /TcTI/SCRIPTS/telegram
    chmod 700 /TcTI/SCRIPTS/telegram
    
    json_data="{\"token\":\"$bot_token\",\"chat_id\":\"$chat_id\",\"server_name\":\"$server_name\"}"
    echo -n "$json_data" | base64 > /TcTI/SCRIPTS/telegram/.env
    chmod 600 /TcTI/SCRIPTS/telegram/.env
    
    echo -e "${COLOR_BLUE}${SYMBOL_LOADING} Instalando serviço do backend Python...${COLOR_RESET}"
    
    cat << 'PYEOF' > /usr/local/bin/pve-telegram-bot.py
#!/usr/bin/env python3
# PVE Telegram Bot — TcTI-BR
# Menus organizados: VMs, Containers, Status, Storage, Rede, Ações Rápidas

import urllib.request
import urllib.parse
import json
import subprocess
import time
import base64
import sys
import os

CONFIG_FILE = "/TcTI/SCRIPTS/telegram/.env"

# ──────────────────────────────────────────────
# Configuração
# ──────────────────────────────────────────────
def load_config():
    try:
        with open(CONFIG_FILE, 'r') as f:
            encoded = f.read().strip()
            decoded = base64.b64decode(encoded).decode('utf-8')
            config = json.loads(decoded)
            return config['token'], str(config['chat_id']), config['server_name']
    except Exception as e:
        print(f"Erro carregando configuração: {e}")
        sys.exit(1)

TOKEN, ALLOWED_CHAT_ID, SERVER_NAME = load_config()
BASE_URL = f"https://api.telegram.org/bot{TOKEN}/"

# ──────────────────────────────────────────────
# API Telegram
# ──────────────────────────────────────────────
def call_api(method, data=None):
    url = BASE_URL + method
    req = urllib.request.Request(url)
    req.add_header('Content-Type', 'application/json')
    try:
        if data:
            jsondata = json.dumps(data).encode('utf-8')
            response = urllib.request.urlopen(req, data=jsondata, timeout=35)
        else:
            response = urllib.request.urlopen(req, timeout=35)
        return json.loads(response.read().decode('utf-8'))
    except Exception as e:
        print(f"API Error ({method}): {e}")
        return None

def run(cmd, shell=False):
    """Executa comando e retorna stdout como string."""
    try:
        if shell:
            out = subprocess.check_output(cmd, shell=True, stderr=subprocess.DEVNULL)
        else:
            out = subprocess.check_output(cmd, stderr=subprocess.DEVNULL)
        return out.decode('utf-8', errors='replace').strip()
    except Exception:
        return ""

def run_bg(cmd):
    """Executa comando em background sem esperar."""
    try:
        subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception as e:
        print(f"Erro bg: {e}")

# ──────────────────────────────────────────────
# Coleta de dados
# ──────────────────────────────────────────────
def get_vms():
    vms = []
    try:
        out = run(['qm', 'list'])
        for line in out.split('\n')[1:]:
            parts = line.split()
            if len(parts) >= 3:
                vms.append({'id': parts[0], 'name': parts[1], 'status': parts[2], 'type': 'vm'})
    except Exception:
        pass
    return vms

def get_containers():
    cts = []
    try:
        out = run(['pct', 'list'])
        for line in out.split('\n')[1:]:
            parts = line.split()
            if len(parts) >= 3:
                cts.append({'id': parts[0], 'name': parts[2] if len(parts) > 2 else parts[0], 'status': parts[1], 'type': 'ct'})
    except Exception:
        pass
    return cts

def status_icon(status):
    if status in ('running',):
        return '🟢'
    elif status in ('stopped',):
        return '🔴'
    else:
        return '🟡'

def get_host_info():
    uptime = run(['uptime', '-p'])
    free_lines = run(['free', '-m']).split('\n')
    cpu_load = run("top -bn1 | grep 'Cpu(s)' | awk '{print $2+$4}'", shell=True)
    ram_total = ram_used = 0
    for line in free_lines:
        if line.startswith('Mem:'):
            p = line.split()
            ram_total = int(p[1])
            ram_used = int(p[2])
            break
    ram_pct = int(ram_used / ram_total * 100) if ram_total > 0 else 0
    bar = _bar(ram_pct)
    return (
        f"🖥️ *{SERVER_NAME}*\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"⏱ Uptime: `{uptime}`\n"
        f"🔥 CPU: `{cpu_load}%` em uso\n"
        f"💾 RAM: `{ram_used}MB / {ram_total}MB` ({ram_pct}%)\n"
        f"`{bar}`"
    )

def get_temperature():
    # Tenta ipmitool primeiro
    ipmitool = run("which ipmitool", shell=True)
    if ipmitool:
        out = run("ipmitool sdr type Temperature 2>/dev/null | grep -i 'inlet\\|ambient\\|cpu\\|temp' | head -6", shell=True)
        if out:
            lines = []
            for line in out.split('\n'):
                if '|' in line:
                    parts = [p.strip() for p in line.split('|')]
                    name = parts[0]
                    val = parts[4] if len(parts) > 4 else '?'
                    lines.append(f"  `{name}`: {val}")
            if lines:
                return "🌡️ *Temperatura (IPMI)*\n━━━━━━━━━━━━━━━━━━━━━━\n" + "\n".join(lines)

    # Tenta lm-sensors
    sensors_bin = run("which sensors", shell=True)
    if sensors_bin:
        raw = run("sensors 2>/dev/null", shell=True)
        if raw:
            lines = []
            skip = {'tg3', 'e1000'}  # ignora chips de rede
            current_chip = ''
            for line in raw.split('\n'):
                if line and not line.startswith(' ') and ':' not in line:
                    current_chip = line.lower()
                if any(s in current_chip for s in skip):
                    continue
                if '°C' in line and ('Core' in line or 'Package' in line or 'temp' in line.lower()):
                    name = line.split(':')[0].strip()
                    val = line.split(':')[1].strip().split('(')[0].strip() if ':' in line else ''
                    lines.append(f"  `{name}`: {val}")
            if lines:
                return "🌡️ *Temperatura (Sensors)*\n━━━━━━━━━━━━━━━━━━━━━━\n" + "\n".join(lines[:8])

    # Fallback: sysfs
    temps = []
    base = '/sys/class/thermal'
    if os.path.isdir(base):
        for zone in sorted(os.listdir(base)):
            tp = f"{base}/{zone}/temp"
            ty = f"{base}/{zone}/type"
            if os.path.exists(tp):
                try:
                    val = int(open(tp).read().strip()) / 1000
                    typ = open(ty).read().strip() if os.path.exists(ty) else zone
                    temps.append(f"  `{typ}`: {val:.1f}°C")
                except Exception:
                    pass
    if temps:
        return "🌡️ *Temperatura (Sysfs)*\n━━━━━━━━━━━━━━━━━━━━━━\n" + "\n".join(temps[:8])

    return "🌡️ Temperatura\n━━━━━━━━━━━━━━━━━━━━━━\n⚠️ Nenhum sensor disponível.\nInstale: `apt install lm-sensors ipmitool`"

def get_disk_usage():
    out = run("df -h --output=target,pcent,used,size -x tmpfs -x devtmpfs 2>/dev/null | tail -n+2", shell=True)
    lines = ["💽 *Uso de Disco*", "━━━━━━━━━━━━━━━━━━━━━━"]
    for line in out.split('\n'):
        if not line.strip():
            continue
        parts = line.split()
        if len(parts) >= 4:
            mp, pct, used, total = parts[0], parts[1], parts[2], parts[3]
            pct_int = int(pct.replace('%', '')) if '%' in pct else 0
            icon = '🔴' if pct_int >= 90 else '🟡' if pct_int >= 75 else '🟢'
            lines.append(f"{icon} `{mp}` — {used}/{total} ({pct})")
    return "\n".join(lines) if len(lines) > 2 else "💽 Nenhuma partição encontrada."

def get_pve_services():
    services = [
        ('pve-cluster',  '🗃️ PVE Cluster'),
        ('pvedaemon',    '⚙️  PVE Daemon'),
        ('pveproxy',     '🌐 PVE Proxy'),
        ('pvestatd',     '📊 PVE Stats'),
        ('corosync',     '🔗 Corosync'),
        ('pve-firewall', '🛡️  Firewall'),
        ('qmeventd',     '📡 QM Events'),
    ]
    lines = ["🔧 *Serviços Proxmox*", "━━━━━━━━━━━━━━━━━━━━━━"]
    for svc, label in services:
        st = run(['systemctl', 'is-active', svc])
        icon = '🟢' if st == 'active' else '🔴'
        lines.append(f"{icon} {label}: `{st}`")
    return "\n".join(lines)

def get_storage_status():
    out = run(['pvesm', 'status'])
    lines = ["💾 *Status dos Storages*", "━━━━━━━━━━━━━━━━━━━━━━"]
    for line in out.split('\n')[1:]:
        if not line.strip():
            continue
        parts = line.split()
        if len(parts) >= 2:
            name = parts[0]
            status = parts[1]
            icon = '🟢' if status == 'active' else '🔴'
            extra = ''
            if len(parts) >= 6:
                try:
                    total_kb = int(parts[3])
                    used_kb = int(parts[4])
                    total_gb = total_kb / (1024**2)
                    used_gb = used_kb / (1024**2)
                    pct = int(used_kb / total_kb * 100) if total_kb > 0 else 0
                    extra = f" — {used_gb:.1f}/{total_gb:.1f} GB ({pct}%)"
                except Exception:
                    pass
            lines.append(f"{icon} `{name}`{extra}")
    return "\n".join(lines) if len(lines) > 2 else "💾 Nenhum storage encontrado ou pvesm não disponível."

def get_last_backups():
    # Verifica logs de backup do Proxmox
    out = run("grep -r 'backup' /var/log/syslog 2>/dev/null | grep 'TASK OK\\|vzdump' | tail -10", shell=True)
    if not out:
        out = run("journalctl -u vzdump --no-pager -n 10 2>/dev/null | tail -10", shell=True)
    lines = ["📦 *Últimos Backups (Log)*", "━━━━━━━━━━━━━━━━━━━━━━"]
    if out:
        for line in out.split('\n')[:8]:
            if line.strip():
                lines.append(f"`{line[:80]}`")
    else:
        lines.append("Nenhum registro de backup encontrado.")
    return "\n".join(lines)

def get_network_info():
    out = run("ip -o addr show | grep -v '^.*lo ' | awk '{print $2, $4}'", shell=True)
    lines = ["🌐 *Interfaces de Rede*", "━━━━━━━━━━━━━━━━━━━━━━"]
    for line in out.split('\n'):
        if line.strip():
            parts = line.split()
            if len(parts) == 2:
                iface, addr = parts
                lines.append(f"  `{iface}` — `{addr}`")
    return "\n".join(lines) if len(lines) > 2 else "🌐 Nenhuma interface encontrada."

def get_ping_test():
    targets = [
        ('8.8.8.8',       'Google DNS'),
        ('1.1.1.1',       'Cloudflare'),
        ('gateway',       'Gateway'),
    ]
    # Tenta descobrir o gateway
    gw = run("ip route | grep default | awk '{print $3}' | head -1", shell=True)
    if gw:
        targets[2] = (gw, f'Gateway ({gw})')

    lines = ["📡 *Teste de Conectividade*", "━━━━━━━━━━━━━━━━━━━━━━"]
    for host, label in targets:
        result = run(['ping', '-c', '2', '-W', '2', host])
        if 'bytes from' in result or '2 received' in result or '0% packet loss' in result:
            ms_line = [l for l in result.split('\n') if 'avg' in l]
            ms = ms_line[0].split('/')[-3].split('/')[-1] if ms_line else '?'
            lines.append(f"🟢 {label}: `{ms}ms`")
        else:
            lines.append(f"🔴 {label}: sem resposta")
    return "\n".join(lines)

def get_recent_logs():
    out = run("journalctl -p err..emerg --no-pager -n 15 --output=short-iso 2>/dev/null", shell=True)
    lines = ["📜 *Logs Recentes (erros)*", "━━━━━━━━━━━━━━━━━━━━━━"]
    if out:
        for line in out.split('\n')[:12]:
            if line.strip() and not line.startswith('--'):
                lines.append(f"`{line[:90]}`")
    else:
        lines.append("✅ Nenhum erro recente encontrado.")
    return "\n".join(lines)

def _bar(pct, width=12):
    filled = int(width * pct / 100)
    return '█' * filled + '░' * (width - filled) + f' {pct}%'

# ──────────────────────────────────────────────
# Teclados inline
# ──────────────────────────────────────────────
def kb_main():
    return {"inline_keyboard": [
        [{"text": "💻 VMs e Containers",   "callback_data": "menu_vms_ct"}],
        [{"text": "🖥️ Status do Servidor",  "callback_data": "menu_status"}],
        [{"text": "💾 Storage & Backups",   "callback_data": "menu_storage"}],
        [{"text": "🌐 Rede",               "callback_data": "menu_network"}],
        [{"text": "🛠️ Ações Rápidas",      "callback_data": "menu_actions"}],
    ]}

def kb_back_main():
    return {"inline_keyboard": [[{"text": "🏠 Menu Principal", "callback_data": "menu_main"}]]}

def kb_vms_ct():
    return {"inline_keyboard": [
        [{"text": "🖥️ Gerenciar VMs (QEMU)",      "callback_data": "menu_vms"}],
        [{"text": "📦 Gerenciar Containers (LXC)", "callback_data": "menu_cts"}],
        [{"text": "📋 Listar Todas",               "callback_data": "list_all"}],
        [{"text": "🔒 VMs com Lock",               "callback_data": "list_locked"}],
        [{"text": "🏠 Menu Principal",             "callback_data": "menu_main"}],
    ]}

def kb_vms():
    vms = get_vms()
    kb = []
    for vm in vms:
        icon = status_icon(vm['status'])
        kb.append([{"text": f"{icon} {vm['id']} — {vm['name']}", "callback_data": f"vm_{vm['id']}"}])
    kb.append([{"text": "🔙 Voltar", "callback_data": "menu_vms_ct"}])
    return {"inline_keyboard": kb}

def kb_cts():
    cts = get_containers()
    kb = []
    for ct in cts:
        icon = status_icon(ct['status'])
        kb.append([{"text": f"{icon} {ct['id']} — {ct['name']}", "callback_data": f"ct_{ct['id']}"}])
    kb.append([{"text": "🔙 Voltar", "callback_data": "menu_vms_ct"}])
    return {"inline_keyboard": kb}

def kb_vm_actions(vmid):
    return {"inline_keyboard": [
        [{"text": "⚡ Ligar",    "callback_data": f"vm_start_{vmid}"},
         {"text": "🛑 Desligar", "callback_data": f"vm_shutdown_{vmid}"}],
        [{"text": "💀 Forçar",   "callback_data": f"vm_stop_{vmid}"},
         {"text": "🔄 Reiniciar","callback_data": f"vm_reboot_{vmid}"}],
        [{"text": "📊 Status",   "callback_data": f"vm_status_{vmid}"},
         {"text": "⏸️ Pausar",   "callback_data": f"vm_suspend_{vmid}"}],
        [{"text": "🔙 Voltar às VMs", "callback_data": "menu_vms"}],
    ]}

def kb_ct_actions(ctid):
    return {"inline_keyboard": [
        [{"text": "⚡ Ligar",    "callback_data": f"ct_start_{ctid}"},
         {"text": "🛑 Desligar", "callback_data": f"ct_shutdown_{ctid}"}],
        [{"text": "💀 Forçar",   "callback_data": f"ct_stop_{ctid}"},
         {"text": "🔄 Reiniciar","callback_data": f"ct_reboot_{ctid}"}],
        [{"text": "📊 Status",   "callback_data": f"ct_status_{ctid}"}],
        [{"text": "🔙 Voltar aos Containers", "callback_data": "menu_cts"}],
    ]}

def kb_status():
    return {"inline_keyboard": [
        [{"text": "📊 CPU & RAM & Uptime", "callback_data": "st_host"}],
        [{"text": "🌡️ Temperatura",        "callback_data": "st_temp"}],
        [{"text": "💽 Uso de Disco",       "callback_data": "st_disk"}],
        [{"text": "🔧 Serviços Proxmox",   "callback_data": "st_services"}],
        [{"text": "🏠 Menu Principal",     "callback_data": "menu_main"}],
    ]}

def kb_storage():
    return {"inline_keyboard": [
        [{"text": "💾 Status dos Storages", "callback_data": "sg_status"}],
        [{"text": "📦 Últimos Backups",     "callback_data": "sg_backups"}],
        [{"text": "🏠 Menu Principal",      "callback_data": "menu_main"}],
    ]}

def kb_network():
    return {"inline_keyboard": [
        [{"text": "🌐 IPs das Interfaces", "callback_data": "net_ips"}],
        [{"text": "📡 Teste de Ping",      "callback_data": "net_ping"}],
        [{"text": "🏠 Menu Principal",     "callback_data": "menu_main"}],
    ]}

def kb_actions():
    return {"inline_keyboard": [
        [{"text": "🔄 Atualizar Sistema",  "callback_data": "act_update_confirm"}],
        [{"text": "🧹 Limpar Cache RAM",   "callback_data": "act_cache_confirm"}],
        [{"text": "📜 Logs de Erros",      "callback_data": "act_logs"}],
        [{"text": "🏠 Menu Principal",     "callback_data": "menu_main"}],
    ]}

def kb_confirm(action):
    return {"inline_keyboard": [
        [{"text": "✅ Confirmar", "callback_data": f"act_do_{action}"},
         {"text": "❌ Cancelar", "callback_data": "menu_actions"}],
    ]}

# ──────────────────────────────────────────────
# Helpers de envio
# ──────────────────────────────────────────────
def edit(chat_id, msg_id, text, keyboard=None):
    data = {"chat_id": chat_id, "message_id": msg_id,
            "text": text, "parse_mode": "Markdown"}
    if keyboard:
        data["reply_markup"] = keyboard
    call_api("editMessageText", data)

def send(chat_id, text, keyboard=None):
    data = {"chat_id": chat_id, "text": text, "parse_mode": "Markdown"}
    if keyboard:
        data["reply_markup"] = keyboard
    call_api("sendMessage", data)

def answer(cb_id, text=""):
    call_api("answerCallbackQuery", {"callback_query_id": cb_id, "text": text})

# ──────────────────────────────────────────────
# Handlers
# ──────────────────────────────────────────────
def handle_message(msg):
    chat_id = str(msg.get('chat', {}).get('id'))
    if chat_id != ALLOWED_CHAT_ID:
        return
    send(chat_id,
         f"🤖 *{SERVER_NAME}* — PVE Manager\nEscolha uma categoria:",
         kb_main())

def handle_callback(cb):
    chat_id = str(cb.get('message', {}).get('chat', {}).get('id'))
    if chat_id != ALLOWED_CHAT_ID:
        return
    cb_id  = cb.get('id')
    data   = cb.get('data', '')
    msg_id = cb.get('message', {}).get('message_id')

    answer(cb_id)

    # ── Main ──
    if data == "menu_main":
        edit(chat_id, msg_id,
             f"🤖 *{SERVER_NAME}* — PVE Manager\nEscolha uma categoria:",
             kb_main())

    # ── VMs & Containers ──
    elif data == "menu_vms_ct":
        edit(chat_id, msg_id, f"*{SERVER_NAME}* › VMs e Containers", kb_vms_ct())

    elif data == "menu_vms":
        vms = get_vms()
        if not vms:
            edit(chat_id, msg_id, "⚠️ Nenhuma VM encontrada.", kb_vms_ct())
        else:
            edit(chat_id, msg_id, f"*{SERVER_NAME}* › VMs — Selecione:", kb_vms())

    elif data == "menu_cts":
        cts = get_containers()
        if not cts:
            edit(chat_id, msg_id, "⚠️ Nenhum Container encontrado.", kb_vms_ct())
        else:
            edit(chat_id, msg_id, f"*{SERVER_NAME}* › Containers — Selecione:", kb_cts())

    elif data == "list_all":
        vms = get_vms()
        cts = get_containers()
        lines = [f"📋 *{SERVER_NAME}* — Todas as VMs/CTs\n━━━━━━━━━━━━━━━━━━━━━━"]
        if vms:
            lines.append("*🖥️ VMs:*")
            for v in vms:
                lines.append(f"  {status_icon(v['status'])} `{v['id']}` {v['name']} — _{v['status']}_")
        if cts:
            lines.append("*📦 Containers:*")
            for c in cts:
                lines.append(f"  {status_icon(c['status'])} `{c['id']}` {c['name']} — _{c['status']}_")
        if not vms and not cts:
            lines.append("Nenhuma VM ou Container encontrado.")
        edit(chat_id, msg_id, "\n".join(lines), kb_vms_ct())

    elif data == "list_locked":
        out = run("qm list 2>/dev/null | awk '$3 ~ /lock/ {print}'", shell=True)
        if not out:
            out = run("find /var/run/qemu-server/ -name '*.lock' 2>/dev/null", shell=True)
        text = f"🔒 *VMs com Lock*\n━━━━━━━━━━━━━━━━━━━━━━\n"
        text += f"`{out}`" if out else "✅ Nenhuma VM travada encontrada."
        edit(chat_id, msg_id, text, kb_vms_ct())

    # VM selecionada
    elif data.startswith("vm_") and not any(data.startswith(f"vm_{x}_") for x in ['start','shutdown','stop','reboot','suspend','status']):
        vmid = data[3:]
        vms = get_vms()
        vm = next((v for v in vms if v['id'] == vmid), None)
        name = vm['name'] if vm else vmid
        status = vm['status'] if vm else '?'
        edit(chat_id, msg_id,
             f"*{SERVER_NAME}* › VM `{vmid}` — {name}\nStatus: {status_icon(status)} _{status}_\n\nEscolha uma ação:",
             kb_vm_actions(vmid))

    # Ação em VM
    elif data.startswith("vm_") and "_" in data[3:]:
        parts = data[3:].split("_", 1)
        action, vmid = parts[0], parts[1]
        if action == "status":
            out = run(['qm', 'status', vmid])
            config = run(['qm', 'config', vmid])
            mem = next((l for l in config.split('\n') if l.startswith('memory:')), '')
            cores = next((l for l in config.split('\n') if l.startswith('cores:')), '')
            edit(chat_id, msg_id,
                 f"📊 *Status VM {vmid}*\n━━━━━━━━━━━━━━━━━━━━━━\n`{out}`\n{mem}\n{cores}",
                 kb_vm_actions(vmid))
        elif action in ('start', 'shutdown', 'stop', 'reboot', 'suspend'):
            run_bg(['qm', action, vmid])
            labels = {'start':'Ligar','shutdown':'Desligar','stop':'Forçar parada','reboot':'Reiniciar','suspend':'Pausar'}
            edit(chat_id, msg_id,
                 f"✅ Comando *{labels.get(action, action)}* enviado para VM `{vmid}`.",
                 kb_vm_actions(vmid))

    # Container selecionado
    elif data.startswith("ct_") and not any(data.startswith(f"ct_{x}_") for x in ['start','shutdown','stop','reboot','status']):
        ctid = data[3:]
        cts = get_containers()
        ct = next((c for c in cts if c['id'] == ctid), None)
        name = ct['name'] if ct else ctid
        status = ct['status'] if ct else '?'
        edit(chat_id, msg_id,
             f"*{SERVER_NAME}* › CT `{ctid}` — {name}\nStatus: {status_icon(status)} _{status}_\n\nEscolha uma ação:",
             kb_ct_actions(ctid))

    # Ação em Container
    elif data.startswith("ct_") and "_" in data[3:]:
        parts = data[3:].split("_", 1)
        action, ctid = parts[0], parts[1]
        if action == "status":
            out = run(['pct', 'status', ctid])
            config = run(['pct', 'config', ctid])
            mem = next((l for l in config.split('\n') if l.startswith('memory:')), '')
            edit(chat_id, msg_id,
                 f"📊 *Status CT {ctid}*\n━━━━━━━━━━━━━━━━━━━━━━\n`{out}`\n{mem}",
                 kb_ct_actions(ctid))
        elif action in ('start', 'shutdown', 'stop', 'reboot'):
            run_bg(['pct', action, ctid])
            labels = {'start':'Ligar','shutdown':'Desligar','stop':'Forçar parada','reboot':'Reiniciar'}
            edit(chat_id, msg_id,
                 f"✅ Comando *{labels.get(action, action)}* enviado para CT `{ctid}`.",
                 kb_ct_actions(ctid))

    # ── Status do Servidor ──
    elif data == "menu_status":
        edit(chat_id, msg_id, f"*{SERVER_NAME}* › Status do Servidor", kb_status())

    elif data == "st_host":
        edit(chat_id, msg_id, get_host_info(), kb_status())

    elif data == "st_temp":
        edit(chat_id, msg_id, get_temperature(), kb_status())

    elif data == "st_disk":
        edit(chat_id, msg_id, get_disk_usage(), kb_status())

    elif data == "st_services":
        edit(chat_id, msg_id, get_pve_services(), kb_status())

    # ── Storage & Backups ──
    elif data == "menu_storage":
        edit(chat_id, msg_id, f"*{SERVER_NAME}* › Storage & Backups", kb_storage())

    elif data == "sg_status":
        edit(chat_id, msg_id, get_storage_status(), kb_storage())

    elif data == "sg_backups":
        edit(chat_id, msg_id, get_last_backups(), kb_storage())

    # ── Rede ──
    elif data == "menu_network":
        edit(chat_id, msg_id, f"*{SERVER_NAME}* › Rede", kb_network())

    elif data == "net_ips":
        edit(chat_id, msg_id, get_network_info(), kb_network())

    elif data == "net_ping":
        edit(chat_id, msg_id, "📡 Testando conectividade...", kb_network())
        edit(chat_id, msg_id, get_ping_test(), kb_network())

    # ── Ações Rápidas ──
    elif data == "menu_actions":
        edit(chat_id, msg_id, f"*{SERVER_NAME}* › Ações Rápidas", kb_actions())

    elif data == "act_update_confirm":
        edit(chat_id, msg_id,
             "⚠️ *Confirmar Atualização do Sistema*\nIsso executará `apt update && apt upgrade -y`\n\nDeseja continuar?",
             kb_confirm("update"))

    elif data == "act_cache_confirm":
        edit(chat_id, msg_id,
             "⚠️ *Confirmar Limpeza de Cache RAM*\nIsso executa `sync && drop_caches=3`\n\nDeseja continuar?",
             kb_confirm("cache"))

    elif data == "act_logs":
        edit(chat_id, msg_id, get_recent_logs(), kb_actions())

    elif data == "act_do_update":
        edit(chat_id, msg_id, "🔄 *Atualização iniciada em background...*\nAcompanhe nos logs do sistema.", kb_actions())
        run_bg(['bash', '-c', 'apt-get update -qq && apt-get upgrade -y -qq > /tmp/pve-tg-update.log 2>&1'])

    elif data == "act_do_cache":
        run(['bash', '-c', 'sync && echo 3 > /proc/sys/vm/drop_caches'])
        edit(chat_id, msg_id, "🧹 *Cache RAM limpo com sucesso!*", kb_actions())

# ──────────────────────────────────────────────
# Loop principal
# ──────────────────────────────────────────────
def main():
    offset = 0
    print(f"Iniciando PVE Telegram Bot para {SERVER_NAME}...")
    while True:
        try:
            res = call_api("getUpdates", {"offset": offset, "timeout": 30})
            if res and res.get("ok"):
                for update in res.get("result", []):
                    offset = update["update_id"] + 1
                    if "message" in update:
                        handle_message(update["message"])
                    elif "callback_query" in update:
                        handle_callback(update["callback_query"])
            time.sleep(1)
        except Exception as e:
            print(f"Erro no loop principal: {e}")
            time.sleep(5)

if __name__ == "__main__":
    main()
PYEOF

    chmod +x /usr/local/bin/pve-telegram-bot.py
    
    cat << 'EOF' > /etc/systemd/system/pve-telegram-bot.service
[Unit]
Description=Proxmox Telegram Bot Backend (TcTI-BR)
After=network.target

[Service]
ExecStart=/usr/local/bin/pve-telegram-bot.py
Restart=always
RestartSec=5
User=root
StandardOutput=syslog
StandardError=syslog
SyslogIdentifier=pve-telegram-bot

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl enable pve-telegram-bot
    systemctl restart pve-telegram-bot
    
    echo -e "\n${COLOR_GREEN}${SYMBOL_CHECK} Bot Instalado com Sucesso!${COLOR_RESET}"
    echo -e "${COLOR_WHITE}Abra o seu bot no Telegram e envie ${COLOR_YELLOW}/start${COLOR_WHITE} ou ${COLOR_YELLOW}/menu${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_CYAN}  Funcionalidades disponíveis:${COLOR_RESET}"
    echo -e "  ${COLOR_GRAY}▸${COLOR_RESET} 💻 Gerenciar VMs (ligar/desligar/reiniciar/forçar/pausar)"
    echo -e "  ${COLOR_GRAY}▸${COLOR_RESET} 📦 Gerenciar Containers LXC"
    echo -e "  ${COLOR_GRAY}▸${COLOR_RESET} 📋 Listar todas as VMs/CTs + detectar VMs com Lock"
    echo -e "  ${COLOR_GRAY}▸${COLOR_RESET} 🖥️  Status: CPU, RAM, Uptime, Temperatura, Disco, Serviços"
    echo -e "  ${COLOR_GRAY}▸${COLOR_RESET} 💾 Storage: uso de espaço e últimos backups"
    echo -e "  ${COLOR_GRAY}▸${COLOR_RESET} 🌐 Rede: IPs das interfaces e teste de ping"
    echo -e "  ${COLOR_GRAY}▸${COLOR_RESET} 🛠️  Ações: atualizar sistema, limpar cache, ver logs"
    echo ""
    read -p "$(echo -e ${COLOR_YELLOW}"Pressione ENTER para voltar ao menu..."${COLOR_RESET})"
}

uninstall_telegram_bot() {
    clear
    echo -e "${COLOR_YELLOW}${COLOR_BOLD}⚠️  Atenção! Você está prestes a desinstalar o Bot.${COLOR_RESET}"
    read -p "$(echo -e "Deseja continuar? [y/N]: ")" confirm
    if [[ "$confirm" =~ ^[Yy]$ ]]; then
        echo -e "\n${COLOR_BLUE}${SYMBOL_LOADING} Removendo serviço...${COLOR_RESET}"
        systemctl stop pve-telegram-bot 2>/dev/null
        systemctl disable pve-telegram-bot 2>/dev/null
        rm -f /etc/systemd/system/pve-telegram-bot.service
        systemctl daemon-reload
        
        echo -e "${COLOR_BLUE}${SYMBOL_LOADING} Removendo arquivos...${COLOR_RESET}"
        rm -f /usr/local/bin/pve-telegram-bot.py
        rm -rf /TcTI/SCRIPTS/telegram/.env
        
        echo -e "\n${COLOR_GREEN}${SYMBOL_CHECK} Desinstalação concluída!${COLOR_RESET}"
        sleep 2
    fi
}

restart_telegram_bot() {
    clear
    echo -e "${COLOR_BLUE}${SYMBOL_LOADING} Reiniciando serviço do Telegram...${COLOR_RESET}"
    systemctl restart pve-telegram-bot
    echo -e "\n${COLOR_GREEN}${SYMBOL_CHECK} Serviço reiniciado!${COLOR_RESET}"
    sleep 2
}

update_telegram_bot() {
    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}"
    echo -e "╔═════════════════════════════════════════════════════════════════════╗"
    echo -e "║          🔄 Atualizar Script do Bot (manter credenciais)             ║"
    echo -e "╚═════════════════════════════════════════════════════════════════════╝"
    echo -e "${COLOR_RESET}"
    echo ""

    if [ ! -f "/TcTI/SCRIPTS/telegram/.env" ]; then
        echo -e "${COLOR_RED}  ✗ Credenciais não encontradas em /TcTI/SCRIPTS/telegram/.env${COLOR_RESET}"
        echo -e "${COLOR_YELLOW}  Use a opção 1 para instalar e configurar o bot primeiro.${COLOR_RESET}"
        echo ""
        read -p "  Pressione ENTER para voltar..."
        return
    fi

    echo -e "${COLOR_WHITE}  As credenciais existentes serão mantidas.${COLOR_RESET}"
    echo -e "  ${COLOR_GRAY}Token e Chat ID: preservados${COLOR_RESET}"
    echo -e "  ${COLOR_GRAY}Script Python:   será substituído pela versão mais recente${COLOR_RESET}"
    echo ""
    read -p "  Confirma atualização? (s/N): " confirm
    if [[ ! "$confirm" =~ ^[Ss]$ ]]; then
        echo -e "${COLOR_GRAY}  Cancelado.${COLOR_RESET}"
        sleep 1
        return
    fi

    echo ""
    echo -e "${COLOR_BLUE}${SYMBOL_LOADING} Substituindo script Python...${COLOR_RESET}"

    # Reutiliza a mesma lógica de escrita do Python de install_telegram_bot
    # extraindo apenas o heredoc do script — chama install porém pulando credenciais
    # Estratégia: copia o .env atual, chama install_telegram_bot passando dados existentes
    local env_data
    env_data=$(cat /TcTI/SCRIPTS/telegram/.env)
    local decoded
    decoded=$(echo "$env_data" | base64 -d 2>/dev/null)
    local token chat_id srv_name
    token=$(echo "$decoded"    | python3 -c 'import sys,json; d=json.load(sys.stdin); print(d["token"])'    2>/dev/null)
    chat_id=$(echo "$decoded"  | python3 -c 'import sys,json; d=json.load(sys.stdin); print(d["chat_id"])' 2>/dev/null)
    srv_name=$(echo "$decoded" | python3 -c 'import sys,json; d=json.load(sys.stdin); print(d["server_name"])' 2>/dev/null)

    if [[ -z "$token" || -z "$chat_id" || -z "$srv_name" ]]; then
        echo -e "${COLOR_RED}  ✗ Não foi possível decodificar as credenciais existentes.${COLOR_RESET}"
        echo -e "${COLOR_YELLOW}  Use a opção 1 para reconfigurar.${COLOR_RESET}"
        echo ""
        read -p "  Pressione ENTER para voltar..."
        return
    fi

    # Reutiliza install_telegram_bot com as credenciais já existentes (bypass do read)
    # Atribui variáveis que install_telegram_bot usaria e chama direto a parte do Python
    _deploy_bot_python

    echo -e "\n${COLOR_GREEN}${SYMBOL_CHECK} Bot atualizado com sucesso!${COLOR_RESET}"
    echo -e "${COLOR_WHITE}  Credenciais preservadas | Servidor: ${COLOR_YELLOW}${srv_name}${COLOR_RESET}"
    echo ""
    read -p "  Pressione ENTER para voltar..."
}

# Função auxiliar: escreve apenas o Python e reinicia o serviço (sem mexer em credenciais)
_deploy_bot_python() {
    cat << 'PYEOF' > /usr/local/bin/pve-telegram-bot.py
#!/usr/bin/env python3
# PVE Telegram Bot — TcTI-BR
import urllib.request
import json, subprocess, time, base64, sys, os

CONFIG_FILE = "/TcTI/SCRIPTS/telegram/.env"

def load_config():
    try:
        with open(CONFIG_FILE, 'r') as f:
            decoded = base64.b64decode(f.read().strip()).decode('utf-8')
            config = json.loads(decoded)
            return config['token'], str(config['chat_id']), config['server_name']
    except Exception as e:
        print(f"Erro config: {e}"); sys.exit(1)

TOKEN, ALLOWED_CHAT_ID, SERVER_NAME = load_config()
BASE_URL = f"https://api.telegram.org/bot{TOKEN}/"

def call_api(method, data=None):
    url = BASE_URL + method
    req = urllib.request.Request(url)
    req.add_header('Content-Type', 'application/json')
    try:
        payload = json.dumps(data).encode('utf-8') if data else None
        resp = urllib.request.urlopen(req, data=payload, timeout=35)
        return json.loads(resp.read().decode('utf-8'))
    except Exception as e:
        print(f"API Error ({method}): {e}")
        return None

def run(cmd, shell=False):
    try:
        out = subprocess.check_output(cmd, shell=shell, stderr=subprocess.DEVNULL)
        return out.decode('utf-8', errors='replace').strip()
    except:
        return ""

def run_bg(cmd):
    try: subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception as e: print(f"bg err: {e}")

def get_vms():
    vms = []
    for line in run(['qm','list']).split('\n')[1:]:
        p = line.split()
        if len(p)>=3: vms.append({'id':p[0],'name':p[1],'status':p[2],'type':'vm'})
    return vms

def get_containers():
    cts = []
    for line in run(['pct','list']).split('\n')[1:]:
        p = line.split()
        if len(p)>=3: cts.append({'id':p[0],'name':p[2],'status':p[1],'type':'ct'})
    return cts

def icon(status): return '🟢' if status=='running' else '🔴' if status=='stopped' else '🟡'

def _bar(pct,w=12): return '█'*int(w*pct/100)+'░'*(w-int(w*pct/100))+f' {pct}%'

def get_host_info():
    uptime = run(['uptime','-p'])
    free = run(['free','-m']).split('\n')
    cpu = run("top -bn1 | grep 'Cpu' | awk '{print $2+$4}'",shell=True)
    rt=ru=0
    for l in free:
        if l.startswith('Mem:'): p=l.split(); rt=int(p[1]); ru=int(p[2]); break
    pct=int(ru/rt*100) if rt else 0
    return f"🖥️ *{SERVER_NAME}*\n━━━━━━━━━━━━━━━━━━━━━━\n⏱ Uptime: `{uptime}`\n🔥 CPU: `{cpu}%`\n💾 RAM: `{ru}MB/{rt}MB` ({pct}%)\n`{_bar(pct)}`"

def get_temperature():
    if run("which ipmitool",shell=True):
        out=run("ipmitool sdr type Temperature 2>/dev/null | grep -i 'inlet\\|ambient\\|cpu\\|temp' | head -6",shell=True)
        if out:
            lines=[]
            for l in out.split('\n'):
                if '|' in l:
                    p=[x.strip() for x in l.split('|')]
                    lines.append(f"  `{p[0]}`: {p[4] if len(p)>4 else '?'}")
            if lines: return "🌡️ *Temperatura (IPMI)*\n━━━━━━━━━━━━━━━━━━━━━━\n"+"\n".join(lines)
    if run("which sensors",shell=True):
        raw=run("sensors 2>/dev/null",shell=True)
        if raw:
            lines=[]; chip=''
            for l in raw.split('\n'):
                if l and ':' not in l and not l.startswith(' '): chip=l.lower()
                if any(s in chip for s in ['tg3','e1000']): continue
                if '°C' in l and any(k in l for k in ['Core','Package','temp']):
                    n=l.split(':')[0].strip(); v=l.split(':')[1].strip().split('(')[0].strip() if ':' in l else ''
                    lines.append(f"  `{n}`: {v}")
            if lines: return "🌡️ *Temperatura (Sensors)*\n━━━━━━━━━━━━━━━━━━━━━━\n"+"\n".join(lines[:8])
    temps=[]
    base='/sys/class/thermal'
    if os.path.isdir(base):
        for z in sorted(os.listdir(base)):
            tp=f"{base}/{z}/temp"; ty=f"{base}/{z}/type"
            if os.path.exists(tp):
                try:
                    val=int(open(tp).read().strip())/1000
                    typ=open(ty).read().strip() if os.path.exists(ty) else z
                    temps.append(f"  `{typ}`: {val:.1f}°C")
                except: pass
    if temps: return "🌡️ *Temperatura (Sysfs)*\n━━━━━━━━━━━━━━━━━━━━━━\n"+"\n".join(temps[:8])
    return "🌡️ Sem sensores disponíveis.\nInstale: `apt install lm-sensors ipmitool`"

def get_disk_usage():
    out=run("df -h --output=target,pcent,used,size -x tmpfs -x devtmpfs 2>/dev/null | tail -n+2",shell=True)
    lines=["💽 *Uso de Disco*","━━━━━━━━━━━━━━━━━━━━━━"]
    for l in out.split('\n'):
        p=l.split()
        if len(p)>=4:
            mp,pct,used,total=p[0],p[1],p[2],p[3]
            pi=int(pct.replace('%','')) if '%' in pct else 0
            ic='🔴' if pi>=90 else '🟡' if pi>=75 else '🟢'
            lines.append(f"{ic} `{mp}` — {used}/{total} ({pct})")
    return "\n".join(lines)

def get_pve_services():
    svcs=[('pve-cluster','🗃️ PVE Cluster'),('pvedaemon','⚙️  PVE Daemon'),('pveproxy','🌐 PVE Proxy'),
          ('pvestatd','📊 PVE Stats'),('corosync','🔗 Corosync'),('pve-firewall','🛡️  Firewall'),('qmeventd','📡 QM Events')]
    lines=["🔧 *Serviços Proxmox*","━━━━━━━━━━━━━━━━━━━━━━"]
    for svc,label in svcs:
        st=run(['systemctl','is-active',svc])
        ic='🟢' if st=='active' else '🔴'
        lines.append(f"{ic} {label}: `{st}`")
    return "\n".join(lines)

def get_storage_status():
    out=run(['pvesm','status'])
    lines=["💾 *Status dos Storages*","━━━━━━━━━━━━━━━━━━━━━━"]
    for l in out.split('\n')[1:]:
        p=l.split()
        if len(p)>=2:
            ic='🟢' if p[1]=='active' else '🔴'
            extra=''
            if len(p)>=6:
                try:
                    tg=int(p[3]); ug=int(p[4])
                    extra=f" — {ug/1024**2:.1f}/{tg/1024**2:.1f} GB ({int(ug/tg*100) if tg else 0}%)"
                except: pass
            lines.append(f"{ic} `{p[0]}`{extra}")
    return "\n".join(lines)

def get_last_backups():
    out=run("journalctl -u vzdump --no-pager -n 10 2>/dev/null | tail -10",shell=True)
    if not out: out=run("grep -r 'vzdump\\|TASK OK' /var/log/syslog 2>/dev/null | tail -8",shell=True)
    lines=["📦 *Últimos Backups*","━━━━━━━━━━━━━━━━━━━━━━"]
    if out:
        for l in out.split('\n')[:8]:
            if l.strip(): lines.append(f"`{l[:85]}`")
    else: lines.append("Nenhum registro encontrado.")
    return "\n".join(lines)

def get_network_info():
    out=run("ip -o addr show | grep -v ' lo ' | awk '{print $2, $4}'",shell=True)
    lines=["🌐 *Interfaces de Rede*","━━━━━━━━━━━━━━━━━━━━━━"]
    for l in out.split('\n'):
        p=l.split()
        if len(p)==2: lines.append(f"  `{p[0]}` — `{p[1]}`")
    return "\n".join(lines)

def get_ping_test():
    gw=run("ip route | grep default | awk '{print $3}' | head -1",shell=True)
    targets=[('8.8.8.8','Google DNS'),('1.1.1.1','Cloudflare'),(gw or '192.168.1.1',f'Gateway ({gw})')]
    lines=["📡 *Teste de Conectividade*","━━━━━━━━━━━━━━━━━━━━━━"]
    for host,label in targets:
        r=run(['ping','-c','2','-W','2',host])
        if '0% packet loss' in r or '2 received' in r:
            ms=[l for l in r.split('\n') if 'avg' in l]
            val=ms[0].split('/')[-2] if ms else '?'
            lines.append(f"🟢 {label}: `{val}ms`")
        else: lines.append(f"🔴 {label}: sem resposta")
    return "\n".join(lines)

def get_recent_logs():
    out=run("journalctl -p err..emerg --no-pager -n 12 --output=short-iso 2>/dev/null",shell=True)
    lines=["📜 *Logs Recentes (erros)*","━━━━━━━━━━━━━━━━━━━━━━"]
    if out:
        for l in out.split('\n')[:10]:
            if l.strip() and not l.startswith('--'): lines.append(f"`{l[:88]}`")
    else: lines.append("✅ Nenhum erro recente.")
    return "\n".join(lines)

# ── Teclados ──
def kb_main(): return {"inline_keyboard":[
    [{"text":"💻 VMs e Containers",  "callback_data":"menu_vms_ct"}],
    [{"text":"🖥️ Status do Servidor", "callback_data":"menu_status"}],
    [{"text":"💾 Storage & Backups",  "callback_data":"menu_storage"}],
    [{"text":"🌐 Rede",              "callback_data":"menu_network"}],
    [{"text":"🛠️ Ações Rápidas",     "callback_data":"menu_actions"}],
]}
def kb_vms_ct(): return {"inline_keyboard":[
    [{"text":"🖥️ Gerenciar VMs (QEMU)",      "callback_data":"menu_vms"}],
    [{"text":"📦 Gerenciar Containers (LXC)", "callback_data":"menu_cts"}],
    [{"text":"📋 Listar Todas",               "callback_data":"list_all"}],
    [{"text":"🔒 VMs com Lock",               "callback_data":"list_locked"}],
    [{"text":"🏠 Menu Principal",             "callback_data":"menu_main"}],
]}
def kb_vms():
    kb=[[{"text":f"{icon(v['status'])} {v['id']} — {v['name']}","callback_data":f"vm_{v['id']}"}] for v in get_vms()]
    kb.append([{"text":"🔙 Voltar","callback_data":"menu_vms_ct"}])
    return {"inline_keyboard":kb}
def kb_cts():
    kb=[[{"text":f"{icon(c['status'])} {c['id']} — {c['name']}","callback_data":f"ct_{c['id']}"}] for c in get_containers()]
    kb.append([{"text":"🔙 Voltar","callback_data":"menu_vms_ct"}])
    return {"inline_keyboard":kb}
def kb_vm_actions(vmid): return {"inline_keyboard":[
    [{"text":"⚡ Ligar","callback_data":f"vm_start_{vmid}"},{"text":"🛑 Desligar","callback_data":f"vm_shutdown_{vmid}"}],
    [{"text":"💀 Forçar","callback_data":f"vm_stop_{vmid}"},{"text":"🔄 Reiniciar","callback_data":f"vm_reboot_{vmid}"}],
    [{"text":"📊 Status","callback_data":f"vm_status_{vmid}"},{"text":"⏸️ Pausar","callback_data":f"vm_suspend_{vmid}"}],
    [{"text":"🔙 Voltar às VMs","callback_data":"menu_vms"}],
]}
def kb_ct_actions(ctid): return {"inline_keyboard":[
    [{"text":"⚡ Ligar","callback_data":f"ct_start_{ctid}"},{"text":"🛑 Desligar","callback_data":f"ct_shutdown_{ctid}"}],
    [{"text":"💀 Forçar","callback_data":f"ct_stop_{ctid}"},{"text":"🔄 Reiniciar","callback_data":f"ct_reboot_{ctid}"}],
    [{"text":"📊 Status","callback_data":f"ct_status_{ctid}"}],
    [{"text":"🔙 Voltar aos CTs","callback_data":"menu_cts"}],
]}
def kb_status(): return {"inline_keyboard":[
    [{"text":"📊 CPU & RAM & Uptime","callback_data":"st_host"}],
    [{"text":"🌡️ Temperatura",       "callback_data":"st_temp"}],
    [{"text":"💽 Uso de Disco",      "callback_data":"st_disk"}],
    [{"text":"🔧 Serviços Proxmox",  "callback_data":"st_services"}],
    [{"text":"🏠 Menu Principal",    "callback_data":"menu_main"}],
]}
def kb_storage(): return {"inline_keyboard":[
    [{"text":"💾 Status dos Storages","callback_data":"sg_status"}],
    [{"text":"📦 Últimos Backups",    "callback_data":"sg_backups"}],
    [{"text":"🏠 Menu Principal",     "callback_data":"menu_main"}],
]}
def kb_network(): return {"inline_keyboard":[
    [{"text":"🌐 IPs das Interfaces","callback_data":"net_ips"}],
    [{"text":"📡 Teste de Ping",     "callback_data":"net_ping"}],
    [{"text":"🏠 Menu Principal",    "callback_data":"menu_main"}],
]}
def kb_actions(): return {"inline_keyboard":[
    [{"text":"🔄 Atualizar Sistema", "callback_data":"act_update_confirm"}],
    [{"text":"🧹 Limpar Cache RAM",  "callback_data":"act_cache_confirm"}],
    [{"text":"📜 Logs de Erros",     "callback_data":"act_logs"}],
    [{"text":"🏠 Menu Principal",    "callback_data":"menu_main"}],
]}
def kb_confirm(action): return {"inline_keyboard":[
    [{"text":"✅ Confirmar","callback_data":f"act_do_{action}"},{"text":"❌ Cancelar","callback_data":"menu_actions"}],
]}

# ── Helpers ──
def edit(chat_id,msg_id,text,kb=None):
    d={"chat_id":chat_id,"message_id":msg_id,"text":text,"parse_mode":"Markdown"}
    if kb: d["reply_markup"]=kb
    call_api("editMessageText",d)
def send(chat_id,text,kb=None):
    d={"chat_id":chat_id,"text":text,"parse_mode":"Markdown"}
    if kb: d["reply_markup"]=kb
    call_api("sendMessage",d)
def answer(cb_id,text=""): call_api("answerCallbackQuery",{"callback_query_id":cb_id,"text":text})

# ── Handlers ──
def handle_message(msg):
    if str(msg.get('chat',{}).get('id'))!=ALLOWED_CHAT_ID: return
    send(str(msg['chat']['id']),f"🤖 *{SERVER_NAME}* — PVE Manager\nEscolha uma categoria:",kb_main())

def handle_callback(cb):
    chat_id=str(cb.get('message',{}).get('chat',{}).get('id',''))
    if chat_id!=ALLOWED_CHAT_ID: return
    cb_id=cb.get('id'); data=cb.get('data',''); msg_id=cb.get('message',{}).get('message_id')
    answer(cb_id)

    if data=="menu_main": edit(chat_id,msg_id,f"🤖 *{SERVER_NAME}* — PVE Manager\nEscolha uma categoria:",kb_main())
    elif data=="menu_vms_ct": edit(chat_id,msg_id,f"*{SERVER_NAME}* › VMs e Containers",kb_vms_ct())
    elif data=="menu_vms":
        vms=get_vms()
        edit(chat_id,msg_id,f"*{SERVER_NAME}* › VMs — Selecione:" if vms else "⚠️ Nenhuma VM encontrada.",kb_vms() if vms else kb_vms_ct())
    elif data=="menu_cts":
        cts=get_containers()
        edit(chat_id,msg_id,f"*{SERVER_NAME}* › Containers — Selecione:" if cts else "⚠️ Nenhum CT encontrado.",kb_cts() if cts else kb_vms_ct())
    elif data=="list_all":
        vms=get_vms(); cts=get_containers()
        lines=[f"📋 *{SERVER_NAME}* — Todas as VMs/CTs\n━━━━━━━━━━━━━━━━━━━━━━"]
        if vms:
            lines.append("*🖥️ VMs:*")
            for v in vms: lines.append(f"  {icon(v['status'])} `{v['id']}` {v['name']} — _{v['status']}_")
        if cts:
            lines.append("*📦 Containers:*")
            for c in cts: lines.append(f"  {icon(c['status'])} `{c['id']}` {c['name']} — _{c['status']}_")
        if not vms and not cts: lines.append("Nenhuma VM ou Container encontrado.")
        edit(chat_id,msg_id,"\n".join(lines),kb_vms_ct())
    elif data=="list_locked":
        out=run("find /var/run/qemu-server/ -name '*.lock' 2>/dev/null",shell=True)
        text=f"🔒 *VMs com Lock*\n━━━━━━━━━━━━━━━━━━━━━━\n`{out}`" if out else "🔒 *VMs com Lock*\n━━━━━━━━━━━━━━━━━━━━━━\n✅ Nenhuma VM travada."
        edit(chat_id,msg_id,text,kb_vms_ct())
    elif data.startswith("vm_") and "_" not in data[3:]:
        vmid=data[3:]; vms=get_vms(); vm=next((v for v in vms if v['id']==vmid),None)
        edit(chat_id,msg_id,f"*{SERVER_NAME}* › VM `{vmid}` — {vm['name'] if vm else vmid}\nStatus: {icon(vm['status'] if vm else '?')} _{vm['status'] if vm else '?'}_\n\nEscolha uma ação:",kb_vm_actions(vmid))
    elif data.startswith("vm_") and "_" in data[3:]:
        p=data[3:].split("_",1); action,vmid=p[0],p[1]
        if action=="status":
            out=run(['qm','status',vmid]); cfg=run(['qm','config',vmid])
            mem=next((l for l in cfg.split('\n') if l.startswith('memory:')),''); cores=next((l for l in cfg.split('\n') if l.startswith('cores:')),'') 
            edit(chat_id,msg_id,f"📊 *Status VM {vmid}*\n━━━━━━━━━━━━━━━━━━━━━━\n`{out}`\n{mem}\n{cores}",kb_vm_actions(vmid))
        elif action in('start','shutdown','stop','reboot','suspend'):
            run_bg(['qm',action,vmid])
            labels={'start':'Ligar','shutdown':'Desligar','stop':'Forçar','reboot':'Reiniciar','suspend':'Pausar'}
            edit(chat_id,msg_id,f"✅ Comando *{labels.get(action,action)}* enviado para VM `{vmid}`.",kb_vm_actions(vmid))
    elif data.startswith("ct_") and "_" not in data[3:]:
        ctid=data[3:]; cts=get_containers(); ct=next((c for c in cts if c['id']==ctid),None)
        edit(chat_id,msg_id,f"*{SERVER_NAME}* › CT `{ctid}` — {ct['name'] if ct else ctid}\nStatus: {icon(ct['status'] if ct else '?')} _{ct['status'] if ct else '?'}_\n\nEscolha uma ação:",kb_ct_actions(ctid))
    elif data.startswith("ct_") and "_" in data[3:]:
        p=data[3:].split("_",1); action,ctid=p[0],p[1]
        if action=="status":
            out=run(['pct','status',ctid]); cfg=run(['pct','config',ctid])
            mem=next((l for l in cfg.split('\n') if l.startswith('memory:')),'') 
            edit(chat_id,msg_id,f"📊 *Status CT {ctid}*\n━━━━━━━━━━━━━━━━━━━━━━\n`{out}`\n{mem}",kb_ct_actions(ctid))
        elif action in('start','shutdown','stop','reboot'):
            run_bg(['pct',action,ctid])
            labels={'start':'Ligar','shutdown':'Desligar','stop':'Forçar','reboot':'Reiniciar'}
            edit(chat_id,msg_id,f"✅ Comando *{labels.get(action,action)}* enviado para CT `{ctid}`.",kb_ct_actions(ctid))
    elif data=="menu_status": edit(chat_id,msg_id,f"*{SERVER_NAME}* › Status do Servidor",kb_status())
    elif data=="st_host":     edit(chat_id,msg_id,get_host_info(),kb_status())
    elif data=="st_temp":     edit(chat_id,msg_id,get_temperature(),kb_status())
    elif data=="st_disk":     edit(chat_id,msg_id,get_disk_usage(),kb_status())
    elif data=="st_services": edit(chat_id,msg_id,get_pve_services(),kb_status())
    elif data=="menu_storage": edit(chat_id,msg_id,f"*{SERVER_NAME}* › Storage & Backups",kb_storage())
    elif data=="sg_status":   edit(chat_id,msg_id,get_storage_status(),kb_storage())
    elif data=="sg_backups":  edit(chat_id,msg_id,get_last_backups(),kb_storage())
    elif data=="menu_network": edit(chat_id,msg_id,f"*{SERVER_NAME}* › Rede",kb_network())
    elif data=="net_ips":     edit(chat_id,msg_id,get_network_info(),kb_network())
    elif data=="net_ping":    edit(chat_id,msg_id,"📡 Testando...",kb_network()); edit(chat_id,msg_id,get_ping_test(),kb_network())
    elif data=="menu_actions": edit(chat_id,msg_id,f"*{SERVER_NAME}* › Ações Rápidas",kb_actions())
    elif data=="act_update_confirm": edit(chat_id,msg_id,"⚠️ *Confirmar Atualização do Sistema*\n`apt update && apt upgrade -y`\n\nDeseja continuar?",kb_confirm("update"))
    elif data=="act_cache_confirm":  edit(chat_id,msg_id,"⚠️ *Confirmar Limpeza de Cache RAM*\n`sync && drop_caches=3`\n\nDeseja continuar?",kb_confirm("cache"))
    elif data=="act_logs":    edit(chat_id,msg_id,get_recent_logs(),kb_actions())
    elif data=="act_do_update": edit(chat_id,msg_id,"🔄 *Atualização iniciada em background...*",kb_actions()); run_bg(['bash','-c','apt-get update -qq && apt-get upgrade -y -qq > /tmp/pve-tg-update.log 2>&1'])
    elif data=="act_do_cache":  run(['bash','-c','sync && echo 3 > /proc/sys/vm/drop_caches']); edit(chat_id,msg_id,"🧹 *Cache RAM limpo com sucesso!*",kb_actions())

def main():
    offset=0
    print(f"PVE Telegram Bot iniciado para {SERVER_NAME}")
    while True:
        try:
            res=call_api("getUpdates",{"offset":offset,"timeout":30})
            if res and res.get("ok"):
                for u in res.get("result",[]):
                    offset=u["update_id"]+1
                    if "message" in u: handle_message(u["message"])
                    elif "callback_query" in u: handle_callback(u["callback_query"])
            time.sleep(1)
        except Exception as e:
            print(f"Erro: {e}"); time.sleep(5)

if __name__=="__main__": main()
PYEOF
    chmod +x /usr/local/bin/pve-telegram-bot.py
    systemctl restart pve-telegram-bot
}

logs_telegram_bot() {
    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}Últimas 30 linhas de log do Bot Telegram:${COLOR_RESET}"
    echo -e "────────────────────────────────────────────────────"
    journalctl -u pve-telegram-bot -n 30 --no-pager
    echo -e "────────────────────────────────────────────────────"
    echo ""
    read -p "$(echo -e ${COLOR_YELLOW}"Pressione ENTER para voltar ao menu..."${COLOR_RESET})"
}
