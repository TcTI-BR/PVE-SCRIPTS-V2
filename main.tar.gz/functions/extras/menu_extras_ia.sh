#!/bin/bash

# Assistente de Configuração e Gerenciamento de IA (Extras)
# Autor: TcTI-BR

AI_CONFIG_FILE="/root/.ai_config"
OPENAI_KEY_FILE="/root/.openai_key"

show_masked_key() {
    local key=$1
    local key_length=${#key}
    if [ $key_length -gt 12 ]; then
        echo "${key:0:4}...${key: -4}"
    else
        echo "***"
    fi
}

load_ai_config() {
    AI_PROVIDER=""
    AI_MODEL=""
    AI_KEY=""
    if [ -f "$AI_CONFIG_FILE" ]; then
        source "$AI_CONFIG_FILE"
    elif [ -f "$OPENAI_KEY_FILE" ]; then
        AI_PROVIDER="openai"
        AI_MODEL="gpt-4o-mini"
        AI_KEY=$(cat "$OPENAI_KEY_FILE")
    fi
}

test_ai_connection() {
    local provider="$1"
    local model="$2"
    local key="$3"

    echo -e "${COLOR_YELLOW}  Testando conexão com $provider ($model)...${COLOR_RESET}"
    
    local http_code="000"
    if [ "$provider" = "gemini" ]; then
        local url="https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}"
        http_code=$(curl -s -o /dev/null -w "%{http_code}" -X POST "$url" \
            -H "Content-Type: application/json" \
            -d '{"contents":[{"parts":[{"text":"ping"}]}]}')
    elif [ "$provider" = "openai" ]; then
        http_code=$(curl -s -o /dev/null -w "%{http_code}" -X POST "https://api.openai.com/v1/chat/completions" \
            -H "Authorization: Bearer $key" \
            -H "Content-Type: application/json" \
            -d "{\"model\":\"$model\",\"messages\":[{\"role\":\"user\",\"content\":\"ping\"}],\"max_tokens\":5}")
    elif [ "$provider" = "claude" ]; then
        http_code=$(curl -s -o /dev/null -w "%{http_code}" -X POST "https://api.anthropic.com/v1/messages" \
            -H "x-api-key: $key" \
            -H "anthropic-version: 2023-06-01" \
            -H "Content-Type: application/json" \
            -d "{\"model\":\"$model\",\"max_tokens\":5,\"messages\":[{\"role\":\"user\",\"content\":\"ping\"}]}")
    fi

    if [ "$http_code" = "200" ]; then
        echo -e "${COLOR_GREEN}  ✓ Sucesso! Conexão estabelecida com a API de $provider (HTTP 200).${COLOR_RESET}"
        return 0
    elif [ "$http_code" = "401" ] || [ "$http_code" = "403" ]; then
        echo -e "${COLOR_RED}  ✗ Erro de Autenticação (HTTP $http_code): Chave API inválida ou sem permissão.${COLOR_RESET}"
        return 1
    elif [ "$http_code" = "429" ]; then
        echo -e "${COLOR_YELLOW}  ⚠ Limite de requisições / cota excedida (HTTP 429). A chave é válida.${COLOR_RESET}"
        return 0
    else
        echo -e "${COLOR_RED}  ✗ Falha de comunicação (HTTP $http_code). Verifique sua conexão ou parâmetros.${COLOR_RESET}"
        return 1
    fi
}

run_ai_wizard() {
    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}"
    echo -e "╔═════════════════════════════════════════════════════════════════════╗"
    echo -e "║            🧙 ASSISTENTE DE CONFIGURAÇÃO DE INTELIGÊNCIA ARTIFICIAL  ║"
    echo -e "╚═════════════════════════════════════════════════════════════════════╝"
    echo -e "${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_BOLD}  PASSO 1: Escolha o Provedor de IA:${COLOR_RESET}"
    echo ""
    echo -e "  ${COLOR_CYAN}1${COLOR_RESET} ➜ ${COLOR_WHITE}Google Gemini${COLOR_RESET} ${COLOR_GRAY}(Recomendado - Gratuito/Econômico e Veloz)${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}2${COLOR_RESET} ➜ ${COLOR_WHITE}OpenAI${COLOR_RESET} ${COLOR_GRAY}(ChatGPT / GPT-4o / GPT-4o-mini)${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}3${COLOR_RESET} ➜ ${COLOR_WHITE}Anthropic Claude${COLOR_RESET} ${COLOR_GRAY}(Claude 3.5 Sonnet)${COLOR_RESET}"
    echo -e "  ${COLOR_RED}0${COLOR_RESET} ➜ ${COLOR_WHITE}Cancelar${COLOR_RESET}"
    echo ""
    read -p "  Selecione a opção (1-3): " prov_opt

    local sel_provider=""
    case $prov_opt in
        1) sel_provider="gemini" ;;
        2) sel_provider="openai" ;;
        3) sel_provider="claude" ;;
        0) return ;;
        *) echo -e "${COLOR_RED}Opção inválida!${COLOR_RESET}"; sleep 1; run_ai_wizard; return ;;
    esac

    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}"
    echo -e "╔═════════════════════════════════════════════════════════════════════╗"
    echo -e "║            🧙 ASSISTENTE DE CONFIGURAÇÃO DE INTELIGÊNCIA ARTIFICIAL  ║"
    echo -e "╚═════════════════════════════════════════════════════════════════════╝"
    echo -e "${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_BOLD}  PASSO 2: Selecione a Versão do Modelo ($sel_provider):${COLOR_RESET}"
    echo ""

    local sel_model=""
    if [ "$sel_provider" = "gemini" ]; then
        echo -e "  ${COLOR_CYAN}1${COLOR_RESET} ➜ ${COLOR_WHITE}gemini-3.6-flash${COLOR_RESET} ${COLOR_GREEN}(Recomendado - Alta Performance e Inteligência em Agentes)${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}2${COLOR_RESET} ➜ ${COLOR_WHITE}gemini-3.5-flash-lite${COLOR_RESET} ${COLOR_CYAN}(Ultra Rápido e Menor Custo)${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}3${COLOR_RESET} ➜ ${COLOR_WHITE}gemini-1.5-flash${COLOR_RESET} ${COLOR_GRAY}(Geração 1.5 Flash)${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}4${COLOR_RESET} ${COLOR_WHITE}gemini-1.5-pro${COLOR_RESET} ${COLOR_YELLOW}(Raciocínio Profundo)${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}9${COLOR_RESET} ➜ ${COLOR_WHITE}Digitar modelo personalizado...${COLOR_RESET}"
        echo ""
        read -p "  Escolha o modelo (1-9): " mod_opt
        case $mod_opt in
            1) sel_model="gemini-3.6-flash" ;;
            2) sel_model="gemini-3.5-flash-lite" ;;
            3) sel_model="gemini-1.5-flash" ;;
            4) sel_model="gemini-1.5-pro" ;;
            9) read -p "  Digite o ID do modelo Gemini (ex: gemini-3.6-flash): " custom_m
               sel_model="$custom_m"
               ;;
            *) sel_model="gemini-3.6-flash" ;;
        esac
    elif [ "$sel_provider" = "openai" ]; then
        echo -e "  ${COLOR_CYAN}1${COLOR_RESET} ➜ ${COLOR_WHITE}gpt-4o-mini${COLOR_RESET} ${COLOR_GREEN}(Recomendado - Rápido, Barato e Eficiente)${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}2${COLOR_RESET} ➜ ${COLOR_WHITE}gpt-4o${COLOR_RESET} ${COLOR_YELLOW}(Flagship Multimodal)${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}3${COLOR_RESET} ➜ ${COLOR_WHITE}o3-mini${COLOR_RESET} ${COLOR_MAGENTA}(Novo Modelo de Raciocínio Lógico e Código)${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}4${COLOR_RESET} ➜ ${COLOR_WHITE}o1${COLOR_RESET} ${COLOR_CYAN}(Raciocínio de Alta Precisão)${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}9${COLOR_RESET} ➜ ${COLOR_WHITE}Digitar modelo personalizado...${COLOR_RESET}"
        echo ""
        read -p "  Escolha o modelo (1-9): " mod_opt
        case $mod_opt in
            1) sel_model="gpt-4o-mini" ;;
            2) sel_model="gpt-4o" ;;
            3) sel_model="o3-mini" ;;
            4) sel_model="o1" ;;
            9) read -p "  Digite o ID do modelo OpenAI (ex: gpt-4o): " custom_m
               sel_model="$custom_m"
               ;;
            *) sel_model="gpt-4o-mini" ;;
        esac
    elif [ "$sel_provider" = "claude" ]; then
        echo -e "  ${COLOR_CYAN}1${COLOR_RESET} ➜ ${COLOR_WHITE}claude-3-5-sonnet-20241022${COLOR_RESET} ${COLOR_GREEN}(Recomendado - Excelente em Código/Análise)${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}2${COLOR_RESET} ➜ ${COLOR_WHITE}claude-3-5-haiku-20241022${COLOR_RESET} ${COLOR_YELLOW}(Ultra Rápido e Leve)${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}9${COLOR_RESET} ➜ ${COLOR_WHITE}Digitar modelo personalizado...${COLOR_RESET}"
        echo ""
        read -p "  Escolha o modelo (1-9): " mod_opt
        case $mod_opt in
            1) sel_model="claude-3-5-sonnet-20241022" ;;
            2) sel_model="claude-3-5-haiku-20241022" ;;
            9) read -p "  Digite o ID do modelo Claude: " custom_m
               sel_model="$custom_m"
               ;;
            *) sel_model="claude-3-5-sonnet-20241022" ;;
        esac
    fi

    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}"
    echo -e "╔═════════════════════════════════════════════════════════════════════╗"
    echo -e "║            🧙 ASSISTENTE DE CONFIGURAÇÃO DE INTELIGÊNCIA ARTIFICIAL  ║"
    echo -e "╚═════════════════════════════════════════════════════════════════════╝"
    echo -e "${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_BOLD}  PASSO 3: Digite a Chave API:${COLOR_RESET}"
    if [ "$sel_provider" = "gemini" ]; then
        echo -e "${COLOR_GRAY}  (Geralmente começa com 'AIzaSy...')${COLOR_RESET}"
    elif [ "$sel_provider" = "openai" ]; then
        echo -e "${COLOR_GRAY}  (Geralmente começa com 'sk-...')${COLOR_RESET}"
    elif [ "$sel_provider" = "claude" ]; then
        echo -e "${COLOR_GRAY}  (Geralmente começa com 'sk-ant-...')${COLOR_RESET}"
    fi
    echo ""
    read -p "  Insira sua chave API: " input_key

    if [ -z "$input_key" ]; then
        echo -e "${COLOR_RED}  ✗ Erro: A chave API não pode ficar em branco.${COLOR_RESET}"
        sleep 2
        return
    fi

    echo ""
    echo -e "${COLOR_CYAN}  Verificando chave digitada...${COLOR_RESET}"
    test_ai_connection "$sel_provider" "$sel_model" "$input_key"
    
    # Salva as configurações
    cat > "$AI_CONFIG_FILE" << EOF
AI_PROVIDER="$sel_provider"
AI_MODEL="$sel_model"
AI_KEY="$input_key"
EOF
    chmod 600 "$AI_CONFIG_FILE"

    # Mantém compatibilidade com scripts legados que leem .openai_key
    if [ "$sel_provider" = "openai" ]; then
        echo "$input_key" > "$OPENAI_KEY_FILE"
        chmod 600 "$OPENAI_KEY_FILE"
    fi

    echo ""
    echo -e "${COLOR_GREEN}${COLOR_BOLD}  ✓ Configuração concluída! O provedor $sel_provider ($sel_model) está ATIVO.${COLOR_RESET}"
    read -p "  Pressione ENTER para continuar..."
}

extras_ia_menu(){
    load_ai_config

    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}"
    echo -e "╔═════════════════════════════════════════════════════════════════════╗"
    echo -e "║                                                                     ║"
    echo -e "║            🤖 Central de Configuração de Inteligência Artificial     ║"
    echo -e "║                                                                     ║"
    echo -e "╚═════════════════════════════════════════════════════════════════════╝"
    echo -e "${COLOR_RESET}"
    echo ""

    # Exibe o Status Atual em Destaque
    echo -e "${COLOR_BOLD}  STATUS DA IA NO SISTEMA:${COLOR_RESET}"
    if [ -n "$AI_KEY" ]; then
        local m_key=$(show_masked_key "$AI_KEY")
        local p_label=""
        case $AI_PROVIDER in
            gemini) p_label="🟢 Google Gemini" ;;
            openai) p_label="🟢 OpenAI (ChatGPT)" ;;
            claude) p_label="🟢 Anthropic Claude" ;;
            *) p_label="🟢 $AI_PROVIDER" ;;
        esac
        echo -e "  ├─ Provedor Ativo : ${COLOR_GREEN}${COLOR_BOLD}${p_label}${COLOR_RESET}"
        echo -e "  ├─ Modelo Versão  : ${COLOR_YELLOW}${AI_MODEL}${COLOR_RESET}"
        echo -e "  └─ Chave API      : ${COLOR_CYAN}${m_key}${COLOR_RESET} ${COLOR_GREEN}(✓ Configurada)${COLOR_RESET}"
    else
        echo -e "  └─ Status         : ${COLOR_RED}🔴 Nenhuma Chave de IA Cadastrada${COLOR_RESET}"
    fi

    echo ""
    echo -e "${COLOR_BOLD}  Selecione uma opção:${COLOR_RESET}"
    echo ""
    echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}1${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}🧙 Assistente de Configuração (Provedor + Modelo + Chave)${COLOR_RESET}${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}2${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}🧪 Testar Conexão com a IA Configurada${COLOR_RESET}                   ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}3${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_RED}🗑️ Remover Configuração de IA${COLOR_RESET}                              ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_RED}0${COLOR_RESET} ${COLOR_RED}➜${COLOR_RESET}  ${COLOR_WHITE}Voltar ao menu de Extras${COLOR_RESET}                                ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_YELLOW}  Digite sua opção ${COLOR_GRAY}(ou pressione ENTER para sair)${COLOR_YELLOW}: ${COLOR_RESET}"
    read -rsn1 opt
    while [ "$opt" != '' ]
    do
        if [[ $opt = "" ]]; then
             exit;
        else
            case $opt in
                1) run_ai_wizard
                   extras_ia_menu
                   ;;
                2) clear
                   if [ -z "$AI_KEY" ]; then
                       echo -e "${COLOR_RED}Nenhuma IA configurada para testar. Execute o assistente (opção 1).${COLOR_RESET}"
                   else
                       test_ai_connection "$AI_PROVIDER" "$AI_MODEL" "$AI_KEY"
                   fi
                   echo ""
                   read -p "Pressione ENTER para continuar..."
                   extras_ia_menu
                   ;;
                3) clear
                   if [ -f "$AI_CONFIG_FILE" ] || [ -f "$OPENAI_KEY_FILE" ]; then
                       read -p "Tem certeza que deseja remover as configurações de IA? (s/N): " conf
                       if [[ $conf =~ ^[Ss]$ ]]; then
                           rm -f "$AI_CONFIG_FILE" "$OPENAI_KEY_FILE"
                           echo -e "${COLOR_GREEN}✓ Configurações de IA removidas!${COLOR_RESET}"
                       fi
                   else
                       echo -e "${COLOR_YELLOW}Nenhuma configuração salva para remover.${COLOR_RESET}"
                   fi
                   sleep 2
                   extras_ia_menu
                   ;;
                0) clear;
                   extras_menu
                   ;;
                *) clear;
                   extras_menu
                   ;;
            esac
        fi
    done
}
