#!/bin/bash

# Submenu de Gerenciamento de Chaves de IA (Extras)
# Autor: TcTI-BR

OPENAI_KEY_FILE="/root/.openai_key"
GEMINI_KEY_FILE="/root/.gemini_key"
CLAUDE_KEY_FILE="/root/.claude_key"

show_masked_key() {
    local key=$1
    local key_length=${#key}
    if [ $key_length -gt 12 ]; then
        echo "${key:0:4}...${key: -4}"
    else
        echo "***"
    fi
}

manage_provider_key() {
    local provider_name="$1"
    local key_file="$2"
    local default_prefix="$3"
    local test_url="$4"
    local test_type="$5"

    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}"
    echo -e "╔═════════════════════════════════════════════════════════════════════╗"
    echo -e "║                                                                     ║"
    echo -e "║                🔑 Gerenciar Chave - $provider_name                   ║"
    echo -e "║                                                                     ║"
    echo -e "╚═════════════════════════════════════════════════════════════════════╝"
    echo -e "${COLOR_RESET}"
    echo ""

    if [ -f "$key_file" ]; then
        CURRENT_KEY=$(cat "$key_file")
        MASKED_KEY=$(show_masked_key "$CURRENT_KEY")
        echo -e "${COLOR_GREEN}  ✓ Chave $provider_name cadastrada${COLOR_RESET}"
        echo -e "${COLOR_WHITE}  Chave atual: ${COLOR_YELLOW}${MASKED_KEY}${COLOR_RESET}"
        echo ""
    else
        echo -e "${COLOR_RED}  ✗ Nenhuma chave $provider_name cadastrada${COLOR_RESET}"
        echo -e "${COLOR_YELLOW}  Cadastre uma chave para utilizar as integrações com $provider_name${COLOR_RESET}"
        echo ""
    fi

    echo -e "${COLOR_BOLD}  Selecione uma opção:${COLOR_RESET}"
    echo ""
    echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}1${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}Cadastrar/Atualizar chave${COLOR_RESET}                               ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}2${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}Deletar chave${COLOR_RESET}                                           ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}3${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}Testar conexão com a API${COLOR_RESET}                                ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_RED}0${COLOR_RESET} ${COLOR_RED}➜${COLOR_RESET}  ${COLOR_WHITE}Voltar${COLOR_RESET}                                                  ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_YELLOW}  Digite sua opção: ${COLOR_RESET}"
    read -rsn1 opt_sub

    case $opt_sub in
        1)
            clear
            echo -e "${COLOR_CYAN}${COLOR_BOLD}Cadastrar/Atualizar Chave $provider_name${COLOR_RESET}"
            echo -e "${COLOR_GRAY}(Formato comum: $default_prefix...)${COLOR_RESET}\n"
            read -p "Digite a chave API: " new_k
            if [ -z "$new_k" ]; then
                echo -e "${COLOR_RED}A chave não pode estar vazia!${COLOR_RESET}"
                sleep 2
                manage_provider_key "$provider_name" "$key_file" "$default_prefix" "$test_url" "$test_type"
                return
            fi
            echo "$new_k" > "$key_file"
            chmod 600 "$key_file"
            echo -e "${COLOR_GREEN}✓ Chave de $provider_name salva com sucesso!${COLOR_RESET}"
            sleep 2
            manage_provider_key "$provider_name" "$key_file" "$default_prefix" "$test_url" "$test_type"
            ;;
        2)
            if [ ! -f "$key_file" ]; then
                echo -e "${COLOR_RED}Nenhuma chave encontrada para deletar.${COLOR_RESET}"
                sleep 2
                manage_provider_key "$provider_name" "$key_file" "$default_prefix" "$test_url" "$test_type"
                return
            fi
            read -p "Tem certeza que deseja deletar a chave $provider_name? (s/N): " confirm
            if [[ $confirm =~ ^[Ss]$ ]]; then
                rm -f "$key_file"
                echo -e "${COLOR_GREEN}✓ Chave removida!${COLOR_RESET}"
                sleep 2
            fi
            manage_provider_key "$provider_name" "$key_file" "$default_prefix" "$test_url" "$test_type"
            ;;
        3)
            if [ ! -f "$key_file" ]; then
                echo -e "${COLOR_RED}Cadastre uma chave antes de testar.${COLOR_RESET}"
                sleep 2
                manage_provider_key "$provider_name" "$key_file" "$default_prefix" "$test_url" "$test_type"
                return
            fi
            echo -e "${COLOR_YELLOW}Testando conexão com a API de $provider_name...${COLOR_RESET}"
            k_val=$(cat "$key_file")
            if [ "$test_type" = "openai" ]; then
                code=$(curl -s -o /dev/null -w "%{http_code}" -H "Authorization: Bearer $k_val" "$test_url")
            elif [ "$test_type" = "gemini" ]; then
                code=$(curl -s -o /dev/null -w "%{http_code}" "${test_url}${k_val}")
            elif [ "$test_type" = "claude" ]; then
                code=$(curl -s -o /dev/null -w "%{http_code}" -H "x-api-key: $k_val" -H "anthropic-version: 2023-06-01" "$test_url")
            fi

            if [ "$code" = "200" ]; then
                echo -e "${COLOR_GREEN}✓ Conexão bem-sucedida! Chave API ativa e funcional (HTTP 200).${COLOR_RESET}"
            elif [ "$code" = "401" ] || [ "$code" = "403" ]; then
                echo -e "${COLOR_RED}✗ Falha na autenticação (HTTP $code). Verifique se a chave está correta.${COLOR_RESET}"
            else
                echo -e "${COLOR_YELLOW}⚠ Resposta da API: HTTP $code. Verifique sua conexão de rede.${COLOR_RESET}"
            fi
            echo ""
            read -p "Pressione ENTER para continuar..."
            manage_provider_key "$provider_name" "$key_file" "$default_prefix" "$test_url" "$test_type"
            ;;
        0)
            return
            ;;
        *)
            manage_provider_key "$provider_name" "$key_file" "$default_prefix" "$test_url" "$test_type"
            ;;
    esac
}

extras_ia_menu(){
    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}"
    echo -e "╔═════════════════════════════════════════════════════════════════════╗"
    echo -e "║                                                                     ║"
    echo -e "║            🔑 Assistente de Chaves de Inteligência Artificial      ║"
    echo -e "║                                                                     ║"
    echo -e "╚═════════════════════════════════════════════════════════════════════╝"
    echo -e "${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_BOLD}  Selecione o provedor de IA para configurar:${COLOR_RESET}"
    echo ""
    echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}1${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}OpenAI (ChatGPT / GPT-4o)${COLOR_RESET}                              ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}2${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}Google Gemini (Gemini Pro / Flash)${COLOR_RESET}                    ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}3${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}Anthropic (Claude 3.5 Sonnet / Haiku)${COLOR_RESET}                 ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_RED}0${COLOR_RESET} ${COLOR_RED}➜${COLOR_RESET}  ${COLOR_WHITE}Voltar ao menu de Extras${COLOR_RESET}                                ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_YELLOW}  Digite sua opção ${COLOR_GRAY}(ou pressione ENTER para sair)${COLOR_YELLOW}: ${COLOR_RESET}"
    read -rsn1 opt
    while [ "$opt" != '' ]
    do
        if [[ $opt = "" ]]; then
             exit;
        else
            case $opt in
                1) manage_provider_key "OpenAI" "$OPENAI_KEY_FILE" "sk-" "https://api.openai.com/v1/models" "openai"
                   extras_ia_menu
                   ;;
                2) manage_provider_key "Google Gemini" "$GEMINI_KEY_FILE" "AIzaSy..." "https://generativelanguage.googleapis.com/v1beta/models?key=" "gemini"
                   extras_ia_menu
                   ;;
                3) manage_provider_key "Anthropic Claude" "$CLAUDE_KEY_FILE" "sk-ant-..." "https://api.anthropic.com/v1/messages" "claude"
                   extras_ia_menu
                   ;;
                0) clear;
                   extras_menu
                   ;;
                *) clear;
                   extras_menu
                   ;;
            esac
        fi
    done
}
