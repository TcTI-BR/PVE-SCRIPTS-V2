#!/bin/bash

# Submenu de Ajustes do Sistema, Host e Monitoramento Térmico (Extras)
# Autor: TcTI-BR (Gerado via IA)

TEMP_DIR="/TcTI/SCRIPTS/monitoramento-temp"
TEMP_PY="$TEMP_DIR/pve_temp_monitor.py"
TEMP_CONF="$TEMP_DIR/config.ini"
TEMP_LOG="$TEMP_DIR/pve_temp_monitor.log"

instalar_dependencias_sensores() {
    if ! command -v sensors &>/dev/null || ! command -v ipmitool &>/dev/null; then
echo -e  "${LANG_AUTO_MENU_EXTRAS_SIS_142:-${COLOR_BLUE}${SYMBOL_LOADING} Garantindo presença das ferramentas de sensores (lm-sensors e ipmitool)...${COLOR_RESET}}"
        apt-get update -qq 2>/dev/null
        apt-get install -y -qq lm-sensors ipmitool 2>/dev/null
        sensors-detect --auto &>/dev/null
    fi
}

garantir_config_ini() {
    mkdir -p "$TEMP_DIR"
    if [ ! -f "$TEMP_CONF" ]; then
        cat > "$TEMP_CONF" << 'EOF'
[telegram]
enabled = true
bot_token = 
chat_id = 
timeout = 10

[ilo]
method = auto
target = ambient
host = 
user = 
password = 
sensor_name = Front Ambient
verify_ssl = false
timeout = 10

[thresholds]
warning_temp = 30.0
critical1_temp = 60.0
critical2_temp = 80.0
hysteresis = 2.0
consecutive_checks = 2

[actions]
critical1_vms = 100, 101
critical1_vm_shutdown_timeout = 30
critical2_shutdown_host = true
dry_run = false

[system]
log_file = /TcTI/SCRIPTS/monitoramento-temp/pve_temp_monitor.log
state_file = /TcTI/SCRIPTS/monitoramento-temp/state.json
hostname = 
EOF
        chmod 600 "$TEMP_CONF"
    fi
}

instalar_script_python_temp() {
    mkdir -p "$TEMP_DIR"
    
    local source_py="$SCRIPT_DIR/temp/pve_temp_monitor.py"
    if [ -f "$source_py" ]; then
        cp -f "$source_py" "$TEMP_PY"
        chmod +x "$TEMP_PY"
        return 0
    fi

    if [ ! -f "$TEMP_PY" ]; then
        cat << 'EOF' > "$TEMP_PY"
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys, os, time, json, logging, argparse, socket, subprocess, configparser, urllib.request, urllib.parse, ssl, shutil
from datetime import datetime

ENV_PATH = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
os.environ["PATH"] = ENV_PATH + ":" + os.environ.get("PATH", "")
BASE_DIR = "/TcTI/SCRIPTS/monitoramento-temp"

def resolve_cmd(name):
    found = shutil.which(name)
    if found: return found
    known = {"qm": "/usr/sbin/qm", "pct": "/usr/sbin/pct", "ipmitool": "/usr/bin/ipmitool", "sensors": "/usr/bin/sensors", "systemctl": "/bin/systemctl", "sync": "/bin/sync"}
    return known.get(name, name)

try:
    import fcntl
    HAS_FCNTL = True
except ImportError:
    HAS_FCNTL = False

DEFAULT_CONFIG_PATHS = [os.path.join(BASE_DIR, "config.ini")]
STATE_NORMAL, STATE_WARNING, STATE_CRITICAL1, STATE_CRITICAL2 = "NORMAL", "WARNING", "CRITICAL1", "CRITICAL2"
STATE_LEVELS = {STATE_NORMAL: 0, STATE_WARNING: 1, STATE_CRITICAL1: 2, STATE_CRITICAL2: 3}

class ConfigManager:
    def __init__(self, config_path=None):
        self.config = configparser.ConfigParser()
        self.path = config_path if config_path and os.path.exists(config_path) else os.path.join(BASE_DIR, "config.ini")
        if os.path.exists(self.path):
            self.config.read(self.path, encoding="utf-8")

    def get_telegram(self):
        enabled = self.config.getboolean("telegram", "enabled", fallback=True)
        bot_token = self.config.get("telegram", "bot_token", fallback="").strip()
        chat_id = self.config.get("telegram", "chat_id", fallback="").strip()
        notif_file = "/TcTI/SCRIPTS/telegram/.env_notificacoes"
        if (not bot_token or not chat_id) and os.path.exists(notif_file):
            try:
                with open(notif_file, "r") as f:
                    for line in f:
                        line = line.strip()
                        if line.startswith("NOTIF_BOT_TOKEN="): bot_token = line.split("=", 1)[1].strip('"\'')
                        elif line.startswith("NOTIF_CHAT_ID="): chat_id = line.split("=", 1)[1].strip('"\'')
            except Exception: pass
        return {"enabled": enabled, "bot_token": bot_token, "chat_id": chat_id, "timeout": 10}

    def get_ilo(self):
        return {"method": self.config.get("ilo", "method", fallback="auto").strip().lower(), "target": self.config.get("ilo", "target", fallback="ambient").strip().lower(), "host": self.config.get("ilo", "host", fallback="").strip(), "user": self.config.get("ilo", "user", fallback="").strip(), "password": self.config.get("ilo", "password", fallback="").strip(), "sensor_name": self.config.get("ilo", "sensor_name", fallback="Front Ambient").strip(), "verify_ssl": False, "timeout": 10}

    def get_thresholds(self):
        return {"warning_temp": self.config.getfloat("thresholds", "warning_temp", fallback=30.0), "critical1_temp": self.config.getfloat("thresholds", "critical1_temp", fallback=60.0), "critical2_temp": self.config.getfloat("thresholds", "critical2_temp", fallback=80.0), "hysteresis": self.config.getfloat("thresholds", "hysteresis", fallback=2.0), "consecutive_checks": self.config.getint("thresholds", "consecutive_checks", fallback=2)}

    def get_actions(self):
        vms_raw = self.config.get("actions", "critical1_vms", fallback="")
        vms_list = [v.strip() for v in vms_raw.replace(",", " ").split() if v.strip().isdigit()]
        return {"critical1_vms": vms_list, "critical1_vm_shutdown_timeout": 30, "critical2_shutdown_host": True, "dry_run": False}

    def get_system(self):
        return {"log_file": os.path.join(BASE_DIR, "pve_temp_monitor.log"), "state_file": os.path.join(BASE_DIR, "state.json"), "hostname": socket.gethostname()}

class TelegramNotifier:
    def __init__(self, config):
        self.cfg = config

    def send(self, message):
        if not self.cfg["enabled"] or not self.cfg["bot_token"] or not self.cfg["chat_id"]:
            return False
        url = f"https://api.telegram.org/bot{self.cfg['bot_token']}/sendMessage"
        payload = {"chat_id": self.cfg["chat_id"], "text": message, "parse_mode": "HTML"}
        try:
            data = json.dumps(payload).encode("utf-8")
            req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
            ctx = ssl.create_default_context()
            ctx.check_hostname, ctx.verify_mode = False, ssl.CERT_NONE
            with urllib.request.urlopen(req, timeout=10, context=ctx) as res:
                return res.status == 200
        except Exception: return False

class TempReader:
    def __init__(self, ilo_config):
        self.config = ilo_config
        self.method = ilo_config["method"]
        self.target = ilo_config.get("target", "ambient")

    def get_temperature(self):
        if self.method in ["ipmi_local", "auto", ""]:
            try:
                t, s = self._read_ipmi_smart()
                if t and t > 0: return t, s
            except Exception: pass
        if self.method in ["sensors", "auto", "ipmi_local", ""]:
            try:
                t, s = self._read_sensors_smart()
                if t and t > 0: return t, s
            except Exception: pass
        return self._read_sysfs()

    def _read_ipmi_smart(self):
        ipmi_bin = shutil.which("ipmitool")
        if not ipmi_bin: raise RuntimeError("ipmitool não instalado")
        cmd = [ipmi_bin, "sdr", "type", "Temperature"]
        res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, check=True)
        ambient_temps, cpu_temps = [], []
        for line in res.stdout.splitlines():
            parts = [p.strip() for p in line.split("|")]
            if len(parts) >= 5 and parts[2].lower() == "ok":
                try:
                    val = float(parts[4].split()[0])
                    name = parts[0]
                    name_l = name.lower()
                    if any(k in name_l for k in ["front ambient", "inlet ambient", "ambient", "sys temp", "system temp", "inlet"]):
                        ambient_temps.append((val, name))
                    elif any(k in name_l for k in ["cpu 1", "cpu 2", "cpu", "processor"]):
                        cpu_temps.append((val, name))
                except Exception: pass

        if self.target == "ambient":
            if ambient_temps:
                ambient_temps.sort(key=lambda x: x[0], reverse=True)
                return ambient_temps[0][0], ambient_temps[0][1]
            elif cpu_temps:
                cpu_temps.sort(key=lambda x: x[0], reverse=True)
                return cpu_temps[0][0], cpu_temps[0][1]
        elif self.target == "cpu" and cpu_temps:
            cpu_temps.sort(key=lambda x: x[0], reverse=True)
            return cpu_temps[0][0], cpu_temps[0][1]

        raise RuntimeError("Nenhum sensor IPMI válido.")

    def _read_sensors_smart(self):
        sensors_bin = shutil.which("sensors")
        if not sensors_bin: raise RuntimeError("sensors não instalado")
        res = subprocess.run([sensors_bin], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, check=True)
        curr_adapter, cpu_temps, ambient_temps = "", [], []
        for line in res.stdout.splitlines():
            line_str = line.strip()
            if not line_str: continue
            if not line.startswith(" ") and ":" not in line:
                curr_adapter = line_str.lower()
                continue
            if any(ign in curr_adapter for ign in ["tg3", "e1000", "iwlwifi", "amdgpu", "nouveau"]):
                continue
            if "°C" in line_str:
                parts = line_str.split(":")
                label = parts[0].strip().lower() if len(parts) > 1 else ""
                val_part = parts[1] if len(parts) > 1 else line_str
                for p in val_part.split():
                    if "°C" in p:
                        try:
                            val = float(p.replace("+", "").replace("°C", "").replace(",", "."))
                            if 0 < val < 120:
                                if "package" in label or "core" in label or "cpu" in label:
                                    cpu_temps.append((val, f"{curr_adapter} ({label})"))
                                elif "ambient" in label or "temp1" in label or "sys" in label:
                                    ambient_temps.append((val, f"{curr_adapter} ({label})"))
                        except ValueError: pass
        if cpu_temps:
            cpu_temps.sort(key=lambda x: x[0], reverse=True)
            return cpu_temps[0][0], cpu_temps[0][1]
        elif ambient_temps:
            ambient_temps.sort(key=lambda x: x[0], reverse=True)
            return ambient_temps[0][0], ambient_temps[0][1]
        raise RuntimeError("Nenhum sensor de CPU no lm-sensors.")

    def _read_sysfs(self):
        thermal_dir = "/sys/class/thermal"
        if os.path.exists(thermal_dir):
            for zone in os.listdir(thermal_dir):
                if zone.startswith("thermal_zone"):
                    t_path = os.path.join(thermal_dir, zone, "type")
                    val_path = os.path.join(thermal_dir, zone, "temp")
                    z_type = open(t_path).read().strip().lower() if os.path.exists(t_path) else ""
                    if any(ign in z_type for ign in ["tg3", "wifi", "nvme", "gpu"]): continue
                    if os.path.exists(val_path):
                        try:
                            val = float(open(val_path).read().strip())
                            if val > 1000: val = val / 1000.0
                            if 0 < val < 120: return val, f"Sysfs {zone} ({z_type})"
                        except Exception: pass
        raise RuntimeError("Nenhum sensor acessível.")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default=None)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--test", action="store_true")
    parser.add_argument("--read-temp", action="store_true")
    parser.add_argument("--simulate-temp", type=float)
    args = parser.parse_args()

    cfg = ConfigManager(args.config)
    if args.read_temp:
        try:
            r = TempReader(cfg.get_ilo())
            temp, s_name = r.get_temperature()
            print(f"{temp:.1f}°C ({s_name})")
            sys.exit(0)
        except Exception as e:
            print(f"Erro: {e}")
            sys.exit(1)

    sys_cfg = cfg.get_system()
    os.makedirs(os.path.dirname(sys_cfg["log_file"]), exist_ok=True)
    logging.basicConfig(filename=sys_cfg["log_file"], level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
    
    notifier = TelegramNotifier(cfg.get_telegram())
    reader = TempReader(cfg.get_ilo())
    
    if args.test:
        print(f"Lendo temperatura...")
        try:
            t, s_name = reader.get_temperature()
            print(f"Temperatura: {t:.1f}°C (Sensor: {s_name})")
        except Exception as e: print(f"Erro: {e}")
        print("Enviando notificação de teste...")
        if notifier.send("🧪 Teste de Monitoramento Térmico PVE"): print("✓ Enviado com sucesso!")
        else: print("✗ Falha no envio do Telegram.")
        sys.exit(0)

    try:
        temp, s_name = (args.simulate_temp, "Simulação") if args.simulate_temp is not None else reader.get_temperature()
        logging.info(f"Temperatura lida: {temp:.1f}°C ({s_name})")
    except Exception as e:
        logging.error(f"Erro de leitura: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
EOF
        chmod +x "$TEMP_PY"
    fi
}

editar_config_ini_menu() {
    garantir_config_ini
    while true; do
        clear
        echo -e "${COLOR_CYAN}${COLOR_BOLD}"
        echo -e "╔═════════════════════════════════════════════════════════════════════╗"
        ui_print_header_line "" "" 69
        ui_print_header_line "⚙️  ${LANG_EXT_SYS_TITLE:-Configurar Parâmetros de Temperatura}" "${COLOR_WHITE}" 69
        ui_print_header_line "" "" 69
        echo -e "╚═════════════════════════════════════════════════════════════════════╝"
        echo -e "${COLOR_RESET}"
        echo ""

        local w_temp=$(grep -E "^warning_temp" "$TEMP_CONF" | cut -d'=' -f2 | tr -d ' ')
        local c1_temp=$(grep -E "^critical1_temp" "$TEMP_CONF" | cut -d'=' -f2 | tr -d ' ')
        local c1_vms=$(grep -E "^critical1_vms" "$TEMP_CONF" | cut -d'=' -f2 | tr -d ' ')
        local c2_temp=$(grep -E "^critical2_temp" "$TEMP_CONF" | cut -d'=' -f2 | tr -d ' ')
        local sensor_method=$(grep -E "^method" "$TEMP_CONF" | cut -d'=' -f2 | tr -d ' ')
        local sensor_target=$(grep -E "^target" "$TEMP_CONF" | cut -d'=' -f2 | tr -d ' ')

        echo -e "  ${COLOR_WHITE}${LANG_EXTRAS_SYS_FILE:-Arquivo: }${COLOR_YELLOW}${TEMP_CONF}${COLOR_RESET}\n"
        echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
        ui_print_menu_item "1" "${LANG_EXT_SYS_OPT1:-Otimizar CPU Scaling Governor (Performance)}"
        ui_print_menu_item "2" "${LANG_EXT_SYS_OPT2:-Instalar Microcode de CPU (Intel/AMD)}"
        ui_print_menu_item "3" "${LANG_EXT_SYS_OPT3:-Configurar Swappiness}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_SIS_143:-  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}4${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}Temp. Crítica 2 (Desliga Host) [Atual: ${c2_temp:-80}°C]${COLOR_RESET}          ${COLOR_CYAN}│${COLOR_RESET}}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_SIS_144:-  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}5${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}Foco do Alvo [Atual: ${sensor_target:-ambient} (Ar/Sala vs CPU)]${COLOR_RESET} ${COLOR_CYAN}│${COLOR_RESET}}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_SIS_145:-  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}6${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}Método do Sensor [Atual: ${sensor_method:-auto}]${COLOR_RESET}                    ${COLOR_CYAN}│${COLOR_RESET}}"
        echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
        ui_print_menu_item "0" "${LANG_VM_OP_OPT_0:-Voltar}" "${COLOR_RED}"
        echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
        echo ""
        echo -e "${COLOR_YELLOW}  ${LANG_EXTRAS_TYPE_OPT:-Digite sua opção} ${COLOR_GRAY}${LANG_EXTRAS_OR_EXIT:-(ou pressione ENTER para sair)}${COLOR_YELLOW}: ${COLOR_RESET}"
        read -rsn1 opt

        case "$opt" in
            1)
                clear
                read -p "${LANG_EXTRAS_SYS_NEW_WARN:-Digite a nova temperatura de Alerta (Warning ex: 30): }" n_w
                if [[ -n "$n_w" ]]; then
                    sed -i "s/^warning_temp =.*/warning_temp = $n_w.0/" "$TEMP_CONF"
echo -e  "${LANG_AUTO_MENU_EXTRAS_SIS_146:-${COLOR_GREEN}✓ Temperatura de alerta atualizada para ${n_w}°C!${COLOR_RESET}}"
                    sleep 2
                fi
                ;;
            2)
                clear
                read -p "${LANG_EXTRAS_SYS_NEW_CRIT1:-Digite a temperatura Crítica 1 (Desligar VMs ex: 60): }" n_c1
                if [[ -n "$n_c1" ]]; then
                    sed -i "s/^critical1_temp =.*/critical1_temp = $n_c1.0/" "$TEMP_CONF"
echo -e  "${LANG_AUTO_MENU_EXTRAS_SIS_147:-${COLOR_GREEN}✓ Temperatura Crítica 1 atualizada para ${n_c1}°C!${COLOR_RESET}}"
                    sleep 2
                fi
                ;;
            3)
                clear
echo -e  "${LANG_AUTO_MENU_EXTRAS_SIS_148:-IDs de VMs ativas no Proxmox:}"
                qm list 2>/dev/null | tail -n +2 | awk '{print "  • VM " $1 ": " $2}'
                echo ""
                read -p "${LANG_EXTRAS_SYS_VMS_SHUT:-Digite os IDs das VMs para desligar no Crítico 1 (ex: 100, 101): }" n_vms
                if [[ -n "$n_vms" ]]; then
                    sed -i "s/^critical1_vms =.*/critical1_vms = $n_vms/" "$TEMP_CONF"
                    echo -e "${COLOR_GREEN}✓ ${LANG_EXTRAS_SYS_VMS_UPD:-Lista de VMs atualizada com sucesso!}${COLOR_RESET}"
                    sleep 2
                fi
                ;;
            4)
                clear
                read -p "${LANG_EXTRAS_SYS_NEW_CRIT2:-Digite a temperatura Crítica 2 (Desligar Host ex: 80): }" n_c2
                if [[ -n "$n_c2" ]]; then
                    sed -i "s/^critical2_temp =.*/critical2_temp = $n_c2.0/" "$TEMP_CONF"
echo -e  "${LANG_AUTO_MENU_EXTRAS_SIS_149:-${COLOR_GREEN}✓ Temperatura Crítica 2 atualizada para ${n_c2}°C!${COLOR_RESET}}"
                    sleep 2
                fi
                ;;
            5)
                clear
                echo -e "${LANG_EXTRAS_SYS_SEL_READ:-Selecione o Foco da Leitura de Temperatura:}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_SIS_150:-1) ambient (Recomendado para Ar Condicionado: Front Ambient / Inlet Temp - ex: 28°C)}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_SIS_151:-2) cpu (Monitorar diretamente a Temperatura do Processador - ex: 40°C - 49°C)}"
read -p  "${LANG_AUTO_MENU_EXTRAS_SIS_152:-Escolha (1 ou 2): }" t_opt
                if [ "$t_opt" == "1" ]; then
                    sed -i "s/^target =.*/target = ambient/" "$TEMP_CONF"
echo -e  "${LANG_AUTO_MENU_EXTRAS_SIS_153:-${COLOR_GREEN}✓ Foco alterado para Temperatura Ambiental da Sala!${COLOR_RESET}}"
                elif [ "$t_opt" == "2" ]; then
                    sed -i "s/^target =.*/target = cpu/" "$TEMP_CONF"
echo -e  "${LANG_AUTO_MENU_EXTRAS_SIS_154:-${COLOR_GREEN}✓ Foco alterado para Temperatura do Processador (CPU)!${COLOR_RESET}}"
                fi
                sleep 2
                ;;
            6)
                clear
                echo -e "${LANG_EXTRAS_SYS_SEL_SENS:-Selecione o Método de Leitura do Sensor:}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_SIS_155:-1) auto (Automático com Filtro Inteligente: IPMI -> lm-sensors -> Sysfs)}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_SIS_156:-2) ipmi_local (Forçar HPE iLO / IPMI local)}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_SIS_157:-3) sensors (Forçar lm-sensors / Sensores da placa-mãe)}"
read -p  "${LANG_AUTO_MENU_EXTRAS_SIS_158:-Escolha (1, 2 ou 3): }" m_opt
                if [ "$m_opt" == "1" ]; then
                    sed -i "s/^method =.*/method = auto/" "$TEMP_CONF"
echo -e  "${LANG_AUTO_MENU_EXTRAS_SIS_159:-${COLOR_GREEN}✓ Método alterado para Automático!${COLOR_RESET}}"
                elif [ "$m_opt" == "2" ]; then
                    sed -i "s/^method =.*/method = ipmi_local/" "$TEMP_CONF"
echo -e  "${LANG_AUTO_MENU_EXTRAS_SIS_160:-${COLOR_GREEN}✓ Método alterado para ipmi_local!${COLOR_RESET}}"
                elif [ "$m_opt" == "3" ]; then
                    sed -i "s/^method =.*/method = sensors/" "$TEMP_CONF"
echo -e  "${LANG_AUTO_MENU_EXTRAS_SIS_161:-${COLOR_GREEN}✓ Método alterado para sensors!${COLOR_RESET}}"
                fi
                sleep 2
                ;;
            0|"")
                return 0
                ;;
            *)
                ;;
        esac
    done
}

simular_testes_temperatura_menu() {
    while true; do
        clear
        echo -e "${COLOR_CYAN}${COLOR_BOLD}"
        echo -e "╔═════════════════════════════════════════════════════════════════════╗"
        ui_print_header_line "" "" 69
        ui_print_header_line "🧪 Simulações e Testes de Temperatura (Dry-Run)" "${COLOR_WHITE}" 69
        ui_print_header_line "" "" 69
        echo -e "╚═════════════════════════════════════════════════════════════════════╝"
        echo -e "${COLOR_RESET}"
        echo ""
        echo -e "${COLOR_WHITE}${LANG_EXTRAS_SYS_DRY_RUN:-Nenhum desligamento real é efetuado no modo de simulação (Dry-Run).}${COLOR_RESET}\n"

        echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
        ui_print_menu_item "1" "${LANG_TEMP_SIM_OPT1:-Executar teste de leitura do sensor}"
        ui_print_menu_item "2" "${LANG_TEMP_SIM_OPT2:-Simular 65°C (Aviso Telegram / Soft Limit)}"
        ui_print_menu_item "3" "${LANG_TEMP_SIM_OPT3:-Simular 82°C (Desligamento / Hard Limit)}"
        echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
        ui_print_menu_item "0" "${LANG_VM_OP_OPT_0:-Voltar}" "${COLOR_RED}"
        echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
        echo ""
        echo -e "${COLOR_YELLOW}  ${LANG_EXTRAS_TYPE_OPT:-Digite sua opção} ${COLOR_GRAY}${LANG_EXTRAS_OR_EXIT:-(ou pressione ENTER para sair)}${COLOR_YELLOW}: ${COLOR_RESET}"
        read -rsn1 opt

        case "$opt" in
            1)
                clear
echo -e  "${LANG_AUTO_MENU_EXTRAS_SIS_162:-${COLOR_YELLOW}Executando teste de leitura e envio...${COLOR_RESET}\n}"
                python3 "$TEMP_PY" --test
                echo ""
read -p  "${LANG_AUTO_MENU_EXTRAS_SIS_163:-Pressione ENTER para continuar...}"
                ;;
            2)
                clear
echo -e  "${LANG_AUTO_MENU_EXTRAS_SIS_164:-${COLOR_YELLOW}Simulando 65°C no modo Dry-Run (Sem desligar VMs reais)...${COLOR_RESET}\n}"
                python3 "$TEMP_PY" --simulate-temp 65 --dry-run
                echo ""
read -p  "${LANG_AUTO_MENU_EXTRAS_SIS_165:-Pressione ENTER para continuar...}"
                ;;
            3)
                clear
echo -e  "${LANG_AUTO_MENU_EXTRAS_SIS_166:-${COLOR_YELLOW}Simulando 82°C no modo Dry-Run (Sem desligar o Host real)...${COLOR_RESET}\n}"
                python3 "$TEMP_PY" --simulate-temp 82 --dry-run
                echo ""
read -p  "${LANG_AUTO_MENU_EXTRAS_SIS_167:-Pressione ENTER para continuar...}"
                ;;
            0|"")
                return 0
                ;;
            *)
                ;;
        esac
    done
}

menu_monitoramento_temperatura() {
    mkdir -p "$TEMP_DIR"
    instalar_dependencias_sensores
    instalar_script_python_temp
    garantir_config_ini

    while true; do
        clear
        echo -e "${COLOR_CYAN}${COLOR_BOLD}"
        echo -e "╔═════════════════════════════════════════════════════════════════════╗"
        ui_print_header_line "" "" 69
        ui_print_header_line "🔥 Monitoramento Térmico & Proteção de Hardware" "${COLOR_WHITE}" 69
        ui_print_header_line "" "" 69
        echo -e "╚═════════════════════════════════════════════════════════════════════╝"
        echo -e "${COLOR_RESET}"
        echo ""

        if crontab -l 2>/dev/null | grep -q "pve_temp_monitor.py"; then
echo -e  "${LANG_AUTO_MENU_EXTRAS_SIS_168:-  ${COLOR_WHITE}Status Monitoramento (Cron): ${COLOR_GREEN}${SYMBOL_CHECK} Ativo (crontab do root)${COLOR_RESET}}"
        else
echo -e  "${LANG_AUTO_MENU_EXTRAS_SIS_169:-  ${COLOR_WHITE}Status Monitoramento (Cron): ${COLOR_GRAY}Não agendado${COLOR_RESET}}"
        fi

        if [ -f "/TcTI/SCRIPTS/telegram/.env_notificacoes" ]; then
            source "/TcTI/SCRIPTS/telegram/.env_notificacoes" 2>/dev/null
echo -e  "${LANG_AUTO_MENU_EXTRAS_SIS_170:-  ${COLOR_WHITE}Telegram Notificações: ${COLOR_GREEN}${SYMBOL_CHECK} Conectado (${NOTIF_SERVER_NAME})${COLOR_RESET}}"
        else
echo -e  "${LANG_AUTO_MENU_EXTRAS_SIS_171:-  ${COLOR_WHITE}Telegram Notificações: ${COLOR_YELLOW}⚠️ Não configurado (Menu 3->7->1->2)${COLOR_RESET}}"
        fi

        if [ -f "$TEMP_PY" ]; then
            temp_now=$(python3 "$TEMP_PY" --read-temp 2>/dev/null)
            if [ -n "$temp_now" ]; then
echo -e  "${LANG_AUTO_MENU_EXTRAS_SIS_172:-  ${COLOR_WHITE}Temperatura Atual do Host: ${COLOR_CYAN}${temp_now}${COLOR_RESET}}"
            fi
        fi
        echo ""
echo -e  "${LANG_AUTO_MENU_EXTRAS_SIS_173:-${COLOR_BOLD}  Selecione a opção desejada:${COLOR_RESET}}"
        echo ""
        echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_SIS_173_1:-  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}1${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}🌡️  Leitura Instantânea de Sensores${COLOR_RESET}                      ${COLOR_CYAN}│${COLOR_RESET}}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_SIS_173_2:-  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}2${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_GREEN}🟢 Ativar Monitoramento no Cron${COLOR_RESET}                         ${COLOR_CYAN}│${COLOR_RESET}}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_SIS_174:-  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}3${COLOR_RESET} ${COLOR_RED}➜${COLOR_RESET}  ${COLOR_RED}🛑 Desativar Monitoramento do Cron${COLOR_RESET}                       ${COLOR_CYAN}│${COLOR_RESET}}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_SIS_175:-  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}4${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}⚙️  Editar Parâmetros (Limites, VMs e Sensores)${COLOR_RESET}          ${COLOR_CYAN}│${COLOR_RESET}}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_SIS_176:-  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}5${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}🧪 Simular Alertas de Temperatura (Modo Teste/Dry-Run)${COLOR_RESET}   ${COLOR_CYAN}│${COLOR_RESET}}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_SIS_177:-  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}6${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}📜 Ver Logs do Monitoramento Térmico${COLOR_RESET}                     ${COLOR_CYAN}│${COLOR_RESET}}"
        echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
        ui_print_menu_item "0" "${LANG_VM_OP_OPT_0:-Voltar}" "${COLOR_RED}"
        echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
        echo ""
        echo -e "${COLOR_YELLOW}  ${LANG_EXTRAS_TYPE_OPT:-Digite sua opção} ${COLOR_GRAY}${LANG_EXTRAS_OR_EXIT:-(ou pressione ENTER para sair)}${COLOR_YELLOW}: ${COLOR_RESET}"
        read -rsn1 opt

        case "$opt" in
            1)
                clear
echo -e  "${LANG_AUTO_MENU_EXTRAS_SIS_178:-${COLOR_CYAN}${COLOR_BOLD}Leitura Instantânea de Sensores / iLO:${COLOR_RESET}\n}"
                if command -v sensors &>/dev/null; then
                    sensors
                fi
                echo ""
                if [ -f "$TEMP_PY" ]; then
                    python3 "$TEMP_PY" --test
                fi
                echo ""
read -p  "${LANG_AUTO_MENU_EXTRAS_SIS_179:-Pressione ENTER para continuar...}"
                ;;
            2)
                clear
echo -e  "${LANG_AUTO_MENU_EXTRAS_SIS_180:-${COLOR_GREEN}${COLOR_BOLD}Ativando Monitoramento Térmico no Crontab do Root...${COLOR_RESET}\n}"
                garantir_config_ini
                (crontab -l 2>/dev/null | grep -v "pve_temp_monitor.py"; echo "*/2 * * * * /usr/bin/python3 $TEMP_PY > /dev/null 2>&1") | crontab -
                echo -e "${COLOR_GREEN}✓ ${LANG_EXTRAS_SYS_CRON_SUC:-Tarefa agendada com sucesso a cada 2 minutos no 'crontab -e'!}${COLOR_RESET}"
                sleep 2
                ;;
            3)
                clear
                echo -e "${COLOR_YELLOW}${COLOR_BOLD}${LANG_EXTRAS_SYS_CRON_REM:-Removendo Monitoramento do Crontab do Root...}${COLOR_RESET}\n"
                crontab -l 2>/dev/null | grep -v "pve_temp_monitor.py" | crontab -
echo -e  "${LANG_AUTO_MENU_EXTRAS_SIS_181:-${COLOR_GREEN}✓ Monitoramento removido do crontab!${COLOR_RESET}}"
                sleep 2
                ;;
            4)
                editar_config_ini_menu
                ;;
            5)
                simular_testes_temperatura_menu
                ;;
            6)
                clear
echo -e  "${LANG_AUTO_MENU_EXTRAS_SIS_182:-${COLOR_CYAN}${COLOR_BOLD}Logs de Monitoramento Térmico ($TEMP_LOG):${COLOR_RESET}\n}"
                if [ -f "$TEMP_LOG" ]; then
                    tail -n 30 -f "$TEMP_LOG"
                else
                    echo -e "${COLOR_YELLOW}${LANG_EXTRAS_SYS_NO_LOG:-Nenhum log gerado ainda.}${COLOR_RESET}"
                    sleep 2
                fi
                ;;
            0|"")
                clear
                return 0
                ;;
            *)
                ;;
        esac
    done
}

extras_sistema_menu() {
    while true; do
        clear
        echo -e "${COLOR_CYAN}${COLOR_BOLD}"
        echo -e "╔═════════════════════════════════════════════════════════════════════╗"
        ui_print_header_line "" "" 69
        ui_print_header_line "⚙️  ${LANG_EXT_SYS_TITLE:-${LANG_EXTRAS_SYS_MENU_TITLE:-Ajustes de Sistema, Host e Watchdog}}" "${COLOR_WHITE}" 69
        ui_print_header_line "" "" 69
        echo -e "╚═════════════════════════════════════════════════════════════════════╝"
        echo -e "${COLOR_RESET}"
        echo ""
        echo -e "${COLOR_BOLD}  ${LANG_SELECT_OPT:-Selecione uma opção:}${COLOR_RESET}"
        echo ""
        echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
        
        ui_print_menu_item "1" "${LANG_EXTRAS_SYS_MENU_OPT_1:-🔥 Monitoramento Térmico e Proteção de Hardware}" "${COLOR_YELLOW}"
        ui_print_menu_item "2" "${LANG_EXTRAS_SYS_MENU_OPT_2:-Configurar SWAP (swappiness)}" "${COLOR_YELLOW}"
        ui_print_menu_item "3" "${LANG_EXTRAS_SYS_MENU_OPT_3:-Informações de desempenho do Host}" "${COLOR_YELLOW}"
        ui_print_menu_item "4" "${LANG_EXTRAS_SYS_MENU_OPT_4:-Instalar/desinstalar script na inicialização do shell}" "${COLOR_YELLOW}"
        ui_print_menu_item "5" "${LANG_EXTRAS_SYS_MENU_OPT_5:-Configuração do Watchdog de VMs (Auto-restart via Ping)}" "${COLOR_YELLOW}"
        
        echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
        
        ui_print_menu_item "0" "${LANG_VM_OP_OPT_0:-Voltar}" "${COLOR_RED}"
        
        echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
        echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
        echo ""
        echo -e "${COLOR_YELLOW}  ${LANG_TYPE_OPT:-Digite sua opção} ${COLOR_GRAY}${LANG_PRESS_ENTER:-(ou pressione ENTER para sair)}${COLOR_YELLOW}: ${COLOR_RESET}"
        read -rsn1 opt

        case "$opt" in
            1) menu_monitoramento_temperatura ;;
            2) clear
               lsblk | grep -qi swap
               swapenabled=$?
               if [ $swapenabled -eq 0 ]; then
read -p  "${LANG_AUTO_MENU_EXTRAS_SIS_183:-- Gostaria de editar ou desativar o swap? s = sim / n = não: }" -n 1 -r
                   if [[ $REPLY =~ ^[Ss]$ ]]; then
                       swapvalue=$(cat /proc/sys/vm/swappiness)
                       echo ""
echo "${LANG_AUTO_MENU_EXTRAS_SIS_184:-- Swap está definido como $swapvalue}"
echo "${LANG_AUTO_MENU_EXTRAS_SIS_185:-- Valor recomendado: 1 (menos uso de swap - apenas em extrema necessidade)}"
                       echo ""
                       echo "- ${LANG_EXTRAS_SYS_SWAP_NEW:-Qual é o novo valor de swap? (0 a 100): }"
                       read newswapvalue
echo "${LANG_AUTO_MENU_EXTRAS_SIS_186:-- Configurando o swap para $newswapvalue}"
                       sysctl vm.swappiness=$newswapvalue
echo "${LANG_AUTO_MENU_EXTRAS_SIS_187:-vm.swappiness=$newswapvalue}" > /etc/sysctl.d/swappiness.conf
echo "${LANG_AUTO_MENU_EXTRAS_SIS_188:-- Esvaziando o swap (pode levar alguns instantes)...}"
                       swapoff -a
                       swapon -a
                       echo "- ${LANG_EXTRAS_SYS_SWAP_SUC:-Finalizado com sucesso!}"
                       sleep 2
                   fi
               else
echo "${LANG_AUTO_MENU_EXTRAS_SIS_189:-- Swap não está ativado neste sistema.}"
                   sleep 2
               fi
               ;;
            3) clear
echo -e  "${LANG_AUTO_MENU_EXTRAS_SIS_190:-${COLOR_CYAN}${COLOR_BOLD}Informações de desempenho do Host Proxmox:${COLOR_RESET}\n}"
               uptime
               echo ""
               free -h
               echo ""
               df -h /
               echo ""
read -p  "${LANG_AUTO_MENU_EXTRAS_SIS_191:-Pressione ENTER para continuar...}"
               ;;
            4) clear
               instalar_script_inicializacao
               ;;
            5) clear
               watch_dog
               ;;
            0|"") clear
               extras_menu
               return
               ;;
            *)
               ;;
        esac
    done
}

instalar_script_inicializacao() {
    if [ -f "/etc/profile.d/proxmox-ini.sh" ]; then
echo -e  "${LANG_AUTO_MENU_EXTRAS_SIS_192:-${COLOR_YELLOW}O script já está configurado na inicialização.${COLOR_RESET}}"
        read -p "${LANG_EXTRAS_SYS_REM_BOOT:-Deseja remover da inicialização? (s/N): }" rem
        if [[ $rem =~ ^[Ss]$ ]]; then
            rm -f /etc/profile.d/proxmox-ini.sh
echo -e  "${LANG_AUTO_MENU_EXTRAS_SIS_193:-${COLOR_GREEN}✓ Script removido da inicialização.${COLOR_RESET}}"
            sleep 2
        fi
    else
        echo -e "$SCRIPT_DIR/main.sh" > /etc/profile.d/proxmox-ini.sh
        chmod +x /etc/profile.d/proxmox-ini.sh
echo -e  "${LANG_AUTO_MENU_EXTRAS_SIS_195:-${COLOR_GREEN}✓ Script adicionado na inicialização do shell!${COLOR_RESET}}"
        sleep 2
    fi
}
