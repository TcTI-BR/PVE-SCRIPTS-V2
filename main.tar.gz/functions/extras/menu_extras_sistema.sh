#!/bin/bash

# Submenu de Ajustes do Sistema e Host (Extras)
# Autor: TcTI-BR

extras_sistema_menu(){
    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}"
    echo -e "╔═════════════════════════════════════════════════════════════════════╗"
    echo -e "║                                                                     ║"
    echo -e "║                ⚙️  Ajustes de Sistema, Host e Watchdog              ║"
    echo -e "║                                                                     ║"
    echo -e "╚═════════════════════════════════════════════════════════════════════╝"
    echo -e "${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_BOLD}  Selecione uma opção:${COLOR_RESET}"
    echo ""
    echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}1${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}Verifica temperatura do hardware${COLOR_RESET}                       ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}2${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}Configura SWAP (swappiness)${COLOR_RESET}                             ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}3${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}Informações de desempenho do Host${COLOR_RESET}                       ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}4${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}Instala/desinstala script na inicialização do shell${COLOR_RESET}      ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}5${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}Configuração do Watchdog de VMs (Auto-restart via Ping)${COLOR_RESET} ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_RED}0${COLOR_RESET} ${COLOR_RED}➜${COLOR_RESET}  ${COLOR_WHITE}Voltar ao menu de Extras${COLOR_RESET}                                ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_YELLOW}  Digite sua opção ${COLOR_GRAY}(ou pressione ENTER para sair)${COLOR_YELLOW}: ${COLOR_RESET}"
    read -rsn1 opt
    while [ "$opt" != '' ]
    do
        if [[ $opt = "" ]]; then
             exit;
        else
            case $opt in
                1) clear
                apt install lm-sensors -y 2>/dev/null
                watch -n 1 sensors
                clear
                extras_sistema_menu
                    ;;
                2) clear;
                lsblk | grep -qi swap
                swapenabled=$?
                if [ $swapenabled -eq 0 ]; then
                    read -p "- Gostaria de editar ou desativar o swap? s = sim / n = não: " -n 1 -r
                    if [[ $REPLY =~ ^[Ss]$ ]]; then
                        swapvalue=$(cat /proc/sys/vm/swappiness)
                        echo ""
                        echo "- Swap está definido como $swapvalue"
                        echo "- Valor recomendado: 1 (menos uso de swap - apenas em extrema necessidade)"
                        echo ""
                        echo "- Qual é o novo valor de swap? (0 a 100): "
                        read newswapvalue
                        echo "- Configurando o swap para $newswapvalue"
                        sysctl vm.swappiness=$newswapvalue
                        echo "vm.swappiness=$newswapvalue" > /etc/sysctl.d/swappiness.conf
                        echo "- Esvaziando o swap (pode levar alguns instantes)..."
                        swapoff -a
                        echo "- Re-habilitando o swap..." 
                        swapon -a
                        sleep 2
                    fi
                else
                    echo "- O sistema não possui partição/arquivo de swap ativo."
                fi
                read -p "Pressione uma tecla para continuar..."
                extras_sistema_menu
                    ;;
                3) clear;
                red="\e[31m"
                default="\e[39m"
                white="\e[97m"
                green="\e[32m"
                date_str=`date`
                load=`cat /proc/loadavg | awk '{print $1}'`
                memory_usage=`free -m | awk '/Mem:/ { total=$2; used=$3 } END { printf("%3.1f%%", used/total*100)}'`
                users_cnt=`users | wc -w`
                uptime_str=`uptime | grep -ohe 'up .*' | sed 's/,/\ hours/g' | awk '{ printf $2" "$3 }'`
                processes=`ps aux | wc -l`
                ip_addr=`hostname -I | awk '{print $1}'`
                root_usage=`df -h / | awk '/\// {print $(NF-1)}'`
                root_free_space=`df -h / | awk '/\// {print $(NF-4)}'`
                echo -e "${green}Informações do Sistema em: ${white}$date_str${COLOR_RESET}\n"
                printf "${red}System Load${white}:${default}\t%s\t${red}IP Address${white}:${default}\t%s\n" "$load" "$ip_addr"
                printf "${red}Memory Usage${white}:${default}\t%s\t${red}System Uptime${white}:${default}\t%s\n" "$memory_usage" "$uptime_str"
                printf "${red}Local Users${white}:${default}\t%s\t${red}Processes${white}:${default}\t%s\n" "$users_cnt" "$processes"
                echo ""
                echo -e "${green}Informações de Disco / (Root):${white}${COLOR_RESET}\n"
                printf "${red}Uso em /${white}:${default}\t\t%s\t${red}Espaço Livre em /${white}:${default}\t%s\n" "$root_usage" "$root_free_space"
                echo ""
                read -p "Pressione uma tecla para continuar..."
                clear
                extras_sistema_menu 
                    ;;
                4) clear;
                if [ -f /etc/profile.d/tcti-proxmox-auto.sh ]; then
                    echo -e "${COLOR_YELLOW}O script de auto-inicialização já está INSTALADO.${COLOR_RESET}"
                    read -p "- Deseja DESINSTALAR o carregamento automático? s = sim / n = não: " -n 1 -r
                    if [[ $REPLY =~ ^[Ss]$ ]]; then
                        rm -f /etc/profile.d/tcti-proxmox-auto.sh
                        echo ""
                        echo -e "${COLOR_GREEN}✓ Script removido! O menu não será mais executado no login.${COLOR_RESET}"
                    fi
                else
                    echo -e "${COLOR_CYAN}Instalando inicialização automática no shell...${COLOR_RESET}"
                    cat > /etc/profile.d/tcti-proxmox-auto.sh << 'EOF'
#!/bin/bash
SCRIPT_DIR="$SCRIPT_DIR"
MAIN_SH="$SCRIPT_DIR/main.sh"
if [ -f "$MAIN_SH" ]; then
    cd "$SCRIPT_DIR"
    ./main.sh
fi
EOF
                    sed -i "s|\$SCRIPT_DIR|$SCRIPT_DIR|g" /etc/profile.d/tcti-proxmox-auto.sh
                    chmod +x /etc/profile.d/tcti-proxmox-auto.sh
                    echo ""
                    echo -e "${COLOR_GREEN}✓ Inicialização automática instalada com sucesso!${COLOR_RESET}"
                fi
                read -p "Pressione uma tecla para continuar..."
                extras_sistema_menu
                    ;;
                5) clear;
                watch_dog
                    ;;
                0) clear;
                extras_menu;
                    ;;
                *) clear;
                extras_menu;
                    ;;
            esac
        fi
    done
}
