#!/bin/bash

# Menu de Configurações Extras e Ferramentas Gerais
# Autor: TcTI-BR

extras_menu() {
    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}"
    echo -e "╔═════════════════════════════════════════════════════════════════════╗"
	ui_print_header_line "" "" 69
	ui_print_header_line "🛠️  ${LANG_EXTRAS_MENU_TITLE:-Ferramentas Gerais e Diagnósticos (Extras)}" "${COLOR_WHITE}" 69
	ui_print_header_line "" "" 69
	echo -e "╚═════════════════════════════════════════════════════════════════════╝"
    echo -e "${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_BOLD}  ${LANG_SELECT_OPT:-Selecione uma categoria:}${COLOR_RESET}"
    echo ""
    echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    
    ui_print_menu_item "1" "${LANG_EXTRAS_MENU_OPT_1}"
    ui_print_menu_desc "${LANG_EXTRAS_MENU_DESC_1}"
    
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    
    ui_print_menu_item "2" "${LANG_EXTRAS_MENU_OPT_2}"
    ui_print_menu_desc "${LANG_EXTRAS_MENU_DESC_2}"
    
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    
    ui_print_menu_item "3" "${LANG_EXTRAS_MENU_OPT_3}"
    ui_print_menu_desc "${LANG_EXTRAS_MENU_DESC_3}"
    
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    
    ui_print_menu_item "4" "${LANG_EXTRAS_MENU_OPT_4}"
    ui_print_menu_desc "${LANG_EXTRAS_MENU_DESC_4}"
    
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    
    ui_print_menu_item "5" "${LANG_EXTRAS_MENU_OPT_5}"
    ui_print_menu_desc "${LANG_EXTRAS_MENU_DESC_5}"
    
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    
    ui_print_menu_item "6" "${LANG_EXTRAS_MENU_OPT_6}"
    ui_print_menu_desc "${LANG_EXTRAS_MENU_DESC_6}"
    
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    
    ui_print_menu_item "7" "${LANG_EXTRAS_MENU_OPT_7}"
    ui_print_menu_desc "${LANG_EXTRAS_MENU_DESC_7}"
    
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    
    ui_print_menu_item "0" "${LANG_VM_OP_OPT_0:-Voltar}" "${COLOR_RED}"
    
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_YELLOW}  ${LANG_TYPE_OPT:-Digite sua opção} ${COLOR_GRAY}${LANG_PRESS_ENTER:-(ou pressione ENTER para sair)}${COLOR_YELLOW}: ${COLOR_RESET}"
    read -rsn1 opt
    while [ "$opt" != '' ]
    do
        if [[ $opt = "" ]]; then
            exit;
        else
            case $opt in
                1) extras_disco_menu ;;
                2) extras_email_menu ;;
                3) extras_rede_menu ;;
                4) extras_sistema_menu ;;
                5) extras_comandos_menu ;;
                6) extras_ia_menu ;;
                7) extras_gerenciamento_menu ;;
                0) clear; main_menu ;;
                *) clear; main_menu ;;
            esac
        fi
    done
    extras_menu
}
