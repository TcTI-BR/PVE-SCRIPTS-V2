#!/bin/bash

# Teste de velocidade dos discos
run_disk_speed_test() {
    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}"
    echo -e "╔═════════════════════════════════════════════════════════════════════╗"
        ui_print_header_line "${LANG_EXT_DISK_SPD_TITLE:-🚀 Teste de Velocidade (HD/SSD)}" "${COLOR_WHITE}" 69
    echo -e "╚═════════════════════════════════════════════════════════════════════╝"
    echo -e "${COLOR_RESET}"
    echo ""
    lsblk -o NAME,SIZE,LABEL,MOUNTPOINT,FSTYPE
    echo ""
    echo -e "${COLOR_YELLOW}${LANG_EXTRAS_DISK_ASK_SPEED:-Qual disco será testado o desempenho? EX: sda / nvme0n1}${COLOR_RESET}"
    read TESTEDISCO
    clear
    if [ -n "$TESTEDISCO" ]; then
echo -e  "${LANG_AUTO_DISK_SPEED_TEST_20:-${COLOR_BLUE}${SYMBOL_LOADING} Testando velocidade do disco /dev/$TESTEDISCO...${COLOR_RESET}\n}"
        hdparm -tT /dev/$TESTEDISCO
    else
        echo -e "${COLOR_RED}${SYMBOL_ERROR} ${LANG_EXTRAS_ERR_NO_DISK:-Nenhum disco informado!}${COLOR_RESET}"
    fi
    echo ""
read -p  "$(echo -e ${COLOR_YELLOW}"${LANG_EXTRAS_PRESS_ENTER:-Pressione ENTER para continuar...}"${COLOR_RESET})"
    extras_menu
}
