#!/bin/bash

# Teste de velocidade dos discos
run_disk_speed_test() {
    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}"
    echo -e "╔═════════════════════════════════════════════════════════════════════╗"
    echo -e "║                    🚀 Teste de Velocidade (HD/SSD)                  ║"
    echo -e "╚═════════════════════════════════════════════════════════════════════╝"
    echo -e "${COLOR_RESET}"
    echo ""
    lsblk -o NAME,SIZE,LABEL,MOUNTPOINT,FSTYPE
    echo ""
    echo -e "${COLOR_YELLOW}Qual disco será testado o desempenho? EX: sda / nvme0n1${COLOR_RESET}"
    read TESTEDISCO
    clear
    if [ -n "$TESTEDISCO" ]; then
        echo -e "${COLOR_BLUE}${SYMBOL_LOADING} Testando velocidade do disco /dev/$TESTEDISCO...${COLOR_RESET}\n"
        hdparm -tT /dev/$TESTEDISCO
    else
        echo -e "${COLOR_RED}${SYMBOL_ERROR} Nenhum disco informado!${COLOR_RESET}"
    fi
    echo ""
    read -p "$(echo -e ${COLOR_YELLOW}"Pressione ENTER para continuar..."${COLOR_RESET})"
    extras_menu
}
