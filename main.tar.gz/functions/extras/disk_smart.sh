#!/bin/bash

# Verificação de status SMART
run_disk_smart() {
    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}"
    echo -e "╔═════════════════════════════════════════════════════════════════════╗"
echo -e  "${LANG_AUTO_DISK_SMART_17:-║                    🩺 Status de Saúde (SMART)                       ║}"
    echo -e "╚═════════════════════════════════════════════════════════════════════╝"
    echo -e "${COLOR_RESET}"
    echo ""
    lsblk -o NAME,SIZE,LABEL,MOUNTPOINT,FSTYPE
    echo ""
    echo -e "${COLOR_YELLOW}${LANG_EXTRAS_DISK_ASK_SMART:-Qual disco será verificado o status do SMART? EX: sda / nvme0n1}${COLOR_RESET}"
    read TESTESMART
    clear
    if [ -n "$TESTESMART" ]; then
        echo -e "${COLOR_BLUE}${SYMBOL_LOADING} ${LANG_EXTRAS_DISK_SEARCH_SMART:-Buscando informações SMART do disco} /dev/$TESTESMART...${COLOR_RESET}\n"
        smartctl -a /dev/$TESTESMART
    else
        echo -e "${COLOR_RED}${SYMBOL_ERROR} ${LANG_EXTRAS_ERR_NO_DISK:-Nenhum disco informado!}${COLOR_RESET}"
    fi
    echo ""
read -p  "$(echo -e ${COLOR_YELLOW}"${LANG_EXTRAS_PRESS_ENTER:-Pressione ENTER para continuar...}"${COLOR_RESET})"
    extras_menu
}
