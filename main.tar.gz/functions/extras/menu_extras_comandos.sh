#!/bin/bash

# Submenu de Comandos e Informações Úteis (Extras)
# Autor: TcTI-BR

extras_comandos_menu(){
    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}"
    echo -e "╔═════════════════════════════════════════════════════════════════════╗"
    ui_print_header_line "" "" 69
    ui_print_header_line "${LANG_EXT_CMD_TITLE:-📚 Comandos e Informações Úteis}" "${COLOR_WHITE}" 69
    ui_print_header_line "" "" 69
    echo -e "╚═════════════════════════════════════════════════════════════════════╝"
    echo -e "${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_BOLD}  ${LANG_EXTRAS_CAT_SEL:-Selecione uma categoria de consulta:}${COLOR_RESET}"
    echo ""
    echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    ui_print_menu_item "1" "${LANG_EXT_CMD_OPT1:-Alterar Hostname e Hosts do PVE}"
    ui_print_menu_item "2" "${LANG_EXT_CMD_OPT2:-Limpar logs do sistema (/var/log)}"
    ui_print_menu_item "3" "${LANG_EXT_CMD_OPT3:-Limpar cache de RAM (drop_caches)}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    ui_print_menu_item "0" "${LANG_VM_OP_OPT_0:-Voltar}" "${COLOR_RED}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_YELLOW}  ${LANG_EXTRAS_TYPE_OPT:-Digite sua opção} ${COLOR_GRAY}${LANG_EXTRAS_OR_EXIT:-(ou pressione ENTER para sair)}${COLOR_YELLOW}: ${COLOR_RESET}"
    read -rsn1 opt
    while [ "$opt" != '' ]
    do
        if [[ $opt = "" ]]; then
             exit;
        else
            case $opt in
                1) clear
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_26:-${COLOR_CYAN}${COLOR_BOLD}🐧 COMANDOS ÚTEIS DO LINUX DEBIAN${COLOR_RESET}}"
                echo -e "${COLOR_GRAY}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${COLOR_RESET}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_27:-${COLOR_YELLOW}🌐 Rede e Conectividade:${COLOR_RESET}}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_28:-  • ${COLOR_WHITE}ip a${COLOR_RESET}                             -> Exibe interfaces e endereços IP}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_29:-  • ${COLOR_WHITE}ip route${COLOR_RESET}                         -> Exibe a tabela de roteamento padrão}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_30:-  • ${COLOR_WHITE}ss -tulpn${COLOR_RESET}                        -> Lista portas escutando e processos associados}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_31:-  • ${COLOR_WHITE}curl -I <URL>${COLOR_RESET}                    -> Exibe os cabeçalhos de resposta HTTP de um site}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_32:-  • ${COLOR_WHITE}mtr <IP/Host>${COLOR_RESET}                    -> Diagnóstico completo de rotas e perda de pacotes}"
                echo ""
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_33:-${COLOR_YELLOW}💾 Disco e Armazenamento:${COLOR_RESET}}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_34:-  • ${COLOR_WHITE}df -h${COLOR_RESET}                            -> Espaço ocupado e disponível nos pontos de montagem}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_35:-  • ${COLOR_WHITE}lsblk -f${COLOR_RESET}                         -> Arvore de discos com UUID e tipo de sistema de arquivos}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_36:-  • ${COLOR_WHITE}du -sh /* 2>/dev/null | sort -h${COLOR_RESET}  -> Identifica quais pastas ocupam mais espaço na raiz}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_37:-  • ${COLOR_WHITE}rsync -avzP /origem/ /destino/${COLOR_RESET}   -> Copia arquivos grandes com barra de progresso}"
                echo ""
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_38:-${COLOR_YELLOW}📊 Desempenho e Logs:${COLOR_RESET}}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_39:-  • ${COLOR_WHITE}free -h${COLOR_RESET}                          -> Uso detalhado de memória RAM e SWAP}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_40:-  • ${COLOR_WHITE}journalctl -fu postfix${COLOR_RESET}           -> Acompanha logs do serviço postfix em tempo real}"
                echo -e "  • ${COLOR_WHITE}journalctl -xe${COLOR_RESET}                   -> ${LANG_EXTRAS_CMD_DESC_1:-Exibe os últimos logs de erro do sistema}"
                echo -e "${COLOR_GRAY}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${COLOR_RESET}"
                echo ""
                read -p "${LANG_EXTRAS_PRESS_KEY:-Pressione uma tecla para continuar...}"
                clear
                extras_comandos_menu
                    ;;
                2) clear
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_41:-${COLOR_CYAN}${COLOR_BOLD}🖥️ COMANDOS DO PROXMOX VE (PVE)${COLOR_RESET}}"
                echo -e "${COLOR_GRAY}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${COLOR_RESET}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_42:-${COLOR_YELLOW}⚙️ Gerenciamento de VMs (KVM/QEMU):${COLOR_RESET}}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_43:-  • ${COLOR_WHITE}qm list${COLOR_RESET}                          -> Lista todas as VMs do host e seus status}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_44:-  • ${COLOR_WHITE}qm start <VMID>${COLOR_RESET}                  -> Liga a VM especificada}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_45:-  • ${COLOR_WHITE}qm shutdown <VMID>${COLOR_RESET}               -> Solicita o desligamento seguro (ACPI) da VM}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_46:-  • ${COLOR_WHITE}qm stop <VMID>${COLOR_RESET}                   -> Força o desligamento imediato (Hard Stop) da VM}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_47:-  • ${COLOR_WHITE}qm reboot <VMID>${COLOR_RESET}                 -> Reinicia a VM via comando}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_48:-  • ${COLOR_WHITE}qm unlock <VMID>${COLOR_RESET}                 -> Destranca uma VM travada em estado de 'lock'}"
                echo -e "  • ${COLOR_WHITE}qm config <VMID>${COLOR_RESET}                 -> ${LANG_EXTRAS_CMD_DESC_2:-Exibe o arquivo de configuração da VM}"
                echo ""
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_49:-${COLOR_YELLOW}📦 Gerenciamento de Containers (LXC):${COLOR_RESET}}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_50:-  • ${COLOR_WHITE}pct list${COLOR_RESET}                         -> Lista todos os containers LXC do node}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_51:-  • ${COLOR_WHITE}pct enter <VMID>${COLOR_RESET}                 -> Acessa o shell root direto dentro do container}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_52:-  • ${COLOR_WHITE}pct start|stop <VMID>${COLOR_RESET}            -> Liga ou desliga um container LXC}"
                echo ""
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_53:-${COLOR_YELLOW}🗄️ Storage e Cluster:${COLOR_RESET}}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_54:-  • ${COLOR_WHITE}pvesm status${COLOR_RESET}                     -> Exibe o status e espaço livre de todos os storages}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_55:-  • ${COLOR_WHITE}pvecm status${COLOR_RESET}                     -> Exibe a saúde e os nós participantes do Cluster PVE}"
                echo -e "${COLOR_GRAY}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${COLOR_RESET}"
                echo ""
                read -p "${LANG_EXTRAS_PRESS_KEY:-Pressione uma tecla para continuar...}"
                clear
                extras_comandos_menu
                    ;;
                3) clear
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_56:-${COLOR_CYAN}${COLOR_BOLD}📁 CAMINHOS RELEVANTES E ESTRUTURA DO PROXMOX${COLOR_RESET}}"
                echo -e "${COLOR_GRAY}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${COLOR_RESET}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_57:-${COLOR_YELLOW}⚙️ Arquivos de Configuração:${COLOR_RESET}}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_58:-  • ${COLOR_WHITE}/etc/pve/nodes/<NODE>/qemu-server/<VMID>.conf${COLOR_RESET}  -> Configurações das VMs}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_59:-  • ${COLOR_WHITE}/etc/pve/nodes/<NODE>/lxc/<VMID>.conf${COLOR_RESET}         -> Configurações dos LXCs}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_60:-  • ${COLOR_WHITE}/etc/pve/storage.cfg${COLOR_RESET}                         -> Mapeamento de Storages PVE}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_61:-  • ${COLOR_WHITE}/etc/pve/datacenter.cfg${COLOR_RESET}                      -> Parâmetros globais do Datacenter}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_62:-  • ${COLOR_WHITE}/etc/network/interfaces${COLOR_RESET}                      -> Configuração de rede física/bridges}"
                echo ""
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_63:-${COLOR_YELLOW}📦 Repositórios de Mídias e Backups:${COLOR_RESET}}"
                echo -e "  • ${COLOR_WHITE}/var/lib/vz/template/iso/${COLOR_RESET}                    -> ${LANG_EXTRAS_CMD_DESC_3:-Diretório padrão para upload de ISOs}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_64:-  • ${COLOR_WHITE}/var/lib/vz/template/cache/${COLOR_RESET}                  -> Templates de Containers LXC}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_65:-  • ${COLOR_WHITE}/var/lib/vz/dump/${COLOR_RESET}                            -> Destino padrão dos backups VMA/ZST}"
                echo ""
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_66:-${COLOR_YELLOW}🔍 Logs e Registros:${COLOR_RESET}}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_67:-  • ${COLOR_WHITE}/var/log/pve/tasks/${COLOR_RESET}                          -> Histórico completo de tarefas da GUI}"
echo -e  "${LANG_AUTO_MENU_EXTRAS_COM_68:-  • ${COLOR_WHITE}/var/log/syslog${COLOR_RESET}                            -> Log geral do sistema operacional}"
                echo -e "${COLOR_GRAY}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${COLOR_RESET}"
                echo ""
                read -p "${LANG_EXTRAS_PRESS_KEY:-Pressione uma tecla para continuar...}"
                clear
                extras_comandos_menu
                    ;;
                0) clear;
                extras_menu;
                    ;;
                *) clear;
                extras_menu;
                    ;;
            esac
        fi
    done
}
