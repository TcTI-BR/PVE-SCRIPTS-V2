#!/bin/bash

# Submenu de Comandos e Informações Úteis (Extras)
# Autor: TcTI-BR

extras_comandos_menu(){
    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}"
    echo -e "╔═════════════════════════════════════════════════════════════════════╗"
    echo -e "║                                                                     ║"
    echo -e "║               📚 Comandos e Informações Úteis                        ║"
    echo -e "║                                                                     ║"
    echo -e "╚═════════════════════════════════════════════════════════════════════╝"
    echo -e "${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_BOLD}  Selecione uma categoria de consulta:${COLOR_RESET}"
    echo ""
    echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}1${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}Comandos Úteis do Linux (Sistema, Rede, Disco e Processos)${COLOR_RESET}    ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}2${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}Comandos do Proxmox VE (qm, pct, pvesm, pvecm)${COLOR_RESET}            ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}3${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}Caminhos Relevantes e Estrutura de Arquivos${COLOR_RESET}                   ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_RED}0${COLOR_RESET} ${COLOR_RED}➜${COLOR_RESET}  ${COLOR_WHITE}Voltar ao menu de Extras${COLOR_RESET}                                ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_YELLOW}  Digite sua opção ${COLOR_GRAY}(ou pressione ENTER para sair)${COLOR_YELLOW}: ${COLOR_RESET}"
    read -rsn1 opt
    while [ "$opt" != '' ]
    do
        if [[ $opt = "" ]]; then
             exit;
        else
            case $opt in
                1) clear
                echo -e "${COLOR_CYAN}${COLOR_BOLD}🐧 COMANDOS ÚTEIS DO LINUX DEBIAN${COLOR_RESET}"
                echo -e "${COLOR_GRAY}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${COLOR_RESET}"
                echo -e "${COLOR_YELLOW}🌐 Rede e Conectividade:${COLOR_RESET}"
                echo -e "  • ${COLOR_WHITE}ip a${COLOR_RESET}                             -> Exibe interfaces e endereços IP"
                echo -e "  • ${COLOR_WHITE}ip route${COLOR_RESET}                         -> Exibe a tabela de roteamento padrão"
                echo -e "  • ${COLOR_WHITE}ss -tulpn${COLOR_RESET}                        -> Lista portas escutando e processos associados"
                echo -e "  • ${COLOR_WHITE}curl -I <URL>${COLOR_RESET}                    -> Exibe os cabeçalhos de resposta HTTP de um site"
                echo -e "  • ${COLOR_WHITE}mtr <IP/Host>${COLOR_RESET}                    -> Diagnóstico completo de rotas e perda de pacotes"
                echo ""
                echo -e "${COLOR_YELLOW}💾 Disco e Armazenamento:${COLOR_RESET}"
                echo -e "  • ${COLOR_WHITE}df -h${COLOR_RESET}                            -> Espaço ocupado e disponível nos pontos de montagem"
                echo -e "  • ${COLOR_WHITE}lsblk -f${COLOR_RESET}                         -> Arvore de discos com UUID e tipo de sistema de arquivos"
                echo -e "  • ${COLOR_WHITE}du -sh /* 2>/dev/null | sort -h${COLOR_RESET}  -> Identifica quais pastas ocupam mais espaço na raiz"
                echo -e "  • ${COLOR_WHITE}rsync -avzP /origem/ /destino/${COLOR_RESET}   -> Copia arquivos grandes com barra de progresso"
                echo ""
                echo -e "${COLOR_YELLOW}📊 Desempenho e Logs:${COLOR_RESET}"
                echo -e "  • ${COLOR_WHITE}free -h${COLOR_RESET}                          -> Uso detalhado de memória RAM e SWAP"
                echo -e "  • ${COLOR_WHITE}journalctl -fu postfix${COLOR_RESET}           -> Acompanha logs do serviço postfix em tempo real"
                echo -e "  • ${COLOR_WHITE}journalctl -xe${COLOR_RESET}                   -> Exibe os últimos logs de erro do sistema"
                echo -e "${COLOR_GRAY}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${COLOR_RESET}"
                echo ""
                read -p "Pressione uma tecla para continuar..."
                clear
                extras_comandos_menu
                    ;;
                2) clear
                echo -e "${COLOR_CYAN}${COLOR_BOLD}🖥️ COMANDOS DO PROXMOX VE (PVE)${COLOR_RESET}"
                echo -e "${COLOR_GRAY}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${COLOR_RESET}"
                echo -e "${COLOR_YELLOW}⚙️ Gerenciamento de VMs (KVM/QEMU):${COLOR_RESET}"
                echo -e "  • ${COLOR_WHITE}qm list${COLOR_RESET}                          -> Lista todas as VMs do host e seus status"
                echo -e "  • ${COLOR_WHITE}qm start <VMID>${COLOR_RESET}                  -> Liga a VM especificada"
                echo -e "  • ${COLOR_WHITE}qm shutdown <VMID>${COLOR_RESET}               -> Solicita o desligamento seguro (ACPI) da VM"
                echo -e "  • ${COLOR_WHITE}qm stop <VMID>${COLOR_RESET}                   -> Força o desligamento imediato (Hard Stop) da VM"
                echo -e "  • ${COLOR_WHITE}qm reboot <VMID>${COLOR_RESET}                 -> Reinicia a VM via comando"
                echo -e "  • ${COLOR_WHITE}qm unlock <VMID>${COLOR_RESET}                 -> Destranca uma VM travada em estado de 'lock'"
                echo -e "  • ${COLOR_WHITE}qm config <VMID>${COLOR_RESET}                 -> Exibe o arquivo de configuração da VM"
                echo ""
                echo -e "${COLOR_YELLOW}📦 Gerenciamento de Containers (LXC):${COLOR_RESET}"
                echo -e "  • ${COLOR_WHITE}pct list${COLOR_RESET}                         -> Lista todos os containers LXC do node"
                echo -e "  • ${COLOR_WHITE}pct enter <VMID>${COLOR_RESET}                 -> Acessa o shell root direto dentro do container"
                echo -e "  • ${COLOR_WHITE}pct start|stop <VMID>${COLOR_RESET}            -> Liga ou desliga um container LXC"
                echo ""
                echo -e "${COLOR_YELLOW}🗄️ Storage e Cluster:${COLOR_RESET}"
                echo -e "  • ${COLOR_WHITE}pvesm status${COLOR_RESET}                     -> Exibe o status e espaço livre de todos os storages"
                echo -e "  • ${COLOR_WHITE}pvecm status${COLOR_RESET}                     -> Exibe a saúde e os nós participantes do Cluster PVE"
                echo -e "${COLOR_GRAY}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${COLOR_RESET}"
                echo ""
                read -p "Pressione uma tecla para continuar..."
                clear
                extras_comandos_menu
                    ;;
                3) clear
                echo -e "${COLOR_CYAN}${COLOR_BOLD}📁 CAMINHOS RELEVANTES E ESTRUTURA DO PROXMOX${COLOR_RESET}"
                echo -e "${COLOR_GRAY}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${COLOR_RESET}"
                echo -e "${COLOR_YELLOW}⚙️ Arquivos de Configuração:${COLOR_RESET}"
                echo -e "  • ${COLOR_WHITE}/etc/pve/nodes/<NODE>/qemu-server/<VMID>.conf${COLOR_RESET}  -> Configurações das VMs"
                echo -e "  • ${COLOR_WHITE}/etc/pve/nodes/<NODE>/lxc/<VMID>.conf${COLOR_RESET}         -> Configurações dos LXCs"
                echo -e "  • ${COLOR_WHITE}/etc/pve/storage.cfg${COLOR_RESET}                         -> Mapeamento de Storages PVE"
                echo -e "  • ${COLOR_WHITE}/etc/pve/datacenter.cfg${COLOR_RESET}                      -> Parâmetros globais do Datacenter"
                echo -e "  • ${COLOR_WHITE}/etc/network/interfaces${COLOR_RESET}                      -> Configuração de rede física/bridges"
                echo ""
                echo -e "${COLOR_YELLOW}📦 Repositórios de Mídias e Backups:${COLOR_RESET}"
                echo -e "  • ${COLOR_WHITE}/var/lib/vz/template/iso/${COLOR_RESET}                    -> Diretório padrão para upload de ISOs"
                echo -e "  • ${COLOR_WHITE}/var/lib/vz/template/cache/${COLOR_RESET}                  -> Templates de Containers LXC"
                echo -e "  • ${COLOR_WHITE}/var/lib/vz/dump/${COLOR_RESET}                            -> Destino padrão dos backups VMA/ZST"
                echo ""
                echo -e "${COLOR_YELLOW}🔍 Logs e Registros:${COLOR_RESET}"
                echo -e "  • ${COLOR_WHITE}/var/log/pve/tasks/${COLOR_RESET}                          -> Histórico completo de tarefas da GUI"
                echo -e "  • ${COLOR_WHITE}/var/log/syslog${COLOR_RESET}                            -> Log geral do sistema operacional"
                echo -e "${COLOR_GRAY}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${COLOR_RESET}"
                echo ""
                read -p "Pressione uma tecla para continuar..."
                clear
                extras_comandos_menu
                    ;;
                0) clear;
                extras_menu;
                    ;;
                *) clear;
                extras_menu;
                    ;;
            esac
        fi
    done
}
