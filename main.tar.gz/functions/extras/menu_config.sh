#!/bin/bash

# Menu de Configurações do Script
# Permite alterar configurações globais como idioma.

menu_config(){
    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}"
    echo -e "╔═════════════════════════════════════════════════════════════════════╗"
    ui_print_header_line "" "" 69
    ui_print_header_line "⚙️  ${LANG_CONF_TITLE:-Configurações do Script}" "${COLOR_WHITE}" 69
    ui_print_header_line "" "" 69
    echo -e "╚═════════════════════════════════════════════════════════════════════╝"
    echo -e "${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_BOLD}  ${LANG_SELECT_OPT:-Selecione uma opção:}${COLOR_RESET}"
    echo ""
    echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    
    ui_print_menu_item "1" "${LANG_CONF_OPT_1:-Alterar Idioma}"
    
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    
    ui_print_menu_item "0" "${LANG_VM_OP_OPT_0:-Voltar}" "${COLOR_RED}"
    
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_YELLOW}  ${LANG_TYPE_OPT:-Digite sua opção} ${COLOR_GRAY}${LANG_PRESS_ENTER:-(ou pressione ENTER para sair)}${COLOR_YELLOW}: ${COLOR_RESET}"
    
    read -rsn1 opt
    while [ opt != '' ] 
    do
        if [[ $opt = "" ]]; then
            exit;
        else
            case $opt in
                1) 
                    change_language 
                    ;;
                0) 
                    clear;
                    main_menu;
                    ;;
                *)
                    menu_config;
                    ;;
            esac
        fi
    done
}

change_language() {
    clear
    echo -e "${COLOR_CYAN}╔══════════════════════════════════════════════════════════════════════════╗${COLOR_RESET}"
    echo -e "${COLOR_CYAN}║${COLOR_RESET}  ${COLOR_YELLOW}Select your language / Selecione seu idioma${COLOR_RESET}                             ${COLOR_CYAN}║${COLOR_RESET}"
    echo -e "${COLOR_CYAN}╚══════════════════════════════════════════════════════════════════════════╝${COLOR_RESET}"
    echo ""
    echo "  1 ➜ 🇧🇷 Português (Brasil)"
    echo "  2 ➜ 🇺🇸 English (US)"
    echo "  3 ➜ 🇪🇸 Español (ES)"
    echo "  4 ➜ 🇨🇳 简体中文 (Chinese)"
    echo ""
    echo -n "  Option / Opção: "
    read -r lang_opt
    
    local config_file="$SCRIPT_DIR/.lang.cfg"
    
    case $lang_opt in
        1) echo "LANG_FILE=pt_BR.sh" > "$config_file" ;;
        2) echo "LANG_FILE=en_US.sh" > "$config_file" ;;
        3) echo "LANG_FILE=es_ES.sh" > "$config_file" ;;
        4) echo "LANG_FILE=zh_CN.sh" > "$config_file" ;;
        *) 
            echo -e "\n${COLOR_RED}Invalid option / Opção inválida.${COLOR_RESET}"
            sleep 2
            change_language
            return
            ;;
    esac
    
    echo -e "\n${COLOR_GREEN}${SYMBOL_CHECK} ${LANG_CONF_LANG_CHOSEN:-Idioma salvo!}${COLOR_RESET}"
    echo -e "${COLOR_YELLOW}${SYMBOL_LOADING} ${LANG_CONF_RESTARTING:-Reiniciando script...}${COLOR_RESET}"
    sleep 2
    
    # Reinicia o script do zero para carregar o novo idioma em todas as variáveis globais
    exec "$SCRIPT_DIR/main.sh"
}
