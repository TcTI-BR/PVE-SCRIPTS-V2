#!/bin/bash

# Verificação de setores defeituosos
run_disk_badblocks() {
    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}"
    echo -e "╔═════════════════════════════════════════════════════════════════════╗"
echo -e  "${LANG_AUTO_DISK_BADBLOCKS_14:-║                    🔍 Verificação de Badblocks                      ║}"
    echo -e "╚═════════════════════════════════════════════════════════════════════╝"
    echo -e "${COLOR_RESET}"
    echo ""
    lsblk -o NAME,SIZE,LABEL,MOUNTPOINT,FSTYPE
    echo ""
    echo -e "${COLOR_YELLOW}${LANG_EXTRAS_DISK_ASK_BADBLOCKS:-Qual disco será testado os setores? EX: sda / nvme0n1}${COLOR_RESET}"
    read TESTESETORES
    clear
    if [ -n "$TESTESETORES" ]; then
echo -e  "${LANG_AUTO_DISK_BADBLOCKS_15:-${COLOR_BLUE}${SYMBOL_LOADING} Iniciando teste de blocos defeituosos no disco /dev/$TESTESETORES...${COLOR_RESET}\n}"
        badblocks -sv -c 10240 /dev/$TESTESETORES
    else
        echo -e "${COLOR_RED}${SYMBOL_ERROR} ${LANG_EXTRAS_ERR_NO_DISK:-Nenhum disco informado!}${COLOR_RESET}"
    fi
    echo ""
read -p  "$(echo -e ${COLOR_YELLOW}"${LANG_EXTRAS_PRESS_ENTER:-Pressione ENTER para continuar...}"${COLOR_RESET})"
    extras_menu
}
