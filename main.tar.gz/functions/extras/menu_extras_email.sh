#!/bin/bash

# Submenu de Configuração de Email (Extras)
# Autor: TcTI-BR

extras_email_menu(){
    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}"
    echo -e "╔═════════════════════════════════════════════════════════════════════╗"
    ui_print_header_line "" "" 69
    ui_print_header_line "${LANG_EXT_MAIL_TITLE:-📧 Configuração de Email}" "${COLOR_WHITE}" 69
    ui_print_header_line "" "" 69
    echo -e "╚═════════════════════════════════════════════════════════════════════╝"
    echo -e "${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_BOLD}  ${LANG_EXTRAS_SEL_OPT:-Selecione uma opção:}${COLOR_RESET}"
    echo ""
    echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    ui_print_menu_item "1" "${LANG_EXT_MAIL_OPT1:-Configurar Postfix (SMTP Gmail/Outlook)}"
    ui_print_menu_item "2" "${LANG_EXT_MAIL_OPT2:-Enviar E-mail de Teste}"
    ui_print_menu_item "3" "${LANG_EXT_MAIL_OPT3:-Remover Configuração do Postfix}"
    ui_print_menu_item "4" "${LANG_EXT_MAIL_OPT4:-Restaura a configuração original}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    ui_print_menu_item "0" "${LANG_VM_OP_OPT_0:-Voltar}" "${COLOR_RED}"
    echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
    echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_YELLOW}  ${LANG_EXTRAS_TYPE_OPT:-Digite sua opção} ${COLOR_GRAY}${LANG_EXTRAS_OR_EXIT:-(ou pressione ENTER para sair)}${COLOR_YELLOW}: ${COLOR_RESET}"
    read -rsn1 opt
    while [ "$opt" != '' ] 
    do
        if [[ $opt = "" ]]; then
             exit;
        else
            case $opt in
                1) clear
                echo "- ${LANG_MAIL_ROOT_ALIAS:-Endereço de e-mail do destinatário do administrador do sistema (conta@dominioexemplo.com) (root alias): }"
                read varrootmail
                echo "- ${LANG_EXTRAS_MAIL_HOST:-Qual é o endereço do host do servidor de e-mail? (smtp.gmail.com): }"
                read varmailserver
                echo "- ${LANG_EXTRAS_MAIL_PORT:-Qual é a porta do servidor de e-mail? (Ex: 465 ou 587): }"
                read varmailport
                read -p  "- ${LANG_MAIL_REQ_TLS:-O servidor de e-mail requer TLS? s = sim / n = não: }" -n 1 -r 
                if [[ $REPLY =~ ^[SsYy]$ ]]; then
                    vartls=yes
                else
                    vartls=no
                fi
                echo " "
                echo "- ${LANG_MAIL_AUTH_USER:-O nome do usuário de autenticação? (EX: email@dominioexemplo.com.br): }"
                read varmailusername
                echo "- ${LANG_EXTRAS_MAIL_PASS:-Qual é a senha de autenticação?: }"
                read varmailpassword
                echo "- ${LANG_MAIL_SAME_SENDER:-O endereço de e-mail que envia é o mesmo que o usuário de autenticação?}"
                read -p "${LANG_MAIL_S_TO_USE:- s para usar }$varmailusername${LANG_MAIL_ENTER_NO:- / Enter para não: }" -n 1 -r 
                if [[ $REPLY =~ ^[SsYy]$ ]]; then
                    varsenderaddress=$varmailusername
                else
                    echo " "
                    echo "- ${LANG_EXTRAS_MAIL_SENDER:-Qual é o endereço de e-mail do remetente?: }"
                    read varsenderaddress
                fi
                echo " "
                echo "- ${LANG_MAIL_EXEC:-Executando...!}"
                echo " "
                echo "- ${LANG_MAIL_DEF_ALIASES:-Definindo aliases}"
                if grep "root:" /etc/aliases
                then
                    echo "- ${LANG_MAIL_ALIAS_FOUND:-A entrada de alias foi encontrada: editando para }$varrootmail"
                    sed -i "s/^root:.*$/root: $varrootmail/" /etc/aliases
                else
                    echo "- ${LANG_EXTRAS_MAIL_ROOT:-Nenhum alias do root encontrado: Adicionando}"
echo "${LANG_AUTO_MENU_EXTRAS_EMA_76:-root: $varrootmail}" >> /etc/aliases
                fi
                # Configurando o arquivo canônico para o remetente
echo "${LANG_AUTO_MENU_EXTRAS_EMA_77:-root $varsenderaddress}" > /etc/postfix/canonical
                chmod 600 /etc/postfix/canonical
                # Preparando para o hash da senha
                echo [$varmailserver]:$varmailport $varmailusername:$varmailpassword > /etc/postfix/sasl_passwd
                chmod 600 /etc/postfix/sasl_passwd 
                # Adicionando o servidor de email no arquivo main.cf
                sed -i "/#/!s/\(relayhost[[:space:]]*=[[:space:]]*\)\(.*\)/\1"[$varmailserver]:"$varmailport""/"  /etc/postfix/main.cf
                
                # Removendo parâmetro antigo smtp_use_tls se existir para evitar conflitos
                postconf -X smtp_use_tls 2>/dev/null

                # Verificando as configurações de TLS
                echo "- ${LANG_MAIL_DEF_TLS:-Definindo as configurações de TLS corretas}"
                if [ "$vartls" = "yes" ]; then
                    postconf smtp_tls_security_level=encrypt
                    if [ "$varmailport" = "465" ]; then
                        postconf smtp_tls_wrappermode=yes
                        postconf smtp_tls_loglevel=1
                    else
                        postconf smtp_tls_wrappermode=no
                    fi
                else
                    postconf smtp_tls_security_level=none
                    postconf smtp_tls_wrappermode=no
                fi

                # Verificando a entrada de hash da senha
                if grep -q "smtp_sasl_password_maps" /etc/postfix/main.cf
                then
                    echo "- ${LANG_MAIL_HASH_OK:-Hash da senha já configurado}"
                else
                    echo "- ${LANG_MAIL_HASH_ADD:-Adicionando entrada de hash da senha}"
                    postconf smtp_sasl_password_maps=hash:/etc/postfix/sasl_passwd
                fi
                
                postconf -X smtp_tls_CAfile 2>/dev/null
                
                if grep -q "smtp_sasl_security_options" /etc/postfix/main.cf
                then
                    echo "- ${LANG_MAIL_SASL_FOUND:-Configuração de smtp_sasl_security_options encontrada}"
                else
                    postconf smtp_sasl_security_options=noanonymous
                fi
                if grep -q "smtp_sasl_auth_enable" /etc/postfix/main.cf
                then
                    echo "- ${LANG_MAIL_AUTH_OK:-Autenticação já habilitada}"
                else
                    postconf smtp_sasl_auth_enable=yes
                fi 
                if grep -q "sender_canonical_maps" /etc/postfix/main.cf
                then
                    echo "- ${LANG_MAIL_CANON_OK:-Entrada canônica já existente}"
                else
                    postconf sender_canonical_maps=hash:/etc/postfix/canonical
                fi 
                echo "- ${LANG_MAIL_ENC_CANON:-Criptografia de senha e entrada canônica}"
                postmap /etc/postfix/sasl_passwd
                postmap /etc/postfix/canonical
                apt update
                apt install libsasl2-modules bsd-mailx mailutils -y 2>/dev/null
                echo "- ${LANG_MAIL_RESTART_POSTFIX:-Reiniciando o postfix e habilitando a inicialização automática}"
                systemctl restart postfix && systemctl enable postfix
                echo "- ${LANG_EXTRAS_MAIL_CLEAN:-Limpando o arquivo usado para gerar hash de senha}"
                rm -rf "/etc/postfix/sasl_passwd"
                echo "- ${LANG_EXTRAS_MAIL_SUC:-Concluído com sucesso!}"
                read -p "${LANG_PRESS_ANY_KEY:-Pressione uma tecla para continuar...}"
                extras_email_menu
                    ;;
                2) clear;
                echo "- ${LANG_EXTRAS_MAIL_RECV:-Qual é o endereço de e-mail do destinatário? :}"
                read vardestaddress
                echo "- ${LANG_MAIL_WILL_SEND:-Um e-mail será enviado para: }$vardestaddress"
                echo "${LANG_MAIL_TEST_BODY:-Esse e-mail confirma que a configuração do seu servidor está OK!}" | mail -s "${LANG_MAIL_TEST_SUBJECT:-Teste de e-mail - }$(hostname) - $(date +'%d/%m/%Y %H:%M')" $vardestaddress
                echo "- ${LANG_EXTRAS_MAIL_SENT:-O e-mail deveria ter sido enviado - Se nenhum for recebido, verifique se há erros no menu 3}"
                read -p "${LANG_PRESS_ANY_KEY:-Pressione uma tecla para continuar...}"
                extras_email_menu
                    ;;
                3) clear;
                echo "- ${LANG_EXTRAS_MAIL_CHECK:-Verificando se há erros nos logs...}"
                LOG_FILE="/var/log/mail.log"
                [ ! -f "$LOG_FILE" ] && LOG_FILE="/var/log/syslog"

                if grep -q "SMTPUTF8 is required" "$LOG_FILE" 2>/dev/null
                then
                    echo "- ${LANG_EXTRAS_MAIL_ERR1:-Encontrado erro no log: SMTPUTF8 é requerido}"
                    if grep -q "smtputf8_enable = no" /etc/postfix/main.cf 2>/dev/null
                    then
echo "${LANG_AUTO_MENU_EXTRAS_EMA_78:-- Correção já aplicada!}"
                    else
echo "${LANG_AUTO_MENU_EXTRAS_EMA_79:-- Aplicando correção: smtputf8_enable=no}"
                        postconf smtputf8_enable=no
                        postfix reload
                    fi 
                elif grep -q "Network is unreachable" "$LOG_FILE" 2>/dev/null; then
read -p  "${LANG_AUTO_MENU_EXTRAS_EMA_80:-- Você está no IPv4 e seu host pode resolver e acessar endereços públicos? s = sim / n = não: }" -n 1 -r
                    if [[ $REPLY =~ ^[SsYy]$ ]]; then
                        if grep -q "inet_protocols = ipv4" /etc/postfix/main.cf 2>/dev/null
                        then
echo "${LANG_AUTO_MENU_EXTRAS_EMA_81:-- Correção já aplicada!}"
                        else
echo "${LANG_AUTO_MENU_EXTRAS_EMA_82:-- Aplicando correção: inet_protocols = ipv4}"
                            postconf inet_protocols=ipv4
                            postfix reload
                        fi
                    fi
                elif grep -q "smtp_tls_security_level = encrypt" "$LOG_FILE" 2>/dev/null; then     
                    echo "- ${LANG_EXTRAS_MAIL_ERR2:-Encontrado erro no log: smtp_tls_security_level = encrypt é requerido}"
                    if grep -q "smtp_tls_security_level = encrypt" /etc/postfix/main.cf 2>/dev/null; then
echo "${LANG_AUTO_MENU_EXTRAS_EMA_83:-- Correção já aplicada!}"
                    else
echo "${LANG_AUTO_MENU_EXTRAS_EMA_84:-- Aplicando correção: smtp_tls_security_level = encrypt}"
                        postconf smtp_tls_security_level=encrypt
                        postfix reload
                    fi
                elif grep -q "smtp_tls_wrappermode = yes" "$LOG_FILE" 2>/dev/null; then        
                    echo "- ${LANG_EXTRAS_MAIL_ERR3:-Encontrado erro no log: smtp_tls_wrappermode = yes é requerido}"
                    if grep -q "smtp_tls_wrappermode = yes" /etc/postfix/main.cf 2>/dev/null; then
echo "${LANG_AUTO_MENU_EXTRAS_EMA_85:-- Correção já aplicada!}"
                    else
echo "${LANG_AUTO_MENU_EXTRAS_EMA_86:-- Aplicando correção: smtp_tls_wrappermode = yes}"
                        postconf smtp_tls_wrappermode=yes
                        postfix reload
                    fi
                else
echo "${LANG_AUTO_MENU_EXTRAS_EMA_87:-- Não foram encontrados erros conhecidos nos logs recentes!}"
                fi
                read -p "${LANG_PRESS_ANY_KEY:-Pressione uma tecla para continuar...}"
                extras_email_menu  
                    ;;
                4) clear;
                read -p "- ${LANG_EXTRAS_MAIL_RESTORE:-Deseja restaurar as configurações originais? s = sim / n = não: }" -n 1 -r
                if [[ $REPLY =~ ^[SsYy]$ ]]; then
                    echo " "
echo "${LANG_AUTO_MENU_EXTRAS_EMA_88:-- Restaurando as configurações originais...}"
                    [ -f /etc/aliases.BCK ] && cp -rf /etc/aliases.BCK /etc/aliases
                    [ -f /etc/postfix/main.cf.BCK ] && cp -rf /etc/postfix/main.cf.BCK /etc/postfix/main.cf
echo "${LANG_AUTO_MENU_EXTRAS_EMA_89:-- Reiniciando o serviço postfix...}"
                    systemctl restart postfix
echo "${LANG_AUTO_MENU_EXTRAS_EMA_90:-- Restauração concluída!}"
                fi
                read -p "${LANG_PRESS_ANY_KEY:-Pressione uma tecla para continuar...}"
                extras_email_menu
                    ;;
                0) clear;
                extras_menu;
                    ;;
                *) clear;
                extras_menu;
                    ;;
            esac
        fi
    done
}
