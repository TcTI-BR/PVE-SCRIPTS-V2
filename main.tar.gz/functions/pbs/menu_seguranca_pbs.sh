#!/bin/bash

# Menu de Segurança, Acessos e API do Proxmox Backup Server (PBS)

gerar_token_api_pbs(){
	clear
	echo -e "${COLOR_CYAN}${COLOR_BOLD}"
	echo -e "╔═════════════════════════════════════════════════════════════════════╗"
	ui_print_header_line "" "" 69
	ui_print_header_line "🔑 ${LANG_TOKEN_TITLE:-Gerar Token de API para Automação Externa}" "${COLOR_WHITE}" 69
	ui_print_header_line "" "" 69
	echo -e "╚═════════════════════════════════════════════════════════════════════╝"
	echo -e "${COLOR_RESET}"
	echo ""
	
	echo -e "${COLOR_WHITE}  ${LANG_TOKEN_ASK_NAME:-Digite o nome do token de API} ${COLOR_GRAY}${LANG_TOKEN_EX_HINT:-(ex: automacao, n8n, terraform):}${COLOR_RESET}"
	read -p "  ${LANG_TOKEN_LABEL:-Nome do Token: }" nome_do_token
	
	# Remove espaços em branco nas pontas
	nome_do_token=$(echo "$nome_do_token" | xargs 2>/dev/null || echo "$nome_do_token")
	
	if [ -z "$nome_do_token" ]; then
		echo ""
		echo -e "${COLOR_RED}  ✗ ${LANG_TOKEN_ERR_EMPTY:-Erro: O nome do token não pode ficar em branco.}${COLOR_RESET}"
		echo ""
		read -p "  ${LANG_PVE_PRESS_ENTER:-Pressione ENTER para continuar...}"
		return
	fi
	
	echo ""
	echo -e "${COLOR_BLUE}${SYMBOL_LOADING:-⟳} ${LANG_TOKEN_CREATING_PBS:-Gerando token de API no PBS para root@pam...}${COLOR_RESET}"
	echo ""
	
	if command -v proxmox-backup-manager &>/dev/null; then
		proxmox-backup-manager user generate-token root@pam "$nome_do_token"
		if [ $? -eq 0 ]; then
			proxmox-backup-manager acl update / Admin --auth-id "root@pam!$nome_do_token" 2>/dev/null
			echo ""
			echo -e "${COLOR_GREEN}${COLOR_BOLD}  ✓ ${LANG_TOKEN_SUCCESS_1:-Token de API '}${nome_do_token}${LANG_TOKEN_SUCCESS_2:-' gerado com sucesso!}${COLOR_RESET}"
			echo -e "${COLOR_GREEN}  ✓ ${LANG_TOKEN_ACL_SUC_PBS:-Permissão 'Admin' atribuída ao path '/' com sucesso!}${COLOR_RESET}"
			echo -e "${COLOR_YELLOW}  ⚠️ ${LANG_TOKEN_WARN_SECRET_1:-Guarde o 'value' (Secret) exibido acima em um local seguro.}${COLOR_RESET}"
			echo -e "${COLOR_YELLOW}     ${LANG_TOKEN_WARN_SECRET_2:-Ele não poderá ser visualizado novamente pelo Proxmox.}${COLOR_RESET}"
		else
			echo ""
			echo -e "${COLOR_RED}  ✗ ${LANG_TOKEN_ERR_FAIL:-Erro ao gerar o token de API. Verifique se o token já existe.}${COLOR_RESET}"
		fi
	else
		echo -e "${COLOR_YELLOW}  ⚠️ ${LANG_TOKEN_SIM_MODE:-[Modo Simulação / Comando PVE]}${COLOR_RESET}"
		echo -e "${COLOR_WHITE}  ${LANG_TOKEN_CMD_TO_EXEC:-Comandos a serem executados:}${COLOR_RESET}"
		echo -e "  ${COLOR_CYAN}proxmox-backup-manager user generate-token root@pam $nome_do_token${COLOR_RESET}"
		echo -e "  ${COLOR_CYAN}proxmox-backup-manager acl update / Admin --auth-id 'root@pam!$nome_do_token'${COLOR_RESET}"
		echo ""
		echo -e "${COLOR_GREEN}  ✓ ${LANG_TOKEN_SIM_SUC_1:-Token '}${nome_do_token}${LANG_TOKEN_SIM_SUC_2:-' configurado.}${COLOR_RESET}"
	fi
	
	echo ""
	read -p "  ${LANG_PVE_PRESS_ENTER:-Pressione ENTER para continuar...}"
}

admin_host_acessos_api_pbs_menu(){
	clear
	echo -e "${COLOR_CYAN}${COLOR_BOLD}"
	echo -e "╔═════════════════════════════════════════════════════════════════════╗"
	ui_print_header_line "" "" 69
	ui_print_header_line "🔑 ${LANG_ADMIN_HOST_MENU_TITLE:-Administração do Host (Acessos e API)}" "${COLOR_WHITE}" 69
	ui_print_header_line "" "" 69
	echo -e "╚═════════════════════════════════════════════════════════════════════╝"
	echo -e "${COLOR_RESET}"
	echo ""
	echo -e "${COLOR_BOLD}  ${LANG_SELECT_OPT:-Selecione uma opção:}${COLOR_RESET}"
	echo ""
	echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	
	ui_print_menu_item "1" "${LANG_ADMIN_HOST_OPT_1:-Gerar Token de API para automação externa}"
	
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	
	ui_print_menu_item "0" "${LANG_VM_OP_OPT_0:-Voltar}" "${COLOR_RED}"
	
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
	echo ""
	echo -e "${COLOR_YELLOW}  ${LANG_TYPE_OPT:-Digite sua opção} ${COLOR_GRAY}${LANG_PRESS_ENTER:-(ou pressione ENTER para sair)}${COLOR_YELLOW}: ${COLOR_RESET}"
	read -rsn1 opt
	while [ "$opt" != '' ]
	do
		if [[ $opt = "" ]]; then
			exit;
		else
			case $opt in
				1) clear;
				gerar_token_api_pbs
				admin_host_acessos_api_pbs_menu
					;;
				0) clear;
				seguranca_acessos_api_pbs_menu
					;;
				*) clear;
				seguranca_acessos_api_pbs_menu
					;;
			esac
		fi
	done
	seguranca_acessos_api_pbs_menu
}

seguranca_acessos_api_pbs_menu(){
	clear
	echo -e "${COLOR_CYAN}${COLOR_BOLD}"
	echo -e "╔═════════════════════════════════════════════════════════════════════╗"
	ui_print_header_line "" "" 69
	ui_print_header_line "🔒 ${LANG_SEGURANCA_MENU_TITLE:-Segurança, Acessos e API}" "${COLOR_WHITE}" 69
	ui_print_header_line "" "" 69
	echo -e "╚═════════════════════════════════════════════════════════════════════╝"
	echo -e "${COLOR_RESET}"
	echo ""
	echo -e "${COLOR_BOLD}  ${LANG_SELECT_OPT:-Selecione uma opção:}${COLOR_RESET}"
	echo ""
	echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	
	ui_print_menu_item "1" "${LANG_SEGURANCA_MENU_OPT_1:-Administração do Host (Acessos e API)}"
	
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	
	ui_print_menu_item "0" "${LANG_VM_OP_OPT_0:-Voltar}" "${COLOR_RED}"
	
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
	echo ""
	echo -e "${COLOR_YELLOW}  ${LANG_TYPE_OPT:-Digite sua opção} ${COLOR_GRAY}${LANG_PRESS_ENTER:-(ou pressione ENTER para sair)}${COLOR_YELLOW}: ${COLOR_RESET}"
	read -rsn1 opt
	while [ "$opt" != '' ]
	do
		if [[ $opt = "" ]]; then
			exit;
		else
			case $opt in
				1) clear;
				admin_host_acessos_api_pbs_menu
					;;
				0) clear;
				pbs_menu
					;;
				*) clear;
				pbs_menu
					;;
			esac
		fi
	done
	pbs_menu
}
