#!/bin/bash

# Menu principal do Proxmox Backup Server

recuperar_datastore_pbs() {
    clear
    echo -e "${COLOR_CYAN}${COLOR_BOLD}Recuperar DataStore do PBS${COLOR_RESET}\n"
    
    # 1. Listar discos (ocultando loops)
    echo -e "Discos disponíveis no sistema:\n"
    lsblk -o NAME,SIZE,LABEL,FSTYPE,UUID | grep -v loop
    echo ""
    
    # 2. Solicitar LABEL
    read -p "Digite exatamente o LABEL do disco físico que deseja montar: " pbs_label
    
    if [ -z "$pbs_label" ]; then
        echo -e "${COLOR_RED}LABEL inválido ou vazio. Cancelando.${COLOR_RESET}"
        sleep 2
        return
    fi
    
    # 3. Extrair UUID e FSTYPE via blkid
    if ! blkid -t LABEL="$pbs_label" > /dev/null 2>&1; then
        echo -e "${COLOR_RED}Erro: Nenhum disco encontrado com o LABEL '${pbs_label}'. Verifique e tente novamente.${COLOR_RESET}"
        sleep 3
        return
    fi
    
    local pbs_uuid=$(blkid -s UUID -o value -t LABEL="$pbs_label")
    local pbs_fstype=$(blkid -s TYPE -o value -t LABEL="$pbs_label")
    
    echo -e "${COLOR_GREEN}Disco físico encontrado! UUID: $pbs_uuid | FSTYPE: $pbs_fstype${COLOR_RESET}"
    
    # Verificação de colisão do nome do Datastore
    local datastore_name="$pbs_label"
    local mount_point="/mnt/$datastore_name"
    local cfg_file="/etc/proxmox-backup/datastore.cfg"
    
    # Checar se já existe a pasta montada OU se já existe no datastore.cfg
    while mountpoint -q "$mount_point" || grep -q "datastore: $datastore_name" "$cfg_file" 2>/dev/null; do
        echo -e "${COLOR_YELLOW}⚠️  Atenção: Já existe um Datastore ou ponto de montagem com o nome '${datastore_name}'.${COLOR_RESET}"
        read -p "Digite um NOVO NOME para este Datastore (ex: ${pbs_label}_2): " novo_nome
        if [ -n "$novo_nome" ]; then
            datastore_name="$novo_nome"
            mount_point="/mnt/$datastore_name"
        else
            echo -e "${COLOR_RED}Nome inválido. Cancelando.${COLOR_RESET}"
            sleep 2
            return
        fi
    done
    
    echo -e "\nO disco físico '${pbs_label}' será montado e configurado como Datastore '${datastore_name}'."
    
    # 4. Criar pasta de montagem
    mkdir -p "$mount_point"
    
    # 5. Adicionar no fstab (se não existir)
    if ! grep -q "$pbs_uuid" /etc/fstab; then
        echo -e "Adicionando entrada no /etc/fstab..."
        echo "UUID=$pbs_uuid $mount_point $pbs_fstype defaults 0 2" >> /etc/fstab
    else
        echo -e "${COLOR_YELLOW}O disco físico (UUID) já possui entrada no /etc/fstab.${COLOR_RESET}"
    fi
    
    # Montar e checar
    echo -e "Montando o disco..."
    mount -a
    
    if ! mountpoint -q "$mount_point"; then
        echo -e "${COLOR_RED}Falha ao montar o disco em $mount_point. Verifique o /etc/fstab e tente novamente.${COLOR_RESET}"
        sleep 3
        return
    fi
    
    # 6. Permissões
    echo -e "Ajustando permissões para o usuário 'backup'..."
    chown -R backup:backup "$mount_point"
    
    # 7. Inserir no datastore.cfg
    mkdir -p /etc/proxmox-backup
    
    echo -e "Injetando configurações no Proxmox Backup Server..."
    cat >> "$cfg_file" << EOF

datastore: $datastore_name
    path $mount_point
EOF
    echo -e "${COLOR_GREEN}✓ Datastore '$datastore_name' recuperado e configurado com sucesso!${COLOR_RESET}"
    
    echo ""
    read -p "Pressione ENTER para voltar ao menu..."
}
pbs_menu(){
	clear
	NORMAL=`echo "\033[m"`
	MENU=`echo "\033[36m"`
	NUMBER=`echo "\033[33m"`
	FGRED=`echo "\033[41m"`
	RED_TEXT=`echo "\033[31m"`
	ENTER_LINE=`echo "\033[33m"`
	
	echo -e "${COLOR_CYAN}${COLOR_BOLD}"
	echo -e "╔═════════════════════════════════════════════════════════════════════╗"
	ui_print_header_line "" "" 69
	ui_print_header_line "💾 ${LANG_PBS_MENU_TITLE:-Proxmox Backup Server - Menu Principal}" "${COLOR_WHITE}" 69
	ui_print_header_line "${LANG_MAIN_VERSION:-Versão:} ${version}" "${COLOR_YELLOW}" 69
	ui_print_header_line "" "" 69
	echo -e "╚═════════════════════════════════════════════════════════════════════╝"
	echo -e "${COLOR_RESET}"
	echo ""
	echo -e "${COLOR_BOLD}  ${LANG_SELECT_OPT:-Selecione uma opção:}${COLOR_RESET}"
	echo ""
	echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	
	ui_print_menu_item "1" "${LANG_PBS_MENU_OPT_1}"
	ui_print_menu_item "2" "${LANG_PBS_MENU_OPT_2}"
	ui_print_menu_item "3" "${LANG_PBS_MENU_OPT_3:-Recuperar DataStore (PBS)}"
	
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	
	ui_print_menu_item "0" "${LANG_PBS_MENU_OPT_0}" "${COLOR_RED}"
	
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
	echo ""
	echo -e "${COLOR_YELLOW}  ${LANG_TYPE_OPT:-Digite sua opção} ${COLOR_GRAY}${LANG_PRESS_ENTER:-(ou pressione ENTER para sair)}${COLOR_YELLOW}: ${COLOR_RESET}"
	read -rsn1 opt
	while [ opt != '' ]
	do
		if [[ $opt = "" ]]; then
			exit;
		else
			case $opt in
				1) clear;
				update_pbs_menu
				;;
				2) clear;
				disco_pbs_menu
				;;
				3) clear;
				recuperar_datastore_pbs
				pbs_menu
				;;
				0)
				clear
				main_menu
				;;
			esac
		fi
	done
	pve_menu
}

