#!/bin/bash

# Menu de ferramentas de disco do Proxmox Backup Server

disco_pbs_menu(){
	clear
	
	echo -e "${COLOR_CYAN}${COLOR_BOLD}"
	echo -e "╔═════════════════════════════════════════════════════════════════════╗"
	ui_print_header_line "" "" 69
	ui_print_header_line "💾 ${LANG_PBS_DISK_TITLE:-Ferramentas de Disco (PBS)}" "${COLOR_WHITE}" 69
	ui_print_header_line "" "" 69
	echo -e "╚═════════════════════════════════════════════════════════════════════╝"
	echo -e "${COLOR_RESET}"
	echo ""
	echo -e "${COLOR_BOLD}  ${LANG_SELECT_OPT:-Selecione uma opção:}${COLOR_RESET}"
	echo ""
	echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
	
	ui_print_menu_item "1" "${LANG_PBS_DISK_OPT_1}" "${COLOR_YELLOW}"
	
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	
	ui_print_menu_item "0" "${LANG_VM_OP_OPT_0:-Voltar}" "${COLOR_RED}"
	
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
	echo ""
	echo -e "${COLOR_YELLOW}  ${LANG_TYPE_OPT:-Digite sua opção} ${COLOR_GRAY}${LANG_PRESS_ENTER:-(ou pressione ENTER para sair)}${COLOR_YELLOW}: ${COLOR_RESET}"
	read -rsn1 opt
	while [ "$opt" != '' ]
	do
		if [[ $opt = "" ]]; then
			exit;
		else
			case $opt in
				1) clear
				lsblk -o NAME,SIZE,LABEL,MOUNTPOINT,FSTYPE
				echo ""
				echo -e "  ${COLOR_WHITE}${LANG_DISK_PREP:-Qual o disco que vai ser preparado? EX: sda / nvme0n1}${COLOR_RESET}"
read -p  "${LANG_AUTO_MENU_DISCO_PBS_261:-  Disco: }" FORMATADISCO
				echo -e "  ${COLOR_WHITE}${LANG_DISK_PBS_NAME:-Qual o nome do Datastore? EX: BACKUP_REDE / STORE_01}${COLOR_RESET}"
read -p  "${LANG_AUTO_MENU_DISCO_PBS_262:-  Nome: }" STORAGE
				echo ""
echo -e  "${LANG_AUTO_MENU_DISCO_PBS_263:-${COLOR_YELLOW}  ⚠️  Atenção: o disco /dev/${FORMATADISCO} será formatado!${COLOR_RESET}}"
read -p  "${LANG_AUTO_MENU_DISCO_PBS_264:-  Confirma? (s/N): }" confirm
				if [[ "$confirm" =~ ^[sS]$ ]]; then
					umount /dev/$FORMATADISCO 2>/dev/null
					umount /dev/${FORMATADISCO}1 2>/dev/null
					umount /dev/${FORMATADISCO}p1 2>/dev/null
					wipefs -a /dev/$FORMATADISCO 2>/dev/null
					echo -e "g\nn\np\n1\n\n\nw" | fdisk /dev/$FORMATADISCO >/dev/null 2>&1
					partprobe /dev/$FORMATADISCO 2>/dev/null
					sleep 2
					if [[ "$FORMATADISCO" =~ (nvme|mmcblk) ]]; then
						PART_DEV="/dev/${FORMATADISCO}p1"
					else
						PART_DEV="/dev/${FORMATADISCO}1"
					fi
					mkfs.ext4 -F -L $STORAGE $PART_DEV
					mkdir -p /mnt/$STORAGE
					sed -i /"$STORAGE"/d /etc/fstab
					echo "" >> /etc/fstab
					echo "LABEL=$STORAGE /mnt/$STORAGE ext4 defaults,auto,nofail 0 0" >> /etc/fstab
					mount -a
					proxmox-backup-manager datastore create $STORAGE /mnt/$STORAGE
					echo ""
					echo -e "${COLOR_GREEN}  ✓ ${LANG_PBS_DS_SUC:-Datastore criado com sucesso!} (${STORAGE})${COLOR_RESET}"
				else
					echo -e "${COLOR_GRAY}  ${LANG_PBS_CANCEL:-Operação cancelada.}${COLOR_RESET}"
				fi
				read -p "  ${LANG_PBS_PRESS_CONT:-Pressione ENTER para continuar...}"
				clear
				disco_pbs_menu
				;;
				0) clear;
				pbs_menu;
				;;
				*) clear;
				pbs_menu;
				;;
			esac
		fi
	done
}
