#!/bin/bash

# Menu de ferramentas de disco do Proxmox Backup Server

disco_pbs_menu(){
	clear
	
	echo -e "${COLOR_CYAN}${COLOR_BOLD}"
	echo -e "╔═════════════════════════════════════════════════════════════════════╗"
	echo -e "║                                                                     ║"
	echo -e "║                    💾 Ferramentas de Disco (PBS)                    ║"
	echo -e "║                                                                     ║"
	echo -e "╚═════════════════════════════════════════════════════════════════════╝"
	echo -e "${COLOR_RESET}"
	echo ""
	echo -e "${COLOR_BOLD}  Selecione uma opção:${COLOR_RESET}"
	echo ""
	echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_YELLOW}1${COLOR_RESET} ${COLOR_GREEN}➜${COLOR_RESET}  ${COLOR_WHITE}Configura disco e cria Datastore PBS${COLOR_RESET}                    ${COLOR_CYAN}│${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}  ${COLOR_RED}0${COLOR_RESET} ${COLOR_RED}➜${COLOR_RESET}  ${COLOR_WHITE}Voltar${COLOR_RESET}                                                  ${COLOR_CYAN}│${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
	echo ""
	echo -e "${COLOR_YELLOW}  Digite sua opção ${COLOR_GRAY}(ou pressione ENTER para sair)${COLOR_YELLOW}: ${COLOR_RESET}"
	read -rsn1 opt
	while [ "$opt" != '' ]
	do
		if [[ $opt = "" ]]; then
			exit;
		else
			case $opt in
				1) clear
				lsblk -o NAME,SIZE,LABEL,MOUNTPOINT,FSTYPE
				echo ""
				echo -e "${COLOR_WHITE}  Qual o disco que vai ser preparado? ${COLOR_GRAY}EX: sda / nvme0n1${COLOR_RESET}"
				read -p "  Disco: " FORMATADISCO
				echo -e "${COLOR_WHITE}  Qual o nome do Datastore? ${COLOR_GRAY}EX: BACKUP_REDE / STORE_01${COLOR_RESET}"
				read -p "  Nome: " STORAGE
				echo ""
				echo -e "${COLOR_YELLOW}  ⚠️  Atenção: o disco /dev/${FORMATADISCO} será formatado!${COLOR_RESET}"
				read -p "  Confirma? (s/N): " confirm
				if [[ "$confirm" =~ ^[sS]$ ]]; then
					echo -e "g\nn\np\n1\n\n\nw" | fdisk /dev/$FORMATADISCO
					mkfs.ext4 -L $STORAGE /dev/$FORMATADISCO
					mkdir -p /mnt/$STORAGE
					sed -i /"$STORAGE"/d /etc/fstab
					echo "" >> /etc/fstab
					echo "LABEL=$STORAGE /mnt/$STORAGE ext4 defaults,auto,nofail 0 0" >> /etc/fstab
					mount -a
					proxmox-backup-manager datastore create $STORAGE /mnt/$STORAGE
					echo ""
					echo -e "${COLOR_GREEN}  ✓ Datastore '${STORAGE}' criado com sucesso!${COLOR_RESET}"
				else
					echo -e "${COLOR_GRAY}  Operação cancelada.${COLOR_RESET}"
				fi
				read -p "  Pressione ENTER para continuar..."
				clear
				disco_pbs_menu
				;;
				0) clear;
				pbs_menu;
				;;
				*) clear;
				pbs_menu;
				;;
			esac
		fi
	done
}
