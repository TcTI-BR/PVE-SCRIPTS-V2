#!/bin/bash

# Menu de upgrade de versões do Proxmox Backup Server

upgrade_pbs_menu(){
	clear
	NORMAL=`echo "\033[m"`
	MENU=`echo "\033[36m"`
	NUMBER=`echo "\033[33m"`
	FGRED=`echo "\033[41m"`
	RED_TEXT=`echo "\033[31m"`
	ENTER_LINE=`echo "\033[33m"`
	
	echo -e "${COLOR_CYAN}${COLOR_BOLD}"
	echo -e "╔═════════════════════════════════════════════════════════════════════╗"
	ui_print_header_line "" "" 69
	ui_print_header_line "🚀 ${LANG_PBS_UPGRADE_TITLE:-Upgrade de Versões do Proxmox PBS}" "${COLOR_WHITE}" 69
	ui_print_header_line "" "" 69
	echo -e "╚═════════════════════════════════════════════════════════════════════╝"
	echo -e "${COLOR_RESET}"
	echo ""
echo -e  "${LANG_AUTO_MENU_UPGRADE_PB_269:-${COLOR_YELLOW}${COLOR_BOLD}  ⚠️  ATENÇÃO:${COLOR_RESET}}"
	echo -e "${COLOR_YELLOW}  ${LANG_PBS_UPGRADE_WARN:-Faça backup antes de realizar qualquer upgrade!}${COLOR_RESET}"
	echo ""
	echo -e "${COLOR_BOLD}  ${LANG_PBS_UPGRADE_SELECT:-Selecione a versão de destino:}${COLOR_RESET}"
	echo ""
	echo -e "  ${COLOR_CYAN}┌───────────────────────────────────────────────────────────────┐${COLOR_RESET}"
	
	ui_print_menu_item "1" "${LANG_PBS_UPGRADE_OPT_1}" "${COLOR_YELLOW}"
	
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	
	ui_print_menu_item "0" "${LANG_VM_OP_OPT_0:-Voltar}" "${COLOR_RED}"
	
	echo -e "  ${COLOR_CYAN}│${COLOR_RESET}                                                               ${COLOR_CYAN}│${COLOR_RESET}"
	echo -e "  ${COLOR_CYAN}└───────────────────────────────────────────────────────────────┘${COLOR_RESET}"
	echo ""
	echo -e "${COLOR_YELLOW}  ${LANG_TYPE_OPT:-Digite sua opção} ${COLOR_GRAY}${LANG_PRESS_ENTER:-(ou pressione ENTER para sair)}${COLOR_YELLOW}: ${COLOR_RESET}"
	read -rsn1 opt
	while [ opt != '' ]
	do
		if [[ $opt = "" ]]; then
			exit;
		else
			case $opt in
				1) clear;
				mv /etc/apt/sources.list.d/pbs-enterprise.list /root/ 2>/dev/null
				sed -i 's/buster\/updates/bullseye-security/g;s/buster/bullseye/g' /etc/apt/sources.list
				sed -i '/pbs-no-subscription/d' /etc/apt/sources.list
				echo "${LANG_AUTO_MENU_UPGRADE_PB_270:-deb http://download.proxmox.com/debian/pbs bullseye pbs-no-subscription}" >> /etc/apt/sources.list
				apt update
				systemctl stop proxmox-backup-proxy.service proxmox-backup.service
				apt dist-upgrade -y
				apt upgrade -y 
				systemctl start proxmox-backup-proxy.service proxmox-backup.service
				clear 
				update_pbs_menu;
				;;
				0) clear;
				update_pbs_menu;
				;;
				x)exit;
				;;
				\n)exit;
				;;
				*)clear;
				update_pbs_menu;
				;;
			esac
		fi
	done
}

